import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeferralComponent } from './deferral.component';

describe('DeferralComponent', () => {
  let component: DeferralComponent;
  let fixture: ComponentFixture<DeferralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeferralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeferralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

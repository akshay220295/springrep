import { TestBed } from '@angular/core/testing';

import { MatConfirmationService } from './mat-confirmation.service';

describe('MatConfirmationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MatConfirmationService = TestBed.get(MatConfirmationService);
    expect(service).toBeTruthy();
  });
});

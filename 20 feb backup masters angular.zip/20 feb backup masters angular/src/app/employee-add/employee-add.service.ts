import { Injectable } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {Http,Response} from '@angular/http';
import { Router, ActivatedRoute } from '@angular/router';
import 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { map } from "rxjs/operators"; 
import 'rxjs/add/observable/of';
import 'rxjs-compat';


@Injectable({
  providedIn: 'root'
})
export class EmployeeAddService {
  BASEURI='http://localhost:8080/';
  
  constructor(
    private httpClient:HttpClientModule, 
    private router :Router , 
    private ActivatedRoute : ActivatedRoute,
     public http:Http) { }

getAllSaluatations()
{
  return this.http.get(this.BASEURI+"salutation/getAll")
  .pipe(map(resp=>resp.json()));
}
}


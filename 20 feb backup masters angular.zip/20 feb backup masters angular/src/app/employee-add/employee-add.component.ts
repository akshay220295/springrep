import { Component, OnInit, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { EmployeeAddService } from './employee-add.service';
import { salutation } from '../Models/salutation';
import { employee } from '../Models/employee';
import 'rxjs-compat';

@Component({
  selector: 'app-employee-add',
  templateUrl: './employee-add.component.html',
  styleUrls: ['./employee-add.component.css']
})
export class EmployeeAddComponent implements OnInit {
  employeeModel;
  salut:Array<salutation>[];


 
  BASEURI = 'http://localhost:8080/employee/'

  BASEURI2='http://localhost:8080/salutation/getAll'

  //BASEURI3='http://localhost:8080/emp/'

  //BASEURI4='http://localhost:8080/salutation/'
  id;
  updatingBoolean;
  constructor( 
  
    private http:HttpClient, private router :Router , private route : ActivatedRoute,
    private employeeService:EmployeeAddService) { 
    // this.salut =new salutation();
    this.employeeModel = new employee();
    // this.Salutation=new salutation();
    
// this.salutationModel=new salutation();
    
  }


  ngOnInit() {
    
    this.route.params.subscribe(params => {
      this.id = params["id"];
    });
    console.log(this.id)
    if(this.id != 0){
      this.updatingBoolean = true
       this.fetchemployeeById(this.id);
      
     
    }
 
    this.fetchsalutationModel();
      
  }

  fetchemployeeById(id){
    this.http.get(this.BASEURI+"id"+id).subscribe(
      res => {
        this.employeeModel = res["data"]["REQUESTED VALUE"]
        console.log("RESPONSE......", res)

      },
      err => {
              console.log("ERR" + err)
            }
    )
  }



  fetchsalutationModel()
  {
 
    this.employeeService.getAllSaluatations().subscribe(
      data=>
      {
       
        this.salut=data['data']['LIST ALL'];
        //this.salut = Array.of(this.salut); 
        
        
      },
      err=>
      {
        console.log("err",err);
      }
      )
  }

  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating..")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
 }

)
 
}
 this.http.post(this.BASEURI, JSON.stringify(this.employeeModel) , options).subscribe(
   res => {
     if(res){
this.router.navigate(["/employee"])
     }
   }
 )
} 
}

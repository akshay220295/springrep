import { Component, OnInit } from '@angular/core';
import { residential } from '../Models/residential';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-residential-status-add',
  templateUrl: './residential-status-add.component.html',
  styleUrls: ['./residential-status-add.component.css']
})
export class ResidentialStatusAddComponent implements OnInit {

  
  BASEURI = 'http://localhost:8080/residentialStatus/'
  residentModel: residential = new residential();
  id;

 updatingBoolean=false;
 allvalues: any;
 constructor(private http: HttpClient , private router :Router , private route : ActivatedRoute ) { 
   
   
 }
 ngOnInit() {
  

   this.route.params.subscribe(params => {
     this.id = params["id"];
   });
   console.log(this.id)
   if(this.id != 0){
     this.updatingBoolean = true
     this.fetchById(this.id);
   }
 }

//To Get BY Id
 fetchById(id){
  this.http.get(this.BASEURI+id).subscribe(
   res => {
       if(res["data"]){
       this.residentModel = res["data"]["BY ID"]["body"]
       }
     }
   )
  }
  
  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
}) 
}
 this.http.post(this.BASEURI , JSON.stringify(this.residentModel) , options).subscribe(
   res => {
     console.log("RES " , res)
     if(res){
this.router.navigate(["/residentialStatus"])
     }
   }
 )

}
getAllValues() {
  this.http.get(this.BASEURI+'getAll').subscribe(
    res => {
      console.log("RESPONSE ", res)
    this.allvalues = res['data']['List All']
    console.log(this.allvalues)
    },
    err => {
      console.log("ERR" + err)
    }
  )
}
deleterecord(id) {
  this.http.delete(this.BASEURI + id).subscribe(
    _data=>{
      this.getAllValues()
      this.router.navigate(["/residentialStatus"])
    }
    
  )
  }
}



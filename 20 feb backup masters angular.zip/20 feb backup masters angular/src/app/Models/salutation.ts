export class salutation
{

    salutationId:number;
    salutationName:string;
    salutationCreatedDate:string;
    salutationCreatedBy:string;
    salutationModifiedDate:string;
    salutationModifiedBy:string;
    salutationCertified:number;    

}
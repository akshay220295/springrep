import { Deferral } from './deferral';

describe('Deferral', () => {
  it('should create an instance', () => {
    expect(new Deferral()).toBeTruthy();
  });
});

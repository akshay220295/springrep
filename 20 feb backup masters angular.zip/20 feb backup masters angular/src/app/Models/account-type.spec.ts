import { accounttype } from './account-type';

describe('AccountType', () => {
  it('should create an instance', () => {
    expect(new accounttype()).toBeTruthy();
  });
});

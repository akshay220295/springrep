export class residential {
    residentId:number;
    residentName:string;
    residentCreatedDate:string;
    residentCreatedBy:string;
    residentModifiedDate:string;
    residentModifiedBy:string;
    residentCertified:number;
}

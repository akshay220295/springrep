import { Residential } from './residential';

describe('Residential', () => {
  it('should create an instance', () => {
    expect(new Residential()).toBeTruthy();
  });
});

export class vip {

    vipId:number;
    vipName:string;
    vipCreatedDate:string;
    vipCreatedBy:string;
    vipModifiedDate:string;
    vipModifiedBy:number;
    vipCertified:string;
    bankId:number;
}

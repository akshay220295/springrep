export class relationship
{
    relationId:number;
    relationName:string;
    relationCreatedDate:string;
    relationCreatedBy:string;
    relationModifiedDate:string;
    relationModifiedBy:string;
    relationCertifed:number;
}
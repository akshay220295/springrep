import { Bureau } from './bureau';

describe('Bureau', () => {
  it('should create an instance', () => {
    expect(new Bureau()).toBeTruthy();
  });
});

export class maritalstatus {

    maritalStatusId:number;
    maritalStatusName:string;
    maritalStatusCreatedDate:string;
    maritalStatusCreatedby:string;
    maritalStatusModifiedDate:string;
    maritalStatusModifiedBy:string;
    maritalStatusCertified:number;
    }

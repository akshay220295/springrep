export class dsa {

    dsaId:number;
    dsaName:string;
    dsaCategory:string;
    dsaAdd1:string;
    dsaAdd2:string;
    dsaAdd3:string;
    dsaCity:string;
    dsaState:string;
    dsaCountry:string;
    dsaPin:string;
    dsaWebsite:string;
    dsaAuthPersonName:string;
    dsaAuthPersonMobNo:number;
    dsaAuthPersonEmail:string;
    dsaTaxId:number;
    dsaRegistrationNo:number;
    dsaCreatedDate:string;
    dsaCreatedBy:string;
    dsaModifiedDate:string;
    dsaModifiedBy:string;
    dsaCertified:number;
    dsaBankId:number;
}

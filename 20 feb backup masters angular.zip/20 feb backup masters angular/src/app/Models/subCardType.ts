export class subCardType
{
    subcardTypeId:number;
    subcardTypeCode:string;
    subcardTypeName:string;
    subcardTypeCreatedDate:string;
    subcardTypeCreatedby:string;
    subcardTypeModifiedDate:string;
    subcardTypeModifiedBy:string;
    subcardTypeCertified:number;
    bankId:number;
    entityId:number;
}
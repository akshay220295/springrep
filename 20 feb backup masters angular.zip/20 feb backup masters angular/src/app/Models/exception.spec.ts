import { Exception } from './exception';

describe('Exception', () => {
  it('should create an instance', () => {
    expect(new Exception()).toBeTruthy();
  });
});

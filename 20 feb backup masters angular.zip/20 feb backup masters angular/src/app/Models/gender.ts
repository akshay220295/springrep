export class gender{

    genderID:number;
    genderName:string;
    genderCreatedDate:string;
    genderCreatedBy:string;
    genderModifiedDate:string;
    genderModifiedBy:string;
    certified:number;

}
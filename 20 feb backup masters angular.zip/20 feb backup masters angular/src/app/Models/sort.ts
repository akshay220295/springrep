export class Sort {
    sorted: boolean;
    unsorted: boolean;
  }
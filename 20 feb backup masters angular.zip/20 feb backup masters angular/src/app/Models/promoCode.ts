export class promoCode
{
    prmocdeId:number;
    prmocdeName:string;
    prmocdeStartDate:string;
    prmocdeExpiryDate:string;
    prmocdeCreatedDate:string;
    prmocdeCreatedBy:string;
    prmocdeModifiedDate:string;
    prmocdeModifyBy:string;
    prmocdeCertified:number;
    bankId:number;
    
}
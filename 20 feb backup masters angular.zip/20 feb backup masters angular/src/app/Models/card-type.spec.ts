import { cardtype } from './card-type';

describe('CardType', () => {
  it('should create an instance', () => {
    expect(new cardtype()).toBeTruthy();
  });
});

import { salutation } from './salutation';

export class employee
{
    employeeId:number;
    employeeCode:string;
    employeeSsoId:string;
    employeeEcn:string;
    employeeSalutationId:number;
    employeeFirstName:string;
    employeeMiddleName:string;
    employeeLastName:string;
    employeeFullName:string;
    employeeMobileNumber:number;
    employeeEmail:string;
    employeeBarCode:string;
    employeeDesignationId:string;
    employeeDepartmentId:string;
    employeeSeparationDate:string;
    employeeCreatedDate:string;
    employeeCreatedby:string;
    employeeModifiedDate:string;
    employeeModifiedBy:string;
    employeeCertified:number;
    BankId:number;
    entityId:number;
 



    



}
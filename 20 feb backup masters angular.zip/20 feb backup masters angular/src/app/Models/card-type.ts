export class cardtype{

    cardTypeId:number;
    cardTypeName:string;
    cardTypeCreatedDate:string;
    cardTypeCreatedBy:string;
    cardTypeModifiedDate:string;
    cardTypeModifiedBy:string;
    cardTypeCertified:number;
    cardTypeBankId:number;
}
export class channel {
    channelId:number;
    channelName:string;
    channelCreatedDate:string;
    channelCreatedBy:string;
    channelModifiedDate:string;
    channelModifiedBy:string;
    channelCertified:number;
    channelCheckBy:string;
    channelCheckDate:string;
}

export class education {

    educationId:number;
    educationName:string;
    educationCreatedDate:string;
    educationCreatedBy:string;
    educationModifiedDate:string;
    educationModifiedBy:string;
    educationCertified:number;
}

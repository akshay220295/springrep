export class accounttype {

    accountTypeId:number;
    accountTypeName:string;
    accountTypeCreatedDate:string;
    accountTypeCreatedBy:string;
    accountTypeModifiedDate:string;
    accountTypeModifiedBy:string;
    accountTypeCertified:number;
}

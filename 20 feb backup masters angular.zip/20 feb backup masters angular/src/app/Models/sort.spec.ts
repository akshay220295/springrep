import { Sort } from './sort';

describe('Sort', () => {
  it('should create an instance', () => {
    expect(new Sort()).toBeTruthy();
  });
});

import { AutoDebit } from './auto-debit';

describe('AutoDebit', () => {
  it('should create an instance', () => {
    expect(new AutoDebit()).toBeTruthy();
  });
});

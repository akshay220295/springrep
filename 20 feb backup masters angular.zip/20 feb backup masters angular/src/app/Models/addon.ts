export class addon {

    refNo:number;
    accountId:number;
    addonCrtDte:Date;
}

export class bureau {
    bureauId:number;
    bureauMemberId:string;
    bureauPassword:string;
    bureauCategory:string;
    bureauCreatedDate:string;
    bureauCreatedBy:string;
    bureauModifiedDate:string;
    bureauModifiedBy:string;
    bureauCertified:number;
    bureauBankId:number;
}

import { Dsa } from './dsa';

describe('Dsa', () => {
  it('should create an instance', () => {
    expect(new Dsa()).toBeTruthy();
  });
});

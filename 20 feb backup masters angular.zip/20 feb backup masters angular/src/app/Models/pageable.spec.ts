import { Pageable } from './pageable';

describe('Pageable', () => {
  it('should create an instance', () => {
    expect(new Pageable()).toBeTruthy();
  });
});

export class priority
{
    priorityId:number;
    priorityName:string;
    priorityFstTrkFlag:string;
    priorityCreatedDate:string;
    priorityCreatedBy:string;
    priorityModifiedDate:string;
    priorityModifiedBy:string;
    priorityCertified:string;
    priorityBankId:number;
}
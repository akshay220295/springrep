import { Decision } from './decision';

describe('Decision', () => {
  it('should create an instance', () => {
    expect(new Decision()).toBeTruthy();
  });
});

export class deferral {

    deferralId:number;
    deferralName:string;
    deferralCreatedDate:string;
    deferralCreatedBy:string;
    deferralModifiedDate:string;
    deferralModifiedBy:string;
    deferralCertified:number;
    deferralBankId:number;
}

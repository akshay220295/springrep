import { Vip } from './vip';

describe('Vip', () => {
  it('should create an instance', () => {
    expect(new Vip()).toBeTruthy();
  });
});

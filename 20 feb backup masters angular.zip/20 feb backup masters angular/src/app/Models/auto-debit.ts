export class autoDebit {
    autodbtAgnstId:number;
    autodbtAgnstName:string;
    autodbtAgnstCrtDte:string;
    autodbtAgnstCrtdBy:string;
    autodbtAgnstModDte:string;
    autodbtAgnstModBy:string;
    autodbtAgnstCertified:number;
    autodbtAgnstBankId:number;
}

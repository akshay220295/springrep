import { TestBed } from '@angular/core/testing';

import { EmployeeAddServiceService } from './employee-add-service.service';

describe('EmployeeAddServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EmployeeAddServiceService = TestBed.get(EmployeeAddServiceService);
    expect(service).toBeTruthy();
  });
});

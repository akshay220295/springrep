import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterCompComponent } from './master-comp/master-comp.component';
import {AccountTypeComponent} from './account-type/account-type.component'
import { HomeComponent } from './home/home.component';
import { AccounttypeAddComponent } from './accounttype-add/accounttype-add.component';
import{GenderComponent} from './gender/gender.component';
import{GenderAddComponent} from './gender-add/gender-add.component';
import{SalutationComponent} from './salutation/salutation.component';
import {SalutationAddComponent} from './salutation-add/salutation-add.component';
import {ChannelComponent} from './channel/channel.component';
import {ChannelAddComponent} from './channel-add/channel-add.component';
import {DecisionComponent} from './decision/decision.component';
import { DecisionAddComponent } from './decision-add/decision-add.component';
import { DeferralComponent } from './deferral/deferral.component';
import { DeferralAddComponent } from './deferral-add/deferral-add.component';
import { EducationComponent } from './education/education.component';
import { EducationAddComponent } from './education-add/education-add.component';
import { ExceptionComponent } from './exception/exception.component';
import { ExceptionAddComponent } from './exception-add/exception-add.component';
import { MaritalStatusComponent } from './marital-status/marital-status.component';
import { MaritalStatusAddComponent } from './marital-status-add/marital-status-add.component';
import { OccupationComponent } from './occupation/occupation.component';
import { OccupationAddComponent } from './occupation-add/occupation-add.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { PromocodeComponent } from './promocode/promocode.component';
import { PromocodeAddComponent } from './promocode-add/promocode-add.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RelationshipAddComponent } from './relationship-add/relationship-add.component';
import { ResidentialStatusComponent } from './residential-status/residential-status.component';
import { ResidentialStatusAddComponent } from './residential-status-add/residential-status-add.component';
import { SubCardTypeComponent } from './sub-card-type/sub-card-type.component';
import { SubCardTypeAddComponent } from './sub-card-type-add/sub-card-type-add.component';
import { CardTypeComponent } from './card-type/card-type.component';
import { CardTypeAddComponent } from './card-type-add/card-type-add.component';
import { DSAAddComponent } from './dsa-add/dsa-add.component';
import { DSAComponent } from './dsa/dsa.component';
import { AutoDebitComponent } from './auto-debit/auto-debit.component';
import { AutoDebitAddComponent } from './auto-debit-add/auto-debit-add.component';
import { PriorityComponent } from './priority/priority.component';
import { PriorityAddComponent } from './priority-add/priority-add.component';
import { VipComponent } from './vip/vip.component';
import { VipAddComponent } from './vip-add/vip-add.component';
import { BureauComponent } from './bureau/bureau.component';
import { BureauAddComponent } from './bureau-add/bureau-add.component';
import { CustomPaginationComponent } from './custom-pagination/custom-pagination.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { MatConfirmationComponent } from './mat-confirmation/mat-confirmation.component';



const routes: Routes = [
  {path : '' , component : HomeComponent},
  {path:'masterComp',component:MasterCompComponent},
{path:'AccountType', component:AccountTypeComponent},
{path:'AccountTypeAdd/:id',component:AccounttypeAddComponent},
{path:'AutoDebitAgainst',component:AutoDebitComponent},
{path:'AutoDebitAgainstAdd/:id',component:AutoDebitAddComponent},
{path:'cardType',component:CardTypeComponent},
{path:'cardTypeAdd/:id',component:CardTypeAddComponent},
{path:'bureau',component:BureauComponent},
{path:'bureau-add/:id',component:BureauAddComponent},
{path:'gender',component:GenderComponent},
{path:'genderAdd/:id',component:GenderAddComponent},
{path:'salutation',component:SalutationComponent},
{path:'salutationAdd/:id',component:SalutationAddComponent},
{path:'channel',component:ChannelComponent},
{path:'channelAdd/:id',component:ChannelAddComponent},
{path:'decision',component:DecisionComponent},
{path:'decisionAdd/:id',component:DecisionAddComponent},
{path:'deferral',component:DeferralComponent},
{path:'deferralAdd/:id',component:DeferralAddComponent},
{path:'dsa',component:DSAComponent},
{path:'dsaAdd/:id',component:DSAAddComponent},
{path:'education',component:EducationComponent},
{path:'educationAdd/:id',component:EducationAddComponent},
{path:'exception',component:ExceptionComponent},
{path:'exceptionAdd/:id',component:ExceptionAddComponent},
{path:'maritalStatus',component:MaritalStatusComponent},
{path:'maritalStatusAdd/:id',component:MaritalStatusAddComponent},
{path:'occupation',component:OccupationComponent},
{path:'occupationAdd/:id',component:OccupationAddComponent},
{path:'priority',component:PriorityComponent},
{path:'priorityAdd/:id',component:PriorityAddComponent},
{path:'product',component:ProductComponent},
{path:'productAdd/:id',component:ProductAddComponent},
{path:'promoCode',component:PromocodeComponent},
{path:'promoCodeAdd/:id',component:PromocodeAddComponent},
{path:'relationship',component:RelationshipComponent},
{path:'relationshipAdd/:id',component:RelationshipAddComponent},
{path:'residentialStatus',component:ResidentialStatusComponent},
{path:'residentialStatusAdd/:id',component:ResidentialStatusAddComponent},
{path:'subCardType',component:SubCardTypeComponent},
{path:'subCardTypeAdd/:id',component:SubCardTypeAddComponent},
{path:'vip',component:VipComponent},
{path:'vipAdd/:id',component:VipAddComponent},
{path:'custom-pagination',component:CustomPaginationComponent},
{path:'employee',component:EmployeeComponent},
{path:'employeeAdd/:id',component:EmployeeAddComponent},
{path:'addon',component:MatConfirmationComponent}
];
              
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

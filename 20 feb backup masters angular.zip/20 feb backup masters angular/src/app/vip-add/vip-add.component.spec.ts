import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VipAddComponent } from './vip-add.component';

describe('VipAddComponent', () => {
  let component: VipAddComponent;
  let fixture: ComponentFixture<VipAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VipAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VipAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

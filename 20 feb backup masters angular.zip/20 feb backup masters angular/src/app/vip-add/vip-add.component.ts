import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { vip } from '../Models/vip';

@Component({
  selector: 'app-vip-add',
  templateUrl: './vip-add.component.html',
  styleUrls: ['./vip-add.component.css']
})
export class VipAddComponent implements OnInit {

  
  BASEURI = 'http://localhost:8080/vip/'
  vipModel: vip =new vip()
  id;

 updatingBoolean=false;
 allvalues: any;
 constructor(private http: HttpClient , private router :Router , private route : ActivatedRoute ) { 
   
   
 }
 ngOnInit() {
  

   this.route.params.subscribe(params => {
     this.id = params["id"];
   });
   console.log(this.id)
   if(this.id != 0){
     this.updatingBoolean = true
     this.fetchById(this.id);
   }
 }

//To Get BY Id
 fetchById(id){
  this.http.get(this.BASEURI+id).subscribe(
   res => {
       if(res["data"]){
       this.vipModel = res["data"]["BY ID"]["body"]
       }
     }
   )
  }
 
create(form :NgForm){
 if(!form.valid){
   return
 }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
'Content-Type': 'application/json',
}) 
}
this.http.post(this.BASEURI, JSON.stringify(this.vipModel) , options).subscribe(
  res => {
    console.log("RES " , res)
    if(res){
this.router.navigate(["/vip"])
    }
  }
)
}
}

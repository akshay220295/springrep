import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { gender } from '../Models/gender';

@Component({
  selector: 'app-gender-add',
  templateUrl: './gender-add.component.html',
  styleUrls: ['./gender-add.component.css']
})
export class GenderAddComponent implements OnInit {
   
   BASEURI = 'http://localhost:8080/gender/'
   genderModel: gender = new gender();
  id;

 updatingBoolean=false;
 allvalues: any;
 constructor(private http: HttpClient , private router :Router , private route : ActivatedRoute ) { 
   
   
 }
 ngOnInit() {
  

   this.route.params.subscribe(params => {
     this.id = params["id"];
   });
   console.log(this.id)
   if(this.id != 0){
     this.updatingBoolean = true
     this.fetchById(this.id);
   }
 }

//To Get BY Id
 fetchById(id){
  this.http.get(this.BASEURI+id).subscribe(
   res => {
       if(res["data"]){
       this.genderModel = res["data"]["BY ID"]["body"]
       }
     }
   )
  }
  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
}) 
}
 this.http.post(this.BASEURI, JSON.stringify(this.genderModel) , options).subscribe(
   res => {
     console.log("RES " , res)
     if(res){
this.router.navigate(["/gender"])
     }
   }
 )
}
getAllValues() {
  this.http.get(this.BASEURI+'getAll').subscribe(
    res => {
      console.log("RESPONSE ", res)
    this.allvalues = res['data']['List All']
    console.log(this.allvalues)
    },
    err => {
      console.log("ERR" + err)
    }
  )
}
 deleterecord(id) {
  this.http.delete(this.BASEURI + id).subscribe(
    data=>{
      this.getAllValues()
      this.router.navigate(["/gender"])
    }
    
  )
  }
}



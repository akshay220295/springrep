import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccounttypeAddComponent } from './accounttype-add.component';

describe('AccounttypeAddComponent', () => {
  let component: AccounttypeAddComponent;
  let fixture: ComponentFixture<AccounttypeAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccounttypeAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccounttypeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

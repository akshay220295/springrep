import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { accounttype } from '../Models/account-type';

@Component({
  selector: 'app-accounttype-add',
  templateUrl: './accounttype-add.component.html',
  styleUrls: ['./accounttype-add.component.css']
})
export class AccounttypeAddComponent implements OnInit {


     
     BASEURI = 'http://localhost:8080/accountType/'
     accounttypeModel: accounttype = new accounttype();
     id;
   
    updatingBoolean=false;
    allvalues: any;
    constructor(private http: HttpClient , private router :Router , private route : ActivatedRoute ) { 
      
      
    }
    ngOnInit() {
     
  
      this.route.params.subscribe(params => {
        this.id = params["id"];
      });
      console.log(this.id)
      if(this.id != 0){
        this.updatingBoolean = true
        this.fetchById(this.id);
      }
    }
  
  //To Get BY Id
    fetchById(id){
     this.http.get(this.BASEURI+id).subscribe(
      res => {
          if(res["data"]){
          this.accounttypeModel = res["data"]["BY ID"]["body"]
          }
        }
      )
     }
    
  create(form :NgForm){
    if(!form.valid){
      return
    }  
  console.log("Creating")
  let options = { headers: new HttpHeaders({ 
   'Content-Type': 'application/json',
  }) 
  }
   this.http.post(this.BASEURI, JSON.stringify(this.accounttypeModel) , options).subscribe(
     res => {
       console.log("RES " , res)
       if(res){
  this.router.navigate(["/AccountType"])
       }
     }
   )
  }
  }
  
  
  
  
  


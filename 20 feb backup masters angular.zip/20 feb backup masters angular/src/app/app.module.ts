import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MasterCompComponent } from './master-comp/master-comp.component';
import { AccountTypeComponent } from './account-type/account-type.component';
import { HomeComponent } from './home/home.component';
import { AccounttypeAddComponent } from './accounttype-add/accounttype-add.component';
import { HttpClientModule } from '@angular/common/http';
import{BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { GenderComponent } from './gender/gender.component';
import { GenderAddComponent } from './gender-add/gender-add.component';
import { SalutationComponent } from './salutation/salutation.component';
import { SalutationAddComponent } from './salutation-add/salutation-add.component';
import { ChannelComponent } from './channel/channel.component';
import { ChannelAddComponent } from './channel-add/channel-add.component';
import { DecisionComponent } from './decision/decision.component';
import { DecisionAddComponent } from './decision-add/decision-add.component';
import { DeferralComponent } from './deferral/deferral.component';
import { DeferralAddComponent } from './deferral-add/deferral-add.component';
import { DSAComponent } from './dsa/dsa.component';
import { DSAAddComponent } from './dsa-add/dsa-add.component';
import { EducationComponent } from './education/education.component';
import { EducationAddComponent } from './education-add/education-add.component';
import { ExceptionComponent } from './exception/exception.component';
import { ExceptionAddComponent } from './exception-add/exception-add.component';
import { MaritalStatusComponent } from './marital-status/marital-status.component';
import { MaritalStatusAddComponent } from './marital-status-add/marital-status-add.component';
import { OccupationComponent } from './occupation/occupation.component';
import { OccupationAddComponent } from './occupation-add/occupation-add.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { PromocodeComponent } from './promocode/promocode.component';
import { PromocodeAddComponent } from './promocode-add/promocode-add.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RelationshipAddComponent } from './relationship-add/relationship-add.component';
import { ResidentialStatusComponent } from './residential-status/residential-status.component';
import { ResidentialStatusAddComponent } from './residential-status-add/residential-status-add.component';
import { SubCardTypeComponent } from './sub-card-type/sub-card-type.component';
import { SubCardTypeAddComponent } from './sub-card-type-add/sub-card-type-add.component';
import { CardTypeComponent } from './card-type/card-type.component';
import { CardTypeAddComponent } from './card-type-add/card-type-add.component';
import { FormsModule } from '@angular/forms';
import { PriorityComponent } from './priority/priority.component';
import { VipComponent } from './vip/vip.component';
import { AutoDebitComponent } from './auto-debit/auto-debit.component';
import { PriorityAddComponent } from './priority-add/priority-add.component';
import { VipAddComponent } from './vip-add/vip-add.component';
import { AutoDebitAddComponent } from './auto-debit-add/auto-debit-add.component';
import { BureauComponent } from './bureau/bureau.component';
import { BureauAddComponent } from './bureau-add/bureau-add.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { CustomPaginationComponent } from './custom-pagination/custom-pagination.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeAddComponent } from './employee-add/employee-add.component';
import { HttpModule } from '@angular/http';
import { MatConfirmationComponent } from './mat-confirmation/mat-confirmation.component';
import {MatDialogModule} from '@angular/material/dialog';
import { ConfirmationBoxComponent } from './confirmation-box/confirmation-box.component';




@NgModule({
  declarations: [
    AppComponent,
    MasterCompComponent,
    AccountTypeComponent,
    HomeComponent,
    AccounttypeAddComponent,
    GenderComponent,
    GenderAddComponent,
    SalutationComponent,
    SalutationAddComponent,
    ChannelComponent,
    ChannelAddComponent,
    DecisionComponent,
    DecisionAddComponent,
    DeferralComponent,
    DeferralAddComponent,
    DSAComponent,
    DSAAddComponent,
    EducationComponent,
    EducationAddComponent,
    ExceptionComponent,
    ExceptionAddComponent,
    MaritalStatusComponent,
    MaritalStatusAddComponent,
    OccupationComponent,
    OccupationAddComponent,
    ProductComponent,
    ProductAddComponent,
    PromocodeComponent,
    PromocodeAddComponent,
    RelationshipComponent,
    RelationshipAddComponent,
    ResidentialStatusComponent,
    ResidentialStatusAddComponent,
    SubCardTypeComponent,
    SubCardTypeAddComponent,
    CardTypeComponent,
    CardTypeAddComponent,
    PriorityComponent,
    VipComponent,
    AutoDebitComponent,
    PriorityAddComponent,
    VipAddComponent,
    AutoDebitAddComponent,
    BureauComponent,
    BureauAddComponent,
    CustomPaginationComponent,
    EmployeeComponent,
    EmployeeAddComponent,
    MatConfirmationComponent,
    ConfirmationBoxComponent
    //ConfirmationPopoverModule.forRoot({confirmButtonType:'danger'})
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    NgxPaginationModule,
    FormsModule,
    HttpModule,
    MatDialogModule,

    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

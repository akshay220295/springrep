import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Page } from '../Models/page';
import { Pageable } from '../Models/pageable';

@Component({
  selector: 'app-custom-pagination',
  templateUrl: './custom-pagination.component.html',
  styleUrls: ['./custom-pagination.component.css']
})
export class CustomPaginationComponent implements OnInit {

  @Input() page: Page<any>;
  @Input() pagable: Pageable;
  @Output() nextPageEvent = new EventEmitter();
  @Output() previousPageEvent = new EventEmitter();
  @Output() pageSizeEvent: EventEmitter<number> = new EventEmitter<number>();
  pgSizes: any[];
  constructor() { }

  ngOnInit() :void{
  
  }

  nextPage(): void {
    this.nextPageEvent.emit(null);
  }
 
  previousPage(): void {
    this.previousPageEvent.emit(null);
  }
 
  updatePageSize(pageSize: number): void {
    console.log(pageSize);
    
    this.pageSizeEvent.emit(pageSize);
  }

}


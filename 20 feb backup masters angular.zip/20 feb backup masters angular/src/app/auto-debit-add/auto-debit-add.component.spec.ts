import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AutoDebitAddComponent } from './auto-debit-add.component';

describe('AutoDebitAddComponent', () => {
  let component: AutoDebitAddComponent;
  let fixture: ComponentFixture<AutoDebitAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AutoDebitAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AutoDebitAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

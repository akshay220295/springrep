import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MatConfirmationComponent } from './mat-confirmation.component';

describe('MatConfirmationComponent', () => {
  let component: MatConfirmationComponent;
  let fixture: ComponentFixture<MatConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MatConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MatConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

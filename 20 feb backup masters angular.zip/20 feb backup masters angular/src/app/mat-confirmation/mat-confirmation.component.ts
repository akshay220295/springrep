import { Component, OnInit } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { addon } from '../Models/addon';
import { Router } from '@angular/router';

@Component({
  selector: 'app-mat-confirmation',
  templateUrl: './mat-confirmation.component.html',
  styleUrls: ['./mat-confirmation.component.css']
})
export class MatConfirmationComponent implements OnInit {
  allvalues: any;

  constructor(private router : Router,
    ) { 
  }
  data;
  addunModel: addon = new addon();
  page: any;
  BASEURI = 'http://localhost:8080/addOn/date/'
  http: any;
  
  ngOnInit() {  
    
    
  }

  // create(date: Date){
  //   console.log(date,"date function")
  //  let options = { headers: new HttpHeaders({ 
  //  'Content-Type': 'application/json',
  //  }) 
  //  }
  //  this.http.post(this.BASEURI, JSON.stringify(date) , options).subscribe(
  //    res => {
  //      console.log("RES " , res)
  //      if(res){
  //  this.router.navigate(["/addon"])
  //      }
  //    }
  //  )
  //  }
   httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

   getAllValues(Date:Date): void {
console.log(Date,"date function")
    
  this.http.post(this.BASEURI,JSON.stringify(Date),this.httpOptions).subscribe(
    res => {
    this.allvalues=res['data']['LIST ALL']
    console.log(this.allvalues)

    },
    err => {
      console.log("ERR" + err)
    }
  )
  }
 
  }
import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Page } from '../Models/page';
import { Pageable } from '../Models/pageable';
import { CustomPaginationService } from '../Services/custom-pagination.service';
import { bureau } from '../Models/bureau';

@Component({
  selector: 'app-bureau',
  templateUrl: './bureau.component.html',
  styleUrls: ['./bureau.component.css']
})
export class BureauComponent implements OnInit {
  page: Page<bureau> = new Page();
  pageable: Pageable = new Pageable();
 
  constructor(private http: HttpClient , private router : Router,
    private paginationService: CustomPaginationService) { 
  }
  BASEURI = 'http://localhost:8080/bureau/'
  
  private allvalues:any;
  data;
  ngOnInit() {   
    this.getAllValues() //Get Method call 
   
  }

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };

    getAllValues(): void {

      var obj={
        pageSize:this.page.pageable.pageSize,
        pageNumber:this.page.pageable.pageNumber
      }
    let url = this.BASEURI+'get'
    this.http.post<Page<bureau>>(url,JSON.stringify(obj),this.httpOptions).subscribe(
      res => {
      console.log("RESPONSE ", res)
     
      this.allvalues=res['data']['LIST ALL']
      console.log(this.allvalues)

      },
      err => {
        console.log("ERR" + err)
      }
    )
  }

  //Delete Method 
  deleterecord(id) {
    let url= this.BASEURI+'delete/';
    this.http.delete(url+id).subscribe(
      _data=>{
        this.getAllValues()
      }
    )
    }

    public getNextPage(): void {
      this.page.pageable = this.paginationService.getNextPage(this.page);
      this.getAllValues();
    }
   
    public getPreviousPage(): void {
      this.page.pageable = this.paginationService.getPreviousPage(this.page);
      this.getAllValues();
    }
   
    public getPageInNewSize(pageSize: number): void {
      this.page.pageable = this.paginationService.getPageInNewSize(this.page, pageSize);
      this.getAllValues();
    }
}

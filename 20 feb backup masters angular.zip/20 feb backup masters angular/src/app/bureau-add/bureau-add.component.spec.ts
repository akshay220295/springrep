import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BureauAddComponent } from './bureau-add.component';

describe('BureauAddComponent', () => {
  let component: BureauAddComponent;
  let fixture: ComponentFixture<BureauAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BureauAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BureauAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

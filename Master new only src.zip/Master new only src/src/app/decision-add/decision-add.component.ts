import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-decision-add',
  templateUrl: './decision-add.component.html',
  styleUrls: ['./decision-add.component.css']
})
export class DecisionAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

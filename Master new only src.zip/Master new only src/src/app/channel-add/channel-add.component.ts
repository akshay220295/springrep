import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-channel-add',
  templateUrl: './channel-add.component.html',
  styleUrls: ['./channel-add.component.css']
})
export class ChannelAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { occupation } from '../occupation';
import { Router } from '@angular/router';

@Component({
  selector: 'app-occupation',
  templateUrl: './occupation.component.html',
  styleUrls: ['./occupation.component.css']
})
export class OccupationComponent implements OnInit {

  constructor(private http: HttpClient , private router : Router) { 
    
  }
  BASEURI = 'http://localhost:8089/'
  
  allValues ;
  data;
  ngOnInit() {   
    this.getAllValues()
   
  }

  getAllValues() {
    this.http.get(this.BASEURI + "allvalues").subscribe(
      res => {
        console.log("RESPONSE ", res)
      this.allValues = res['data']['Fetched all data']
      console.log(this.allValues)
      },
      err => {
        console.log("ERR" + err)
      }
    )
  }



  // deleteRow(ocptnId){
  //   for(let i = 0; i < this.data.length; ++i){
  //       if (this.data[i].ocptnId === ocptnId) {
  //           this.data.splice(i,0);
  //       }
  //   }
}


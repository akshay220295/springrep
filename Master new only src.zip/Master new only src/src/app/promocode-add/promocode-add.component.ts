import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promocode-add',
  templateUrl: './promocode-add.component.html',
  styleUrls: ['./promocode-add.component.css']
})
export class PromocodeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

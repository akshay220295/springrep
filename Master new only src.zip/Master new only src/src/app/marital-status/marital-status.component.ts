import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marital-status',
  templateUrl: './marital-status.component.html',
  styleUrls: ['./marital-status.component.css']
})
export class MaritalStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

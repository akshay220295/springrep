import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cbil-enq-add',
  templateUrl: './cbil-enq-add.component.html',
  styleUrls: ['./cbil-enq-add.component.css']
})
export class CbilEnqAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

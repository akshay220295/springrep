import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CbilEnqAddComponent } from './cbil-enq-add.component';

describe('CbilEnqAddComponent', () => {
  let component: CbilEnqAddComponent;
  let fixture: ComponentFixture<CbilEnqAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CbilEnqAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CbilEnqAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

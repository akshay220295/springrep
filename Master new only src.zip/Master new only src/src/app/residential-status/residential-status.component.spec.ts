import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResidentialStatusComponent } from './residential-status.component';

describe('ResidentialStatusComponent', () => {
  let component: ResidentialStatusComponent;
  let fixture: ComponentFixture<ResidentialStatusComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResidentialStatusComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResidentialStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

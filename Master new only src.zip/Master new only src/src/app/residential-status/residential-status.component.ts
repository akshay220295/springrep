import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-residential-status',
  templateUrl: './residential-status.component.html',
  styleUrls: ['./residential-status.component.css']
})
export class ResidentialStatusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

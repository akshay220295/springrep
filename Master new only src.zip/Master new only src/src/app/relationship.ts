export class relationship
{
    relationshipId:number;
    relationshipName:string;
    relationshipCreatedDate:string;
    relationshipCreatedBy:string;
    relationshipModifiedDate:string;
    relationshipModifiedBy:string;
    relationshipCertifed:number;
}
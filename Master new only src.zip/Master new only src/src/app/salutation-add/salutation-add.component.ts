import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salutation-add',
  templateUrl: './salutation-add.component.html',
  styleUrls: ['./salutation-add.component.css']
})
export class SalutationAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

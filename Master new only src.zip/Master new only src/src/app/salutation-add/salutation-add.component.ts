import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { salutation } from '../salutation';

@Component({
  selector: 'app-salutation-add',
  templateUrl: './salutation-add.component.html',
  styleUrls: ['./salutation-add.component.css']
})
export class SalutationAddComponent implements OnInit {
  salutationModel;
  BASEURI = 'http://localhost:8080/salutation'
  id;
  updatingBoolean;
  constructor(private http:HttpClient, private router :Router , private route : ActivatedRoute) { 
    this.salutationModel=new salutation();
    
  }


  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params["id"];
    });
    console.log(this.id)
    if(this.id != 0){
      this.updatingBoolean = true
      this.fetchSalutationById(this.id);
     
    }
  }

  fetchSalutationById(id){
    this.http.get(this.BASEURI+id).subscribe(
      res => {
        if(res["data"]){
        this.salutationModel = res["data"]["Salutation By Id"]["body"]
        }
      }
    )
  }
  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
}) 
}
 this.http.post(this.BASEURI , JSON.stringify(this.salutationModel) , options).subscribe(
   res => {
     console.log("RES " , res)
     if(res){
this.router.navigate(["/salutation"])
     }
   }
 )

}
}

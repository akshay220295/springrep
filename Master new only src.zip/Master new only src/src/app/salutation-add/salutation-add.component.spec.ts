import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalutationAddComponent } from './salutation-add.component';

describe('SalutationAddComponent', () => {
  let component: SalutationAddComponent;
  let fixture: ComponentFixture<SalutationAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalutationAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalutationAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

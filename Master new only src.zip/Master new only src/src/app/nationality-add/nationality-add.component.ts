import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nationality-add',
  templateUrl: './nationality-add.component.html',
  styleUrls: ['./nationality-add.component.css']
})
export class NationalityAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

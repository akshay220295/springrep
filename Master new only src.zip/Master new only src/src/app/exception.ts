export class exception
{

    exceptionMstId:number;
    exceptionMstName:string;
    exceptionMstCreatedDate:string;
    exceptionMstCreatedBy:string;
    exceptionMstModifiedDate:string;
    exceptionMstModifiedBy:string;
    exceptionMstCertified:number;
    exceptionMstBankId:number;
    

}
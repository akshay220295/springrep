import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dsa',
  templateUrl: './dsa.component.html',
  styleUrls: ['./dsa.component.css']
})
export class DSAComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

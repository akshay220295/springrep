export class occupation{

    occupationId:number;
    occupationName:string;
    occupationCreatedDate:string;
    occupationCreatedBy:string;
    occupationModifiedDate:string;
    occupationModifiedBy:string;
    occupationCertified:number;
    


}
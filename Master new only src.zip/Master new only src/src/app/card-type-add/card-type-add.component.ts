import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-card-type-add',
  templateUrl: './card-type-add.component.html',
  styleUrls: ['./card-type-add.component.css']
})
export class CardTypeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

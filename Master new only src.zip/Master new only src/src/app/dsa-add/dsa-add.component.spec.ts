import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DSAAddComponent } from './dsa-add.component';

describe('DSAAddComponent', () => {
  let component: DSAAddComponent;
  let fixture: ComponentFixture<DSAAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DSAAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DSAAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

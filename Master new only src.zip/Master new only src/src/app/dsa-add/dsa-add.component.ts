import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dsa-add',
  templateUrl: './dsa-add.component.html',
  styleUrls: ['./dsa-add.component.css']
})
export class DSAAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

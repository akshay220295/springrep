import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SalesEmployeeAddComponent } from './sales-employee-add.component';

describe('SalesEmployeeAddComponent', () => {
  let component: SalesEmployeeAddComponent;
  let fixture: ComponentFixture<SalesEmployeeAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SalesEmployeeAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SalesEmployeeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

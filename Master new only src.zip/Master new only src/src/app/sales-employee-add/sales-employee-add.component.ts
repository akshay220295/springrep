import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-employee-add',
  templateUrl: './sales-employee-add.component.html',
  styleUrls: ['./sales-employee-add.component.css']
})
export class SalesEmployeeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

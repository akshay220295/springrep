import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { priority } from '../priority';

@Component({
  selector: 'app-priority-add',
  templateUrl: './priority-add.component.html',
  styleUrls: ['./priority-add.component.css']
})
export class PriorityAddComponent implements OnInit {
 priorityModel;
  BASEURI = 'http://localhost:8080/priority'
  id:number;
  updatingBoolean:boolean;
  constructor(private http: HttpClient , private router :Router , private route : ActivatedRoute) { 
    this.priorityModel = new priority();
    
  }


  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params["id"];
    });
    console.log(this.id)
    if(this.id != 0){
      this.updatingBoolean = true
      this.fetchpriorityById(this.id);
    }
  }

  fetchpriorityById(id){
    this.http.get(this.BASEURI+id).subscribe(
      res => {
        if(res["data"]){
        this.priorityModel = res["data"]["LIST ALL"]["body"]
        }
      }
    )
  }
  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
}) 
}
 this.http.post(this.BASEURI, JSON.stringify(this.priorityModel) , options).subscribe(
   res => {
     console.log("RES " , res)
     if(res){
this.router.navigate(["/priority"])
     }
   }
 )

}
}

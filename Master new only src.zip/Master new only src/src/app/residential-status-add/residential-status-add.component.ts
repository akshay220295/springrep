import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-residential-status-add',
  templateUrl: './residential-status-add.component.html',
  styleUrls: ['./residential-status-add.component.css']
})
export class ResidentialStatusAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

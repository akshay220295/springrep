import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResidentialStatusAddComponent } from './residential-status-add.component';

describe('ResidentialStatusAddComponent', () => {
  let component: ResidentialStatusAddComponent;
  let fixture: ComponentFixture<ResidentialStatusAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResidentialStatusAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResidentialStatusAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

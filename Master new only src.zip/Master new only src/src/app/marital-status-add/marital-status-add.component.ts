import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marital-status-add',
  templateUrl: './marital-status-add.component.html',
  styleUrls: ['./marital-status-add.component.css']
})
export class MaritalStatusAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

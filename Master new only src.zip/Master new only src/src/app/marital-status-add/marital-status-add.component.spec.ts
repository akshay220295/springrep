import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MaritalStatusAddComponent } from './marital-status-add.component';

describe('MaritalStatusAddComponent', () => {
  let component: MaritalStatusAddComponent;
  let fixture: ComponentFixture<MaritalStatusAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MaritalStatusAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MaritalStatusAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

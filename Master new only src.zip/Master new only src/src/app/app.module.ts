import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MasterCompComponent } from './master-comp/master-comp.component';
import { AccountTypeComponent } from './account-type/account-type.component';
import { HomeComponent } from './home/home.component';
import { AccounttypeAddComponent } from './accounttype-add/accounttype-add.component';
import { CbilEnqComponent } from './cbil-enq/cbil-enq.component';
import { CbilEnqAddComponent } from './cbil-enq-add/cbil-enq-add.component';
import { HttpClientModule } from '@angular/common/http';
import{BrowserAnimationsModule} from '@angular/platform-browser/animations';
import{MatTableModule} from '@angular/material/table';
import { GenderComponent } from './gender/gender.component';
import { GenderAddComponent } from './gender-add/gender-add.component';
import { SalutationComponent } from './salutation/salutation.component';
import { SalutationAddComponent } from './salutation-add/salutation-add.component';
import { ChannelComponent } from './channel/channel.component';
import { ChannelAddComponent } from './channel-add/channel-add.component';
import { DecisionComponent } from './decision/decision.component';
import { DecisionAddComponent } from './decision-add/decision-add.component';
import { DeferralComponent } from './deferral/deferral.component';
import { DeferralAddComponent } from './deferral-add/deferral-add.component';
import { DSAComponent } from './dsa/dsa.component';
import { DSAAddComponent } from './dsa-add/dsa-add.component';
import { EducationComponent } from './education/education.component';
import { EducationAddComponent } from './education-add/education-add.component';
import { ExceptionComponent } from './exception/exception.component';
import { ExceptionAddComponent } from './exception-add/exception-add.component';
import { MaritalStatusComponent } from './marital-status/marital-status.component';
import { MaritalStatusAddComponent } from './marital-status-add/marital-status-add.component';
import { NationalityComponent } from './nationality/nationality.component';
import { NationalityAddComponent } from './nationality-add/nationality-add.component';
import { OccupationComponent } from './occupation/occupation.component';
import { OccupationAddComponent } from './occupation-add/occupation-add.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { PromocodeComponent } from './promocode/promocode.component';
import { PromocodeAddComponent } from './promocode-add/promocode-add.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RelationshipAddComponent } from './relationship-add/relationship-add.component';
import { ResidentialStatusComponent } from './residential-status/residential-status.component';
import { ResidentialStatusAddComponent } from './residential-status-add/residential-status-add.component';
import { SalesEmployeeComponent } from './sales-employee/sales-employee.component';
import { SalesEmployeeAddComponent } from './sales-employee-add/sales-employee-add.component';
import { SubCardTypeComponent } from './sub-card-type/sub-card-type.component';
import { SubCardTypeAddComponent } from './sub-card-type-add/sub-card-type-add.component';
import { CardTypeComponent } from './card-type/card-type.component';
import { CardTypeAddComponent } from './card-type-add/card-type-add.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [
    AppComponent,
    MasterCompComponent,
    AccountTypeComponent,
    HomeComponent,
    AccounttypeAddComponent,
    CbilEnqComponent,
    CbilEnqAddComponent,
    GenderComponent,
    GenderAddComponent,
    SalutationComponent,
    SalutationAddComponent,
    ChannelComponent,
    ChannelAddComponent,
    DecisionComponent,
    DecisionAddComponent,
    DeferralComponent,
    DeferralAddComponent,
    DSAComponent,
    DSAAddComponent,
    EducationComponent,
    EducationAddComponent,
    ExceptionComponent,
    ExceptionAddComponent,
    MaritalStatusComponent,
    MaritalStatusAddComponent,
    NationalityComponent,
    NationalityAddComponent,
    OccupationComponent,
    OccupationAddComponent,
    ProductComponent,
    ProductAddComponent,
    PromocodeComponent,
    PromocodeAddComponent,
    RelationshipComponent,
    RelationshipAddComponent,
    ResidentialStatusComponent,
    ResidentialStatusAddComponent,
    SalesEmployeeComponent,
    SalesEmployeeAddComponent,
    SubCardTypeComponent,
    SubCardTypeAddComponent,
    CardTypeComponent,
    CardTypeAddComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    BrowserAnimationsModule,
    MatTableModule,
   FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

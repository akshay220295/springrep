import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-salutation',
  templateUrl: './salutation.component.html',
  styleUrls: ['./salutation.component.css']
})
export class SalutationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deferral-add',
  templateUrl: './deferral-add.component.html',
  styleUrls: ['./deferral-add.component.css']
})
export class DeferralAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DeferralAddComponent } from './deferral-add.component';

describe('DeferralAddComponent', () => {
  let component: DeferralAddComponent;
  let fixture: ComponentFixture<DeferralAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DeferralAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DeferralAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-master-comp',
  templateUrl: './master-comp.component.html',
  styleUrls: ['./master-comp.component.css']
})
export class MasterCompComponent implements OnInit {
  activeBoolean : boolean;
searchValue
  @ViewChild("liOfSidebar" , { static : true}) liOfSidebar : ElementRef;
  constructor() { }

  ngOnInit() {
    
  }
  toggleSidebar(){
    this.activeBoolean = !this.activeBoolean;
  }


  sideBarSearch(){
  if(this.searchValue.length > 0 ){
for(let i=0; i< this.liOfSidebar.nativeElement.children.length;i++ ){
  
  if(this.liOfSidebar.nativeElement.children[i].innerText.toLowerCase().indexOf(this.searchValue.toLowerCase())){    
    this.liOfSidebar.nativeElement.children[i].hidden = true
  }else{    
    this.liOfSidebar.nativeElement.children[i].hidden = false
  }
  }
  }else{
    //modify this
for(let i=0; i< this.liOfSidebar.nativeElement.children.length;i++ ){
  this.liOfSidebar.nativeElement.children[i].hidden = false 
}
  }
}

  

}

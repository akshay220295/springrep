import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MasterCompComponent } from './master-comp.component';

describe('MasterCompComponent', () => {
  let component: MasterCompComponent;
  let fixture: ComponentFixture<MasterCompComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MasterCompComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MasterCompComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

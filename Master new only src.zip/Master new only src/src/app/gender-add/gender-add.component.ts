import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gender-add',
  templateUrl: './gender-add.component.html',
  styleUrls: ['./gender-add.component.css']
})
export class GenderAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

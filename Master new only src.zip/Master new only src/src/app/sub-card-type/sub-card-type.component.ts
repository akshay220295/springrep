import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-card-type',
  templateUrl: './sub-card-type.component.html',
  styleUrls: ['./sub-card-type.component.css']
})
export class SubCardTypeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

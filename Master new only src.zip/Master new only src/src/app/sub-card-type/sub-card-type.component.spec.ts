import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubCardTypeComponent } from './sub-card-type.component';

describe('SubCardTypeComponent', () => {
  let component: SubCardTypeComponent;
  let fixture: ComponentFixture<SubCardTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubCardTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubCardTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

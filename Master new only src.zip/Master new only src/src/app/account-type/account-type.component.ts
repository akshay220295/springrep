import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-account-type',
  templateUrl: './account-type.component.html',
  styleUrls: ['./account-type.component.css']
})
export class AccountTypeComponent implements OnInit {
  // elements: any = [];
  // headElements = ['id', 'first', 'last', 'handle'];

  constructor() { }

  ngOnInit() {

    // for (let i = 1; i <= 15; i++) {
    //   this.elements.push({ id: i, first: 'User ' + i, last: 'Name ' + i, handle: 'Handle ' + i });
    // }
  }

}

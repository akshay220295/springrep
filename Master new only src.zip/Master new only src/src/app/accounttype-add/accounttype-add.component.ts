import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accounttype-add',
  templateUrl: './accounttype-add.component.html',
  styleUrls: ['./accounttype-add.component.css']
})
export class AccounttypeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

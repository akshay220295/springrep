import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-card-type-add',
  templateUrl: './sub-card-type-add.component.html',
  styleUrls: ['./sub-card-type-add.component.css']
})
export class SubCardTypeAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubCardTypeAddComponent } from './sub-card-type-add.component';

describe('SubCardTypeAddComponent', () => {
  let component: SubCardTypeAddComponent;
  let fixture: ComponentFixture<SubCardTypeAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubCardTypeAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubCardTypeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

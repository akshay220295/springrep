import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-education-add',
  templateUrl: './education-add.component.html',
  styleUrls: ['./education-add.component.css']
})
export class EducationAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

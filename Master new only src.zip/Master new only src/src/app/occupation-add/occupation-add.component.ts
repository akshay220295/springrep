import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-occupation-add',
  templateUrl: './occupation-add.component.html',
  styleUrls: ['./occupation-add.component.css']
})
export class OccupationAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

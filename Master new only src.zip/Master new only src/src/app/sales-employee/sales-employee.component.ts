import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sales-employee',
  templateUrl: './sales-employee.component.html',
  styleUrls: ['./sales-employee.component.css']
})
export class SalesEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cbil-enq',
  templateUrl: './cbil-enq.component.html',
  styleUrls: ['./cbil-enq.component.css']
})
export class CbilEnqComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CbilEnqComponent } from './cbil-enq.component';

describe('CbilEnqComponent', () => {
  let component: CbilEnqComponent;
  let fixture: ComponentFixture<CbilEnqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CbilEnqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CbilEnqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

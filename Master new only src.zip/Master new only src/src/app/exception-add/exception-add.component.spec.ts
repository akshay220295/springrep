import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExceptionAddComponent } from './exception-add.component';

describe('ExceptionAddComponent', () => {
  let component: ExceptionAddComponent;
  let fixture: ComponentFixture<ExceptionAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExceptionAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExceptionAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

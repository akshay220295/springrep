import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-exception-add',
  templateUrl: './exception-add.component.html',
  styleUrls: ['./exception-add.component.css']
})
export class ExceptionAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

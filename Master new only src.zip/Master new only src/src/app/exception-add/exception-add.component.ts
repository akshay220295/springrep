import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { NgForm } from '@angular/forms';
import { exception } from '../exception';

@Component({
  selector: 'app-exception-add',
  templateUrl: './exception-add.component.html',
  styleUrls: ['./exception-add.component.css']
})
export class ExceptionAddComponent implements OnInit {

 exceptionModel;
  BASEURI = 'http://localhost:8080/exception'
  id;
  updatingBoolean;
  constructor(private http:HttpClient, private router :Router , private route : ActivatedRoute) { 
    this.exceptionModel=new exception();
    
  }


  ngOnInit() {
    this.route.params.subscribe(params => {
      this.id = params["id"];
    });
    console.log(this.id)
    if(this.id != 0){
      this.updatingBoolean = true
      this.fetchexceptionById(this.id);
     
    }
  }

  fetchexceptionById(id){
    this.http.get(this.BASEURI+id).subscribe(
      res => {
        if(res["data"]){
        this.exceptionModel = res["data"]["REQUESTED VALUE"]["body"]
        }
      }
    )
  }
  
create(form :NgForm){
  if(!form.valid){
    return
  }  
console.log("Creating")
let options = { headers: new HttpHeaders({ 
 'Content-Type': 'application/json',
}) 
}
 this.http.post(this.BASEURI , JSON.stringify(this.exceptionModel) , options).subscribe(
   res => {
     console.log("RES " , res)
     if(res){
this.router.navigate(["/exception"])
     }
   }
 )

}
}

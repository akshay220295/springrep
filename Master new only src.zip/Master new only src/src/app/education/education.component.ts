import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent implements OnInit {
  constructor(private http: HttpClient , private router :Router) { 
    
  }
  BASEURI = 'http://localhost:8080/education/'
  
  allValues ;
  data;
  ngOnInit() {   
    this.getAllValues()
   
  }

  getAllValues() {
    this.http.get(this.BASEURI).subscribe(
      res => {
        console.log("RESPONSE ", res)
      this.allValues = res['data']['LIST ALL']
      console.log(this.allValues)
      },
      err => {
        console.log("ERR" + err)
      }
    )
  }



  // deleteRow(ocptnId){
  //   for(let i = 0; i < this.data.length; ++i){
  //       if (this.data[i].ocptnId === ocptnId) {
  //           this.data.splice(i,0);
  //       }
  //   }
}

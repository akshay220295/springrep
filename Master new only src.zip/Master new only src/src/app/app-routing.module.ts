import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MasterCompComponent } from './master-comp/master-comp.component';
import {AccountTypeComponent} from './account-type/account-type.component'
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AccounttypeAddComponent } from './accounttype-add/accounttype-add.component';
import { CbilEnqComponent } from 'src/app/cbil-enq/cbil-enq.component'
import { CbilEnqAddComponent } from './cbil-enq-add/cbil-enq-add.component';
import{GenderComponent} from './gender/gender.component';
import{GenderAddComponent} from './gender-add/gender-add.component';
import{SalutationComponent} from './salutation/salutation.component';
import {SalutationAddComponent} from './salutation-add/salutation-add.component';
import {ChannelComponent} from './channel/channel.component';
import {ChannelAddComponent} from './channel-add/channel-add.component';
import {DecisionComponent} from './decision/decision.component';
import { DecisionAddComponent } from './decision-add/decision-add.component';
import { DeferralComponent } from './deferral/deferral.component';
import { DeferralAddComponent } from './deferral-add/deferral-add.component';
import { EducationComponent } from './education/education.component';
import { EducationAddComponent } from './education-add/education-add.component';
import { ExceptionComponent } from './exception/exception.component';
import { ExceptionAddComponent } from './exception-add/exception-add.component';
import { MaritalStatusComponent } from './marital-status/marital-status.component';
import { MaritalStatusAddComponent } from './marital-status-add/marital-status-add.component';
import { NationalityComponent } from './nationality/nationality.component';
import { NationalityAddComponent } from './nationality-add/nationality-add.component';
import { OccupationComponent } from './occupation/occupation.component';
import { OccupationAddComponent } from './occupation-add/occupation-add.component';
import { ProductComponent } from './product/product.component';
import { ProductAddComponent } from './product-add/product-add.component';
import { PromocodeComponent } from './promocode/promocode.component';
import { PromocodeAddComponent } from './promocode-add/promocode-add.component';
import { RelationshipComponent } from './relationship/relationship.component';
import { RelationshipAddComponent } from './relationship-add/relationship-add.component';
import { ResidentialStatusComponent } from './residential-status/residential-status.component';
import { ResidentialStatusAddComponent } from './residential-status-add/residential-status-add.component';
import { SalesEmployeeComponent } from './sales-employee/sales-employee.component';
import { SalesEmployeeAddComponent } from './sales-employee-add/sales-employee-add.component';
import { SubCardTypeComponent } from './sub-card-type/sub-card-type.component';
import { SubCardTypeAddComponent } from './sub-card-type-add/sub-card-type-add.component';
import { CardTypeComponent } from './card-type/card-type.component';
import { CardTypeAddComponent } from './card-type-add/card-type-add.component';
import { DSAAddComponent } from './dsa-add/dsa-add.component';
import { DSAComponent } from './dsa/dsa.component';






const routes: Routes = [
  {path : '' , component : HomeComponent},
  {path:'masterComp',component:MasterCompComponent},
{path:'AccountType', component:AccountTypeComponent},
{path:'AccountTypeAdd',component:AccounttypeAddComponent},
{path:'cardType',component:CardTypeComponent},
{path:'cardTypeAdd',component:CardTypeAddComponent},
{path:'cbilEnquiry', component:CbilEnqComponent},
{path:'cbilEnquiryAdd',component:CbilEnqAddComponent},
{path:'gender',component:GenderComponent},
{path:'genderAdd',component:GenderAddComponent},
{path:'salutation',component:SalutationComponent},
{path:'salutationAdd',component:SalutationAddComponent},
{path:'channel',component:ChannelComponent},
{path:'channelAdd',component:ChannelAddComponent},
{path:'decision',component:DecisionComponent},
{path:'decisionAdd',component:DecisionAddComponent},
{path:'deferral',component:DeferralComponent},
{path:'deferralAdd',component:DeferralAddComponent},
{path:'dsa',component:DSAComponent},
{path:'dsaAdd',component:DSAAddComponent},
{path:'education',component:EducationComponent},
{path:'educationAdd',component:EducationAddComponent},
{path:'exception',component:ExceptionComponent},
{path:'exceptionAdd',component:ExceptionAddComponent},
{path:'maritalStatus',component:MaritalStatusComponent},
{path:'maritalStatusAdd',component:MaritalStatusAddComponent},
{path:'nationality',component:NationalityComponent},
{path:'nationalityAdd',component:NationalityAddComponent},
{path:'occupation',component:OccupationComponent},
{path:'occupationAdd',component:OccupationAddComponent},
{path:'product',component:ProductComponent},
{path:'productAdd',component:ProductAddComponent},
{path:'promoCode',component:PromocodeComponent},
{path:'promoCodeAdd',component:PromocodeAddComponent},
{path:'relationship',component:RelationshipComponent},
{path:'relationshipAdd',component:RelationshipAddComponent},
{path:'residentialStatus',component:ResidentialStatusComponent},
{path:'residentialStatusAdd',component:ResidentialStatusAddComponent},
{path:'salesEmployee',component:SalesEmployeeComponent},
{path:'salesEmployeeAdd',component:SalesEmployeeAddComponent},
{path:'subCardType',component:SubCardTypeComponent},
{path:'subCardTypeAdd',component:SubCardTypeAddComponent}




];
              

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

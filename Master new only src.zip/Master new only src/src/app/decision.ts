export class decision{

    decisionId:number;
    decisionName:string;
    decisionCreatedDate:string;
    decisionCreatedBy:string;
    decisionModifiedDate:string;
    decisionModifiedBy:string;
    decisionCertified:number;

}
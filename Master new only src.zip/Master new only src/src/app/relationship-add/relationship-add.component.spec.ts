import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelationshipAddComponent } from './relationship-add.component';

describe('RelationshipAddComponent', () => {
  let component: RelationshipAddComponent;
  let fixture: ComponentFixture<RelationshipAddComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelationshipAddComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelationshipAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

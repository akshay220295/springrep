import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-relationship-add',
  templateUrl: './relationship-add.component.html',
  styleUrls: ['./relationship-add.component.css']
})
export class RelationshipAddComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

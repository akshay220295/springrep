import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-deferral',
  templateUrl: './deferral.component.html',
  styleUrls: ['./deferral.component.css']
})
export class DeferralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

$(document).ready(function(){
    $(".datepicker").datepicker({
        daysOfWeekDisabled: "1",
        autoclose: true,
        todayHighlight: true
    });
    // To style only selects with the my-select class
    $('select').selectpicker();
});
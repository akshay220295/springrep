package com.isg.gcms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GcmsApplicationTests {

	@Test
	void contextLoads() {
	}

}

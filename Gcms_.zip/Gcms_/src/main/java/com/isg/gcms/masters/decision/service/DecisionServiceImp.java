package com.isg.gcms.masters.decision.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.decision.dao.DecisionDao;
import com.isg.gcms.masters.decision.dao.DecisionTrailDao;
import com.isg.gcms.masters.decision.dto.DecisnUpdateDTO;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.model.DecisionTrail;

@Service
public class DecisionServiceImp implements DecisionService{
	
	@Autowired
	private DecisionDao decisnDao;
	
	@Autowired
	private DecisionTrailDao decisnTrlDao;
	
	@Autowired
	private ResponseObj res;

	@Override
	public ResponseObj getAllDecision(PaginationModel pagination) 
	{
		res.addData("LIST ALL", this.decisnDao.findAllByPagination(pagination.pageRequest()));
		return res;
	}

	@Override
	public Optional<Decision> findById(Long id)
	{
		return this.decisnDao.findById(id);
	}
	

	@Override
	public ResponseObj getById(Long id) {
		Optional<Decision> decision = this.findById(id);
		if(decision.isPresent() && decision.get().getDecisionCertified() == 0)
		{
			res.addData("REQUESTED VALUE", ResponseDTO.accepted().convertTo(decision.get(), DecisnUpdateDTO.class ));
		}
		else
		{
			res.setActionError("Id " + id + "  not found :");
		}
		return res;
	}
	
	public Optional<Decision> getByName(String name) {
		return decisnDao.findBydecisionNameEqualsIgnoreCase(name);
	}

	@Override
	public ResponseObj findByName(String name) {
		Optional<Decision> decision = this.getByName(name);
		if (decision.isPresent() && decision.get().getDecisionCertified() == 0) {
			res.addData("VALUE FETCHED", ResponseDTO.accepted().convertTo(decision.get(), DecisnUpdateDTO.class));
		} else {
			res.setActionError("Name: " + name + " not found");
		}
		return res;
	}
	


	@Override
	public ResponseObj create(@RequestBody Decision decision) 
	{
		decision.setDecisionCertified(1);
		decision.setDecisionCreatedBy("adi");  //JWT orSession
		
		Decision decisn = this.decisnDao.save(decision);
		saveDecisionTrail(decisn,"DECISION CREATED","NEW" );
		res.addData("SAVED DECISION", decisn);
		return res;
	
	}

	@Override
	public ResponseObj deleteById(Long id) {
		Optional<Decision> decision = this.findById(id);
		if (decision.isPresent() && decision.get().getDecisionCertified() == 0) 
		{
			Decision decisnEx = decision.get();
			decisnEx.setDecisionCertified(1);
			saveDecisionTrail(decisnEx,"DECISION DELETED","DELETE" );
			this.decisnDao.save(decisnEx);
			res.setMsg("VALUE DELETED", ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError("Id " + id + "  not found :");
		}
		return res;
	}
	

	@Override
	public ResponseObj updateDecisn(Decision decision) 
	{
		Optional<Decision> decisnOld = findById(decision.getDecisionId());
		if (decisnOld.isPresent() && decisnOld.get().getDecisionCertified() == 0)
		{
			Decision decisnEx = decisnOld.get();
			decisnEx.setDecisionCertified(1);
			this.decisnDao.save(decisnEx);
			saveDecisionTrail(decision,"DECISION DELETED","DELETE" );
			res.addData("VALUE UPDATED", decision );
		}
		else
		{
			res.setActionError("Id:" + decision.getDecisionId() + "not found");
		}
		
		return res;
	}
	
	public void saveDecisionTrail(Decision decision, String remark, String action) {
		DecisionTrail decisnTrail = (DecisionTrail) ResponseDTO.accepted().convertToEntity(decision,
				DecisionTrail.class);
		decisnTrail.setDecision(decision);
		decisnTrail.setDecisionCreatedBy("adi"); //JWT OR Session
		decisnTrail.setDecisionAction(action);
		decisnTrail.setDecisionCertifed(1);
		decisnTrail.setDecisionRemark(remark);

		this.decisnTrlDao.save(decisnTrail);
	}
	
//	public ResponseObj getstatus(String status)
//	{
//		if(status == "active")
//		{
//			
//		}
//		return res;
//	}

}

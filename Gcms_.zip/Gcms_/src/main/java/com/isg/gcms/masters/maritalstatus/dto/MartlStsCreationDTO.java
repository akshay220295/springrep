package com.isg.gcms.masters.maritalstatus.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class MartlStsCreationDTO {
	
	private String maritalStatusName;

	@JsonIgnore
	private final Date maritalStatusCreatedDate = new Date();
}

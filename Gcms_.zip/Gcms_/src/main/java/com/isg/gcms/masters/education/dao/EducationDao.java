package com.isg.gcms.masters.education.dao;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.education.model.Education;


@Repository
public interface EducationDao extends JpaRepository <Education, Long>
{
	public Optional<Education> findByEducationNameEqualsIgnoreCase(String name);
	
	@Query("SELECT M FROM Education M WHERE M.educationCertified!=2")
	public Page<Education> findAllByPagination(Pageable pageable);
	

}

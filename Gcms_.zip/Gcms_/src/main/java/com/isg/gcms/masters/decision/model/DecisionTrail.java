package com.isg.gcms.masters.decision.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
@Table(name = "GCMS_DECISION_TRAIL")
public class DecisionTrail 
{
	@Id
	@Column( name= "DECISN_TRAIL_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long decisionTrailId;
	
	@ManyToOne
	@JoinColumn(name = "DECISN_ID" , referencedColumnName= "DECISN_ID" )
	private Decision decision;
	
	@Column (name = "DECISN_NAME")
	private String decisionName;
	
	@Column (name = "DECISN_CRT_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String decisionCreatedDate;
	
	@Column (name = "DECISN_CRT_BY")
	private String decisionCreatedBy;
	
	@Column (name = "DECISN_MOD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String decisionModifiedDate;
	
	@Column (name = "DECISN_MOD_BY")
	private String decisionModifiedBy;
	
	@Column (name = "DECISN_CERT")
	private Integer decisionCertifed;
	
	@Column (name = "DECISN_CERT_MODE")
	private Integer decisionCertMode;
	
	@Column (name = "DECISN_ACT")
	private String decisionAction;
	
	@Column (name = "DECISN_RMRK")
	private String decisionRemark;

}

package com.isg.gcms.masters.occupation.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.dao.OccupationDao;
import com.isg.gcms.masters.occupation.dao.OccupationTrailDao;
import com.isg.gcms.masters.occupation.dto.OcptnCreationDTO;
import com.isg.gcms.masters.occupation.dto.OcptnUpdateDTO;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.model.OccupationTrail;

@Service
public class OccupationServiceImp implements OccupationService
{
	@Autowired
	private OccupationDao ocptnDao;
	
	@Autowired
	private OccupationTrailDao ocptnTrlDao;
	
	@Autowired
	private ResponseObj res;

	@Override
	public ResponseObj getAllOcptn(PaginationModel pagination)
	{
		res.addData("LIST ALL", this.ocptnDao.findAllByPagination(pagination.pageRequest()));
		return res;
		
	}

	public Optional<Occupation> findOccuById(Long id)
	{
		return this.ocptnDao.findById(id);
		
	}

	@Override
	public ResponseObj getById(Long id) 
	{
		
		Optional<Occupation> occupation = findOccuById(id);
		if(occupation.isPresent() && occupation.get().getOccupationCertified() == 0)
		{
			res.addData("Requested value", ResponseDTO.accepted().convertTo(occupation.get(),OcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError("Id not found");
		}
		return res;
	}

	

	@Override
	public ResponseObj findByName(String username) 
	{
		Optional<Occupation> occupation = findByOccuName(username);
		if(occupation.isPresent() && occupation.get().getOccupationCertified()==0)
		{
			res.addData("list of names are fetched", ResponseDTO.accepted().convertTo(occupation.get(), OcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError("name not found");
		}
		return res;
	}
	
	public Optional<Occupation> findByOccuName(String username)
	{
		return this.ocptnDao.findByoccupationNameEqualsIgnoreCase(username);
	}
	
	@Override
	public ResponseObj create(@RequestBody Occupation occupation) 
	{
		occupation.setOccupationCertified(1);
		Occupation occu=this.ocptnDao.save(occupation);
		res.addData("Save Occupation", occu );
		saveOcptnTrail(occupation , "Occupation reated" , "NEW");
		return res;
	}

	

	@Override
	public ResponseObj deleteById(Long id)
	{
		Optional<Occupation> occupation = findOccuById(id);
		if(occupation.isPresent() && occupation.get().getOccupationCertified() == 0)
		{
			Occupation occupationEx = occupation.get();
			occupationEx.setOccupationCertified(1);
			saveOcptnTrail(occupationEx , "Occupation deleted" , "DELETE");
			this.ocptnDao.save(occupationEx);
			res.setMsg("value deletd", ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError("Given Occupation id" + id + "not found");
		}
		return res;
	}

	@Override
	public ResponseObj updateOcptn(Occupation occupation)
	{
		
		Optional<Occupation> occupationOld = findOccuById(occupation.getOccupationId());
		
		if(occupationOld.isPresent() && occupation.getOccupationCertified()==0)
		{
			
			Occupation ocptnExisting = occupationOld.get();
			ocptnExisting.setOccupationCertified(1);
			this.ocptnDao.save(ocptnExisting);
			
			saveOcptnTrail(occupation , "Occupation updeted" , "MODIFY");
			res.addData("Occupation updated", occupation);
		}
		else
		{
			res.setActionError("Occupation id  " + occupation.getOccupationId() + "  not fornd");
		}
		return res;
	}
	
	public void saveOcptnTrail(Occupation occupation, String remark , String action)
	{
		OccupationTrail ocptnTrail =  (OccupationTrail) ResponseDTO.accepted().convertToEntity(occupation, OccupationTrail.class);
		ocptnTrail.setOccupation(occupation);
		ocptnTrail.setOccupationCreatedBy("adi");   //JWT
		ocptnTrail.setOccupationAction(action);  
		ocptnTrail.setOccupationCertified(1);
		ocptnTrail.setOccupationRemark(remark);
		
		this.ocptnTrlDao.save(ocptnTrail);
	}

}

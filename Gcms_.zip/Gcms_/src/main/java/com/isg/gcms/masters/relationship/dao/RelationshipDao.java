package com.isg.gcms.masters.relationship.dao;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.relationship.model.Relationship;

@Repository
public interface RelationshipDao extends JpaRepository<Relationship, Long>
{
	public Optional<Relationship> findByrelationshipNameEqualsIgnoreCase(String name);
	
	@Query ("SELECT M FROM Relationship M WHERE M.relationshipCertified!=2")
	public Page<Relationship> findAllByPagination(Pageable pageable);
}

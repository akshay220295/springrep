package com.isg.gcms.common.pagination;

import java.util.Optional;

import javax.validation.constraints.NotNull;

import org.springframework.data.domain.Sort.Direction;

public class SortingModel {

	@NotNull(message = "{invalidSortDir}")
	private Direction dir = null;
	private String prop;

	public SortingModel() {
		super();
	}

	public Direction getDir() {
		return dir;
	}

	public void setDir(String dir) {
		Optional<Direction> optional = Direction.fromOptionalString(dir);
		if (optional.isPresent())
			this.dir = optional.get();
	}

	public String getProp() {
		return prop;
	}

	public void setProp(String prop) {
		this.prop = prop;
	}

	@Override
	public String toString() {
		return "{SortingModel: {dir:" + dir + ", prop:" + prop + "}}";
	}
}

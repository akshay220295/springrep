package com.isg.gcms.masters.relationship.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relationship.dto.RltnCreationDTO;
import com.isg.gcms.masters.relationship.dto.RltnUpdateDTO;
import com.isg.gcms.masters.relationship.model.Relationship;
import com.isg.gcms.masters.relationship.service.RelationshipService;

@RestController
@RequestMapping("/relationship")
@CrossOrigin
public class RelationshipController
{
	@Autowired
	private	RelationshipService rltnService;
	
	@GetMapping
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		return this.rltnService.getAllRltn(pagination);
	}
	
	@GetMapping( value = "/{id}")
	public ResponseObj getRltnById(@PathVariable("id") Long id)
	
	{
		
		return this.rltnService.getById(id);
	}
	
	@GetMapping( value = "/name/{name}")
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.rltnService.findByName(name);
	}
	
	@PostMapping
	public ResponseObj create(@RequestDTO(RltnCreationDTO.class) @Validated Relationship relation)
	{
		return this.rltnService.create(relation);
	}
	
	@DeleteMapping (value = "/{id}")
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.rltnService.deleteById(id);
	}
	
	@PutMapping 
	public ResponseObj update(@RequestDTO(RltnUpdateDTO.class) @Validated Relationship relation)
	{
		
		return this.rltnService.updateRltn(relation);
	}

}

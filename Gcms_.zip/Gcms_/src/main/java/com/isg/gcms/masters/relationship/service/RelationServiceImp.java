package com.isg.gcms.masters.relationship.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relationship.dao.RelationshipDao;
import com.isg.gcms.masters.relationship.dao.RelationshipTrailDao;
import com.isg.gcms.masters.relationship.dto.RltnUpdateDTO;
import com.isg.gcms.masters.relationship.model.Relationship;
import com.isg.gcms.masters.relationship.model.RelationshipTrail;

@Service
public class RelationServiceImp implements RelationshipService 
{
	@Autowired
	private RelationshipDao rltnDao;
	
	@Autowired
	private RelationshipTrailDao rltnTrlDao;
	
	@Autowired
	private ResponseObj res; 

	@Override
	public ResponseObj getAllRltn(PaginationModel pagination) 
	{
		res.addData("LIST ALL", this.rltnDao.findAllByPagination(pagination.pageRequest()));
		return res;
	}
	
	@Override
	public Optional<Relationship> findById(Long id) 
	{

		return this.rltnDao.findById(id);
	}
	
	@Override
	public ResponseObj getById(Long id) {
		Optional<Relationship> rltn = this.findById(id);
		if (rltn.isPresent() && rltn.get().getRelationshipCertified() == 0)
		{
			res.addData("REQUESTED VALUE", ResponseDTO.accepted().convertTo(rltn.get(), RltnUpdateDTO.class));
		} else {
			res.setActionError("Id " + id + "  not found :");
		}
		return res;
	}
	
	public Optional<Relationship> getByName(String name) {
		return rltnDao.findByrelationshipNameEqualsIgnoreCase(name);
	}
	
	@Override
	public ResponseObj findByName(String name) {
		Optional<Relationship> rltn = this.getByName(name);
		if (rltn.isPresent() && rltn.get().getRelationshipCertified() == 0) {
			res.addData("VALUE FETCHED", ResponseDTO.accepted().convertTo(rltn.get(), RltnUpdateDTO.class));
		} else {
			res.setActionError("Name: " + name + " not found");
		}
		return res;
	}

	@Override
	public ResponseObj create(Relationship relation) {
		relation.setRelationshipCertified(1);
		relation.setRelationshipCreatedBy("Aditya"); // To Do -- will be replaced by JWT token or any other
															
		Relationship rltn = this.rltnDao.save(relation);
		saveRltnTrail(rltn, " RELATION CREATED ", "NEW");
		res.addData("saved martlsts", rltn);
		return res;
	}

	
	@Override
	public ResponseObj updateRltn(Relationship relation) {
		Optional<Relationship> rltnOld = findById(relation.getRelationshipId());
		
		if(rltnOld.isPresent() && rltnOld.get().getRelationshipCertified() == 0)
		{
			Relationship rltnEx = rltnOld.get();
			rltnEx.setRelationshipCertified(1);
			this.rltnDao.save(rltnEx);
			saveRltnTrail(relation, "RELATION UPDATED" , "MODIFY" );
			res.addData("VALUE UPDATED", relation);
		}
		else
		{
			res.setActionError("Id:"+ relation.getRelationshipId() + "not found");
		}
		
		
		return res;
	}

	@Override
	public ResponseObj deleteById(Long id) {
		Optional<Relationship> rltn = this.findById(id);
		
		if(rltn.isPresent() && rltn.get().getRelationshipCertified() == 0)
		{
			Relationship rltnEx = rltn.get();
			rltnEx.setRelationshipCertified(1);
			saveRltnTrail(rltnEx,"RELATION DELETED","DELETED");
			this.rltnDao.save(rltnEx);
			res.setMsg("VALUE DELETED", ResponseMsgType.SUCCESS);
			}
		else
		{
			res.setActionError("Id:" + id + "Not found");
		}
	return res;
	}

	
	
	public void saveRltnTrail(Relationship relation, String remark, String action) {
		RelationshipTrail rltnTrail = (RelationshipTrail) ResponseDTO.accepted().convertToEntity(relation,RelationshipTrail.class);
		rltnTrail.setRelation(relation);
		rltnTrail.setRelationshipCreatedBy("adi");
		rltnTrail.setRelationshipAction(action);
		rltnTrail.setRelationshipCertified(1);;
		rltnTrail.setRelationshipRemark(remark);

		this.rltnTrlDao.save(rltnTrail);
	}

}

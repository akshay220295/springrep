package com.isg.gcms.masters.education.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class EducationUpdateDTO 
{

	@Id
    @NotNull
    private Long educationId;
	private String educationName;
	
	@JsonIgnore
    private final Date educationModifiedDate = new Date();
}

package com.isg.gcms.masters.exception.dao;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.occupation.model.Occupation;

@Repository
public interface ExceptionDao extends JpaRepository<ExceptionMst, Long> {

	public Optional<ExceptionMst> findByexceptionMstNameEqualsIgnoreCase(String username);
	
	@Query("SELECT M FROM ExceptionMst M WHERE M.exceptionMstCertified!=2")
	public Page<Occupation>  findAllByPagination(Pageable pageable);
	
}

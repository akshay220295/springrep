package com.isg.gcms.masters.maritalstatus.service;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusDao;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusTrailDao;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsUpdateDTO;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;

@Service
public class MaritalStatusServiceImp implements MaritalStatusService {
	@Autowired
	private ResponseObj res;

	@Autowired
	private MaritalStatusDao mrtlStsDao;

	@Autowired
	private MaritalStatusTrailDao mrtlStsTrlDao;

	@Override
	public ResponseObj getAllMartlSts(PaginationModel pagination) {

		res.addData("List All", this.mrtlStsDao.findAllByPagination(pagination.pageRequest()));
		
		return res;
	}

	@Override
	public Optional<MaritalStatus> findById(Long id) {
		return this.mrtlStsDao.findById(id);

	}

	@Override
	public ResponseObj getById(Long id) {
		Optional<MaritalStatus> martlsts = this.findById(id);

		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			res.addData("Requested value", ResponseDTO.accepted().convertTo(martlsts.get(), MartlStsUpdateDTO.class));
		} else {
			res.setActionError("Id " + id + "  not found :");
		}
		return res;
	}

	public Optional<MaritalStatus> getByName(String username) {
		return mrtlStsDao.findByMaritalStatusNameEqualsIgnoreCase(username);
	}

	@Override
	public ResponseObj findByName(String username) {
		Optional<MaritalStatus> martlsts = this.getByName(username);
		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			res.addData("Value Fetched", ResponseDTO.accepted().convertTo(martlsts.get(), MartlStsUpdateDTO.class));
		} else {
			res.setActionError("Name: " + username + " not found");
		}
		return res;
	}

	@Override
	public ResponseObj create(@RequestBody MaritalStatus maritalstatus) {
		maritalstatus.setMaritalStatusCertified(1);
		maritalstatus.setMaritalStatusCreatedby("Aditya"); // To Do -- will be replaced by JWT token or any other
															// session objects.
		MaritalStatus martlsts = this.mrtlStsDao.save(maritalstatus);
		saveMartlstsTrail(martlsts, " MARITAL STATUS CREATED ", "NEW");
		res.addData("saved martlsts", martlsts);
		return res;
	}

	@Override
	public ResponseObj updateMartlSts(MaritalStatus maritalstatus) {
		Optional<MaritalStatus> martlstsOld = findById(maritalstatus.getMaritalStatusId());
		
		if (martlstsOld.isPresent() && martlstsOld.get().getMaritalStatusCertified() == 0) {
			MaritalStatus MaritalStatusEx = martlstsOld.get();
			MaritalStatusEx.setMaritalStatusCertified(1);
			this.mrtlStsDao.save(MaritalStatusEx);
			saveMartlstsTrail(maritalstatus, "MARITAL STATUS UPDATED", "MODIFY");
			res.addData("value updated", maritalstatus);
		} else {
			res.setActionError("Id:" + maritalstatus.getMaritalStatusId() + "not found");
		}

		return res;
	}

	@Override
	public ResponseObj deleteById(Long id) {
		Optional<MaritalStatus> martlsts = this.findById(id);
		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			MaritalStatus martlstsEx = martlsts.get();
			martlstsEx.setMaritalStatusCertified(1);
			saveMartlstsTrail(martlstsEx, " MARITAL STATUS DELETED ", "DELETED");
			this.mrtlStsDao.save(martlstsEx);
			res.setMsg("value deleted", ResponseMsgType.SUCCESS);
		} else {
			res.setActionError("Id " + id + "  not found :");
		}
		return res;
	}

	public void saveMartlstsTrail(MaritalStatus maritalstatus, String remark, String action) {
		MaritalStatusTrail martlstsTrail = (MaritalStatusTrail) ResponseDTO.accepted().convertToEntity(maritalstatus,
				MaritalStatusTrail.class);
		martlstsTrail.setMartialstatus(maritalstatus);
		martlstsTrail.setMaritalStatusCreatedBy("adi");
		martlstsTrail.setMaritalStatusAction(action);
		martlstsTrail.setMaritalStatusCertified(1);
		martlstsTrail.setMaritalStatusRemark(remark);

		this.mrtlStsTrlDao.save(martlstsTrail);
	}

}

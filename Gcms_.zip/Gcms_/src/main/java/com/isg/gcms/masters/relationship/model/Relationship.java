package com.isg.gcms.masters.relationship.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "GCMS_RELATION")
public class Relationship {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "RLTN_ID")
	private Long relationshipId;
	
	@Column (name = "RLTN_NAME")
	private String relationshipName;
	
	@Column (name = "RLTN_CRT_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String relationshipCreatedDate;
	
	@Column (name = "RLTN_CRT_BY")
	private String relationshipCreatedBy;
	
	@Column (name = "RLTN_MOD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String relationshipModifiedDate;
	
	@Column (name = "RLTN_MOD_BY")
	private String relationshipModifiedBy;
	
	@Column (name = "RLTN_CERT")
	private Integer relationshipCertified;
	
}

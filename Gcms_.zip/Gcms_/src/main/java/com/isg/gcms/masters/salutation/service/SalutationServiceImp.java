package com.isg.gcms.masters.salutation.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.salutation.dao.SalutationDao;
import com.isg.gcms.masters.salutation.dao.SalutationTrailDao;
import com.isg.gcms.masters.salutation.dto.SalutationUpdateDTO;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.model.SalutationTrail;

@Service
public class SalutationServiceImp implements SalutationService{
	
	@Autowired
	private SalutationTrailDao salutationTrailDao;
	
	@Autowired
	SalutationDao salutationdao;
	
	@Autowired
	ResponseObj res;
	
	
	public Optional<Salutation> findBySaltnId(Long saltnId) 
	{
		
		return this.salutationdao.findById(saltnId);

	}
	
	@Override
	public ResponseObj getAllSaltn(PaginationModel pagination) 
	{
		
		System.out.println(pagination);
		res.addData("LIST ALL", this.salutationdao.findAllByPagination(pagination.pageRequest()));
		System.out.println(res);
		return res;
	}
	
	
	
	

	@Override
	public ResponseObj getById(Long saltnId) 
	{
		
		Optional<Salutation> salutation= this.salutationdao.findById(saltnId);
		if(salutation.isPresent() && salutation.get().getSalutationCertified()==0)
		{
			res.addData("Salutation By Id",ResponseDTO.accepted().convertTo(salutation.get(), SalutationUpdateDTO.class));
		}
		else
		{
			res.setActionError("Salutation Not Found for this Id" + saltnId);
		}
		
		return res;
		
		
	}
	
	
	
	@Override
	public ResponseObj getByName(String name) 
	{
		
		Optional<Salutation> salutation=this.salutationdao.findBySalutationNameEqualsIgnoreCase(name);
		
		if(salutation.isPresent() && salutation.get().getSalutationCertified()==0)
		{
			res.addData("Salutation for this Name",ResponseDTO.accepted().convertTo(salutation.get(), SalutationUpdateDTO.class ) );
		}
		else
		{
			res.setActionError("salutation for this name not found");
		}
		
		return res;
	}



	@Override
	public Optional<Salutation> findbySalutationName(String saltnName) 
	{
		return this.salutationdao.findBySalutationNameEqualsIgnoreCase(saltnName);

	}
	
	@Override
	public ResponseObj create(@RequestBody Salutation salutation) 
	{
		salutation.setSalutationCertified(1);
		Salutation salu = this.salutationdao.save(salutation);
		res.addData("Data added", salu);
		saveSalutationTrail(salutation, "remarks" , "NEW");
		return res;
	}

	@Override
	public ResponseObj update(Salutation salutation) 
	{
		Optional<Salutation> saltn= findBySaltnId(salutation.getSalutationId());
		
		if(saltn.isPresent() &&  saltn.get().getSalutationCertified()==0)
		{
			Salutation saltnExisting = saltn.get();
			saltnExisting.setSalutationCertified(1);
			this.salutationdao.save(saltnExisting);
			saveSalutationTrail(salutation, "Salutation Updated", "MODIFY");
			res.addData("Salutation Update", salutation);
		}
		else
			res.setActionError("Salutation not found with Id " + salutation.getSalutationId());

		return res;
	}

	@Override
	public ResponseObj deleteSalutation(Long saltnId) 
	{
		Optional<Salutation> salutation = findBySaltnId(saltnId);

		if (salutation.isPresent() && salutation.get().getSalutationCertified() == 0) {
			Salutation saltnExisting = salutation.get();
			saltnExisting.setSalutationCertified(1);
			this.salutationdao.save(saltnExisting);
			saveSalutationTrail(saltnExisting, "Salutation Delete","DELETE");
			
			res.setMsg("Salutation Deleted", ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError("Salutation not found with id " + saltnId);

		return res;
	}

	public void saveSalutationTrail(Salutation salutation, String remarks, String action) {

		SalutationTrail salutationTrail = (SalutationTrail) ResponseDTO.accepted().convertToEntity(salutation, SalutationTrail.class);
		salutationTrail.setSalutation(salutation);
		salutationTrail.setSalutationCreateddBy("Ajit");
		salutationTrail.setSalutationAction(action);
		salutationTrail.setSalutationRemark(remarks);
		salutationTrail.setSalutationModifiedBy("Aditya");
		salutationTrail.setSaltnCertified((long) 1);
		
		this.salutationTrailDao.save(salutationTrail);
		//saveCertification(salutationTrail);

	}
	

	

}

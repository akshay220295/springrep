package com.isg.gcms.masters.salutation.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class SalutationCreationDTO 
{
	
	private String salutationName;

	@JsonIgnore
    private final Date salutationCreatedDate = new Date();
	
	public SalutationCreationDTO() 
	{
		
	}

	
}

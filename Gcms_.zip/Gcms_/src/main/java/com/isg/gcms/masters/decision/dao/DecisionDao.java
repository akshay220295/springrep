package com.isg.gcms.masters.decision.dao;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.decision.model.Decision;

@Repository
public interface DecisionDao extends JpaRepository<Decision, Long> 
{
	public Optional<Decision> findBydecisionNameEqualsIgnoreCase(String name);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified!=2")
	public Page<Decision> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified=0")
	public Page<Decision> getActiveDecisn(Pageable pageable);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified=1")
	public Page<Decision> getInactDecisn(Pageable pageable);

}

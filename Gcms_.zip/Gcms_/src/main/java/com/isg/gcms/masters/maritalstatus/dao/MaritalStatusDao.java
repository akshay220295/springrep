package com.isg.gcms.masters.maritalstatus.dao;


import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;

@Repository
public interface MaritalStatusDao extends JpaRepository<MaritalStatus, Long>
{
	public Optional<MaritalStatus> findByMaritalStatusNameEqualsIgnoreCase(String username);
	
	@Query("SELECT M FROM MaritalStatus M WHERE M.maritalStatusCertified!=2")
	public Page<MaritalStatus>  findAllByPagination(Pageable pageable);
}

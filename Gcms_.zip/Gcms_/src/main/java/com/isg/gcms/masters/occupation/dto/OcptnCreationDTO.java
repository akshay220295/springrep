package com.isg.gcms.masters.occupation.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class OcptnCreationDTO 
{

	private String occupationName;
	
	@JsonIgnore
    private final Date occupationCreatedDate = new Date();
	

}

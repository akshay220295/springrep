package com.isg.gcms.masters.occupation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
@Entity
@Table(name = "GCMS_OCCUPATION_TRAIL")
@Data
public class OccupationTrail 
{
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column (name = "OCPTN_TRAIL_ID")
	private Long occupationTrailId;
	
	@ManyToOne
	@JoinColumn(name = "OCPTN_ID", referencedColumnName = "OCPTN_ID")
	private Occupation occupation;
	
	@Column (name = "OCPTN_NAME")
	private String occupationName;
	
	@Column (name = "OCPTN_CRT_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String occupationCreatedDate;
	
	@Column (name = "OCPTN_CRT_BY")
	private String occupationCreatedBy;
	
	@Column (name = "OCPTN_MOD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String occupationModifiedDate;
	
	@Column (name = "OCPTN_MOD_BY")
	private String occupationModifiedBy;
	
	@Column (name = "OCPTN_CERT")
	private int occupationCertified;
	
	@Column (name = "OCPTN_CERT_MODE")
	private String occupationCertifiedMode;
	
	@Column (name = "OCPTN_ACT")
	private String occupationAction;
	
	@Column (name = "OCPTN_RMRK")
	private String occupationRemark;
}

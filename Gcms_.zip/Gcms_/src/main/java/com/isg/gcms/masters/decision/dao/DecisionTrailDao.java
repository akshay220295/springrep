package com.isg.gcms.masters.decision.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.decision.model.DecisionTrail;

@Repository
public interface DecisionTrailDao extends JpaRepository<DecisionTrail, Long> {

}

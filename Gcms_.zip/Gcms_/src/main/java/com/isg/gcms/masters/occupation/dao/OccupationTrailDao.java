package com.isg.gcms.masters.occupation.dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.occupation.model.OccupationTrail;

@Repository
public interface OccupationTrailDao extends JpaRepository<OccupationTrail, Long>
{	
	

}

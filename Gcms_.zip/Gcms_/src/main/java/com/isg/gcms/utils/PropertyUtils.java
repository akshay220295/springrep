package com.isg.gcms.utils;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

/* To get key value properties from property by defining Environment */
@PropertySource("classpath:message.properties")
@PropertySource("classpath:appconfig.properties")
@Service
public class PropertyUtils
{

	@Autowired
	private Environment envTmp;

	private static Environment env;

	/* To get property given the key */
	public static String getProperty(String key)
	{
		return env.getProperty(key);
	}

	@PostConstruct
	public void afterInit()
	{
		PropertyUtils.env = envTmp;
	}

}

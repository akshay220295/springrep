package com.isg.gcms.masters.exception.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.isg.gcms.masters.exception.model.ExceptionMstTrail;

public interface ExceptionTrailDao extends JpaRepository<ExceptionMstTrail, Long>{

}

package com.isg.gcms.masters.exception.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;
import lombok.Data;
@Data
@DTO
public class ExcptnUpdateDTO {

	@Id
	@NotNull
	private Long exceptionMstId;
	
	private String exceptionMstName;
	
	@JsonIgnore
    private final Date exceptionMstModifiedDate = new Date();
}

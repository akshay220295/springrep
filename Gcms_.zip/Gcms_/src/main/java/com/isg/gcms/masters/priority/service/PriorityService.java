package com.isg.gcms.masters.priority.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.priority.model.Priority;


@Service
public interface PriorityService 
{
	
	public ResponseObj getAllPriority(PaginationModel pagination);
	public ResponseObj getById(Long id);
	public ResponseObj update(Priority priority);
	public ResponseObj deletePriority(Long id);
	public ResponseObj create(Priority priority);
	public ResponseObj getByName(String name);
	public Optional<Priority> findbyPriorityName(String priorityName);

}

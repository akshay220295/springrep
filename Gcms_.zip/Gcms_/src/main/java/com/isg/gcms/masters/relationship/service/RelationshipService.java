package com.isg.gcms.masters.relationship.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relationship.model.Relationship;

public interface RelationshipService 
{	
	public ResponseObj getAllRltn(PaginationModel pagination);

	public ResponseObj create(Relationship relation);

	public ResponseObj getById(Long id);

	public Optional<Relationship> findById(Long id);

	public ResponseObj deleteById(Long id);

	public ResponseObj findByName(String name);

	public ResponseObj updateRltn(Relationship relation);


}

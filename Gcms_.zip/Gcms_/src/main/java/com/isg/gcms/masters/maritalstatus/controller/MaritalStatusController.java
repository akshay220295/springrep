package com.isg.gcms.masters.maritalstatus.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsCreationDTO;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsUpdateDTO;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;
import com.isg.gcms.masters.maritalstatus.service.MaritalStatusService;


@RestController
@RequestMapping("/marital/status")
public class MaritalStatusController 
{
	@Autowired
	private MaritalStatusService mrtlStsService; 
	
	@PostMapping
	public ResponseObj create(@RequestDTO(MartlStsCreationDTO.class) @Validated MaritalStatus maritalstatus)
	{
		return this.mrtlStsService.create(maritalstatus);
	}
	
	@GetMapping
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		System.out.println("@@@@@@@@@@@@@@@@@@@@@@@");
		return this.mrtlStsService.getAllMartlSts(pagination);
	}
	
	@GetMapping( value = "/{id}")
	public ResponseObj getMrtlStsById(@PathVariable("id") Long id)
	
	{
		
		return this.mrtlStsService.getById(id);
	}
	
	@GetMapping( value = "/name/{name}")
	public ResponseObj getbyName(@PathVariable("name") String username)
	{
		return this.mrtlStsService.findByName(username);
	}
	
	@DeleteMapping (value = "/{id}")
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.mrtlStsService.deleteById(id);
	}
	
	@PutMapping 
	public ResponseObj update(@RequestDTO(MartlStsUpdateDTO.class) @Validated MaritalStatus maritalstatus)
	{
		
		return this.mrtlStsService.updateMartlSts(maritalstatus);
	}
}

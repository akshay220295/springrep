package com.isg.gcms.masters.relationship.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class RltnUpdateDTO 
{	
	@Id
	@NotNull
	private Long relationId;
	
	private String relationshipName;
	
	@JsonIgnore
    private final Date relationshipModifiedDate = new Date();
	
	
}

package com.isg.gcms.masters.education.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class EducationCreationDTO 
{
	
	private String educationName;

	@JsonIgnore
    private final Date educationCreatedDate = new Date();
	
	public EducationCreationDTO() 
	{
		
	}

	
}

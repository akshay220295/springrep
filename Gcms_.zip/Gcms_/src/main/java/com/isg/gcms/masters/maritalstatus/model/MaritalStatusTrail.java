package com.isg.gcms.masters.maritalstatus.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
@Table (name = "GCMS_MARITALSTATUS_TRAIL")
public class MaritalStatusTrail {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "MARTLSTS_TRAIL_ID")
	private Long maritalStatusTrailId;
	
	@ManyToOne
	@JoinColumn (name = "MARTLSTS_ID" , referencedColumnName =  "MARTLSTS_ID" )
	private MaritalStatus  martialstatus; 

	@Column(name = "MARTLSTS_NAME")
	private String maritalStatusName;

	@Column(name = "MARTLSTS_CRT_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String maritalStatusCreatedDate;

	@Column(name = "MARTLSTS_CRT_BY")
	private String maritalStatusCreatedBy;

	@Column(name = "MARTLSTS_MOD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String maritalStatusModifiedDate;

	@Column(name = "MARTLSTS_MOD_BY")
	private String maritalStatusModifiedBy;

	@Column(name = "MARTLSTS_CERT")
	private Integer maritalStatusCertified;
	
	@Column (name = "MARTLSTS_CERT_MODE")
	private Integer maritalStatusCertMode;
	
	@Column (name = "MARTLSTS_ACT")
	private String maritalStatusAction;
	
	@Column (name = "MARTLSTS_RMRK")
	private String maritalStatusRemark;

}

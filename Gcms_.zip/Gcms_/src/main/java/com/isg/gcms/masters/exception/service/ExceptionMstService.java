package com.isg.gcms.masters.exception.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.exception.model.ExceptionMst;

@Service
public interface ExceptionMstService {

public ResponseObj getAllExcptn(PaginationModel pagination);
	
	public ResponseObj create(ExceptionMst exception);
	
	public ResponseObj getById(Long id);
	
	public Optional<ExceptionMst> findExcpById(Long id);

	public ResponseObj deleteById(Long id);
	
	public  ResponseObj findByName(String username);

	public ResponseObj updateExcptn(ExceptionMst exception);

	
	
}

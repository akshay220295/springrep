package com.isg.gcms.masters.priority.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="GCMS_PRIORITY")
public class Priority {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PRIOR_ID")
	private Long priorityId;
	
	@Column(name="PRIOR_NAME")
    private String priorityName;
	
	@Column(name="PRIOR_FST_TRK_FLAG")
    private String priorityFstTrkFlag;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name="PRIOR_CRT_DT")
    private String priorityCreatedDate;
	
	@Column(name="PRIOR_CRT_BY")
    private String  priorityCreatedBy;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name="PRIOR_MOD_DT")
    private String  priorityModifiedDate;
	
	@Column(name="PRIOR_MOD_BY")
    private String priorityModifiedBy;
	
	@Column(name="PRIOR_CERT")
    private Integer priorityCertified;
	
	@Column(name="PRIOR_BANK_ID")
    private Long priorityBankId; 
    
    
    
}

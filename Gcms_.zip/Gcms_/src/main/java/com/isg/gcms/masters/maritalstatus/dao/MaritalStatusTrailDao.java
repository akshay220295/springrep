package com.isg.gcms.masters.maritalstatus.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;

@Repository
public interface MaritalStatusTrailDao extends JpaRepository<MaritalStatusTrail, Long> {

}

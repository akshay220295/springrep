package com.isg.gcms.masters.priority.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.priority.dto.PriorityCreationDTO;
import com.isg.gcms.masters.priority.dto.PriorityUpdateDTO;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.priority.service.PriorityService;

@RestController
@RequestMapping("/priority")
public class PriorityController 
{
	@Autowired
	private PriorityService priorityService;
	
	
	@PostMapping
	public ResponseObj createPriority(@RequestDTO(PriorityCreationDTO.class) @Validated Priority priority)
	{
		return this.priorityService.create(priority);
	}
	
	@GetMapping
	public  ResponseObj findAllPriority(@RequestBody PaginationModel pagination)
	{
		System.out.println(pagination);
		return 	this.priorityService.getAllPriority(pagination);
	}
	
	@GetMapping(value="/{priorityId}")
	public  ResponseObj findPriorityByPriorityId(@PathVariable("priorityId") Long priorityId)
	{
		return 	this.priorityService.getById(priorityId);
	}
	
	@GetMapping(value="/name/{priorityName}")
	public  ResponseObj findPriorityByPriorityName(@PathVariable("priorityName") String priorityName)
	{
		return 	this.priorityService.getByName(priorityName);
	}
	
	@PutMapping
	public ResponseObj updatePriorityById(@RequestDTO(PriorityUpdateDTO.class) @Validated Priority priority)
	{
		return this.priorityService.update(priority);
	}
	
	@DeleteMapping(value = "/{priorityId}")
	public ResponseObj deletePriority(@PathVariable("priorityId") Long priorityId) {

		return this.priorityService.deletePriority(priorityId);

	}
	

}

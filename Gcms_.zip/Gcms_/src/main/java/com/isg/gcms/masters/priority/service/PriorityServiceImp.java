package com.isg.gcms.masters.priority.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.priority.dao.PriorityDao;
import com.isg.gcms.masters.priority.dao.PriorityTrailDao;
import com.isg.gcms.masters.priority.dto.PriorityUpdateDTO;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.priority.model.PriorityTrail;

@Service
public class PriorityServiceImp implements PriorityService
{
	@Autowired
	private PriorityDao priorityDao;
	
	@Autowired
	private PriorityTrailDao priorityTrailDao; 
	
	@Autowired
	ResponseObj res;
	
	public Optional<Priority> findByPriorityId(Long priorityId) 
	{
		
		return this.priorityDao.findById(priorityId);

	}
	
	public void savePriorityTrail(Priority priority, String remarks, String action) {

		PriorityTrail priorityTrail = (PriorityTrail) ResponseDTO.accepted().convertToEntity(priority, PriorityTrail.class);
		priorityTrail.setPriority(priority);
		priorityTrail.setPriorityCreatedBy("Ajit");
		priorityTrail.setPriorityAction(action);
		priorityTrail.setPriorityRemark(remarks);
		priorityTrail.setPriorityModifiedBy("Aditya");
		priorityTrail.setPriorityCertified(1);
		
		
		this.priorityTrailDao.save(priorityTrail);
		//saveCertification(salutationTrail);

	}
	
	@Override
	public ResponseObj getAllPriority(PaginationModel pagination) 
	{
		res.addData("LIST ALL", this.priorityDao.findAllByPagination(pagination.pageRequest()));
		return res;
	}

	@Override
	public ResponseObj getById(Long id) 
	{
		Optional<Priority> priority=this.priorityDao.findById(id);
		if(priority.isPresent() && priority.get().getPriorityCertified()==0)
		{
			res.addData("Priority By Id", ResponseDTO.accepted().convertTo(priority.get(), PriorityUpdateDTO.class));
		}
		else
		{
			res.setActionError("PRIORITY FOR THIS ID NOT FOUND" + id);
		}
		return res;
	}

	@Override
	public ResponseObj update(Priority priority) 
	{
		Optional<Priority> prior= findByPriorityId(priority.getPriorityId());
		
		if(prior.isPresent() &&  prior.get().getPriorityCertified()==0)
		{
			Priority priorityExisting = prior.get();
			priorityExisting.setPriorityCertified(1);
			this.priorityDao.save(priorityExisting);
			savePriorityTrail(priority, "PRIORITY UPDATED ", "MODIFY");
			res.addData("PRIORITY UPDATE", priority);
		}
		else
			res.setActionError("PRIORITY NOT FOUND WITH ID " + priority.getPriorityId());

		return res;
	}

	@Override
	public ResponseObj deletePriority(Long id) 
	{
		Optional<Priority> priority = findByPriorityId(id);

		if (priority.isPresent() && priority.get().getPriorityCertified() == 0) {
			Priority priorityExisting = priority.get();
			priorityExisting.setPriorityCertified(1);
			this.priorityDao.save(priorityExisting);
			savePriorityTrail(priorityExisting, "PRIORITY DELETE","DELETE");
			
			res.setMsg("PRIORITY DELETED", ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError("PRIORITY NOT FOUND WITH ID " + id);

		return res;
	}

	@Override
	public ResponseObj create(@RequestBody Priority priority) 
	{
		priority.setPriorityCertified(1);
		Priority prior = this.priorityDao.save(priority);
		res.addData("Data added", prior);
		savePriorityTrail(priority, "remarks" , "NEW");
		return res;
	}

	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<Priority> priority=this.priorityDao.findByPriorityNameEqualsIgnoreCase(name);
		if(priority.isPresent() && priority.get().getPriorityCertified()==0)
		{
			res.addData("PRIORITY BY NAME", ResponseDTO.accepted().convertTo(priority.get(), PriorityUpdateDTO.class));
		}
		else
		{
			res.setActionError("PRIORITY FOR THIS NAME NOT FOUND");
		}
		
		return res;
	}

	@Override
	public Optional<Priority> findbyPriorityName(String priorityName) 
	{
		
		return this.priorityDao.findByPriorityNameEqualsIgnoreCase(priorityName);
	}

}

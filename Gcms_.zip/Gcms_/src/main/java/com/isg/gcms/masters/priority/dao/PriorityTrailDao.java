package com.isg.gcms.masters.priority.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.priority.model.PriorityTrail;

@Repository
public interface PriorityTrailDao extends JpaRepository<PriorityTrail,Long>
{

}

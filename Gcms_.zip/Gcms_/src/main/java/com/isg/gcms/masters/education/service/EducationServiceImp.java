package com.isg.gcms.masters.education.service;



import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.education.dao.EducationDao;
import com.isg.gcms.masters.education.dao.EducationTrailDao;
import com.isg.gcms.masters.education.dto.EducationUpdateDTO;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.model.EducationTrail;





@Service
public class EducationServiceImp implements EducationService{
	
	@Autowired
	private EducationTrailDao educationTrailDao;
	
	@Autowired
	EducationDao educationDao;
	
	@Autowired
	ResponseObj res;
	
	
	public Optional<Education> findByEducationId(Long educationId) 
	{
		
		return this.educationDao.findById(educationId);

	}

	@Override
	public ResponseObj getAllEducation(PaginationModel pagination) {
		
		res.addData("LIST ALL", this.educationDao.findAllByPagination(pagination.pageRequest()));		
		
		return res;
		
		
	}

	@Override
	public ResponseObj getById(Long id) {
		
		Optional<Education> education=this.educationDao.findById(id);
		if(education.isPresent() && education.get().getEducationCertified()==0)
		{
			res.addData("Education By Id", ResponseDTO.accepted().convertTo(education.get(), EducationUpdateDTO.class));
		}
		else
		{
			res.setActionError("Education not found for this Id" + id);
		}

		return res;
		
		
	}

	@Override
	public ResponseObj update(Education education) 
	{
		Optional<Education> edu= findByEducationId(education.getEducationId());
		if(edu.isPresent() && edu.get().getEducationCertified()==0)
		{
			Education eduExisting=edu.get();
			eduExisting.setEducationCertified(1);
			this.educationDao.save(eduExisting);
			saveEducationTrail(education,"Education Updated","MODIFY");
			res.addData("Education Updated", education);
		}
		else
		{
			res.setActionError("Education not found with ID" + education.getEducationId());
		}

		return res;
	}

	@Override
	public ResponseObj deleteEducation(Long id) 
	{
		Optional<Education> education = findByEducationId(id);

		if (education.isPresent() && education.get().getEducationCertified() == 0) {
			Education eduExisting = education.get();
			eduExisting.setEducationCertified(1);
			this.educationDao.save(eduExisting);
			saveEducationTrail(eduExisting, "Education Delete","DELETE");
			
			res.setMsg("Education Deleted", ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError("Education not found with id " + id);

		return res;
		
	}

	@Override
	public ResponseObj create(@RequestBody Education education) 
	{
		education.setEducationCertified(1);
		Education edu = this.educationDao.save(education);
		res.addData("Data added", edu);
		saveEducationTrail(education, "remarks" , "NEW");
		return res;
	}

	private void saveEducationTrail(Education education, String remark, String action) 
	{
		EducationTrail educationTrail = (EducationTrail) ResponseDTO.accepted().convertToEntity(education, EducationTrail.class);
		educationTrail.setEducation(education);
		educationTrail.setEducationCreatedBy("Ajit");
		educationTrail.setEducationAction(action);
		educationTrail.setEducationRemark(remark);
		educationTrail.setEducationModifiedBy("Aditya");
		educationTrail.setEducationCertified(1);
		//saveCertification(salutationTrail);
		this.educationTrailDao.save(educationTrail);
		
	}

	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<Education> education=this.educationDao.findByEducationNameEqualsIgnoreCase(name);
		
		if(education.isPresent() && education.get().getEducationCertified()==0)
		{
			res.addData("Education for this Name",ResponseDTO.accepted().convertTo(education.get(), EducationUpdateDTO.class ) );
		}
		else
		{
			res.setActionError("Education for this name not found");
		}
		
		return res;
	}

	@Override
	public Optional<Education> findbyEducationName(String educationName) 
	{
		
		return this.educationDao.findByEducationNameEqualsIgnoreCase(educationName);
	}

}

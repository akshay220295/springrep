package com.isg.gcms.masters.exception.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.exception.dao.ExceptionDao;
import com.isg.gcms.masters.exception.dao.ExceptionTrailDao;
import com.isg.gcms.masters.exception.dto.ExcptnUpdateDTO;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.exception.model.ExceptionMstTrail;

@Service
public class ExceptionServiceImp implements ExceptionMstService{
	
	@Autowired
	private ExceptionDao excptnDao;
	
	@Autowired
	private ExceptionTrailDao excptnTrlDao; 
	
	@Autowired
	private ResponseObj res;

	@Override
	public ResponseObj getAllExcptn(PaginationModel pagination) {
		res.addData("LIST ALL", this.excptnDao.findAllByPagination(pagination.pageRequest()));
		
		return res;
	}
	
	@Override
	public Optional<ExceptionMst> findExcpById(Long id) {
		
		return  this.excptnDao.findById(id);
		
		
	}


	
	public ResponseObj getById(Long id)
	{
		Optional<ExceptionMst> exception = this.findExcpById(id);
		if(exception.isPresent() && exception.get().getExceptionMstCertified() == 0)
		{
			res.addData("REQUESTED VALUE", ResponseDTO.accepted().convertTo(exception.get(), ExcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError("ID NOT FOUND");
		}
		return res;
	}
	



	@Override
	public ResponseObj deleteById(Long id) {
		Optional<ExceptionMst> exception = findExcpById(id);
		if(exception.isPresent() && exception.get().getExceptionMstCertified() == 0)
		{
			ExceptionMst exceptionEx = exception.get();
			exceptionEx.setExceptionMstCertified(1);
			saveExcptnTrail(exceptionEx , "EXCEPTION DELETED" , "DELETE");
			this.excptnDao.save(exceptionEx);
			res.setMsg("VALUE DELETED", ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError("GIVEN EXCEPTION ID" + id + "NOT FOUND");
		}
		return res;
	}

	private void saveExcptnTrail(ExceptionMst exception, String remark, String action) {
		ExceptionMstTrail excptnTrail =  (ExceptionMstTrail) ResponseDTO.accepted().convertToEntity(exception, ExceptionMstTrail.class);
		excptnTrail.setExceptionMst(exception);
		excptnTrail.setExceptionMstCreatedBy("adi");   //JWT
		excptnTrail.setExceptionMstAction(action);  
		excptnTrail.setExceptionMstCertified(1);
		excptnTrail.setExceptionMstRemark(remark);
		
		this.excptnTrlDao.save(excptnTrail);
		
	}

	@Override
	public ResponseObj findByName(String username) {
		Optional<ExceptionMst> exception = this.findByExcepName(username);
		if(exception.isPresent() && exception.get().getExceptionMstCertified()==0)
		{
			res.addData("lLIST OF ITEMS ARE FETCHED", ResponseDTO.accepted().convertTo(exception.get(), ExcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError("NAME NOT FOUND");
		}
		return res;
	}


	private Optional<ExceptionMst> findByExcepName(String username) {
		return this.excptnDao.findByexceptionMstNameEqualsIgnoreCase(username);
	}

	@Override
	public ResponseObj updateExcptn(ExceptionMst exception) {
Optional<ExceptionMst> exceptionOld = findExcpById(exception.getExceptionMstId());
		
		if(exceptionOld.isPresent() && exception.getExceptionMstCertified()==0)
		{
			
			ExceptionMst excptnExisting = exceptionOld.get();
			excptnExisting.setExceptionMstCertified(1);
			this.excptnDao.save(excptnExisting);
			
			saveExcptnTrail(exception , "EXCEPTION UPDATED" , "MODIFY");
			res.addData("Exception updated", exception);
		}
		else
		{
			res.setActionError("EXCEPTION ID" + exception.getExceptionMstId() + "NOT FOUND");
		}
		return res;
	}

	

	

	@Override
	public ResponseObj create(ExceptionMst exception) {
		exception.setExceptionMstCertified(1);
		ExceptionMst excp=this.excptnDao.save(exception);
		res.addData("SAVE EXCEPTION", excp );
		saveExcptnTrail(exception , "EXCEPTION CREATED" , "NEW");
		return res;
	}
	
	
	
}

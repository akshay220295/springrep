package com.isg.gcms.masters.salutation.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.salutation.dto.SalutationCreationDTO;
import com.isg.gcms.masters.salutation.dto.SalutationUpdateDTO;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.service.SalutationService;

@RestController
@RequestMapping("/salutation")
@CrossOrigin
public class SalutationController {
	
	@Autowired
	private SalutationService saltnservice;
	
	
	@PostMapping
	public ResponseObj createSalutation(@RequestDTO(SalutationCreationDTO.class) @Validated Salutation salutation)
	{
		return this.saltnservice.create(salutation);
	}
	
	@GetMapping
	public  ResponseObj findAllSalutation(@RequestBody PaginationModel pagination)
	{
		System.out.println(pagination);
		return 	this.saltnservice.getAllSaltn(pagination);
	}
	
	@GetMapping(value="/{saltnId}")
	public  ResponseObj findSalutationBySaltnId(@PathVariable("saltnId") Long saltnId)
	{
		return 	this.saltnservice.getById(saltnId);
	}
	
	@GetMapping(value="/name/{saltnName}")
	public  ResponseObj findSalutationBySaltnName(@PathVariable("saltnName") String saltnName)
	{
		return 	this.saltnservice.getByName(saltnName);
	}
	
	@PutMapping
	public ResponseObj updateSalutationById(@RequestDTO(SalutationUpdateDTO.class) @Validated Salutation salutation)
	{
		return this.saltnservice.update(salutation);
	}
	
	@DeleteMapping(value = "/{saltnId}")
	public ResponseObj deleteSalutation(@PathVariable("saltnId") Long saltnId) {

		return this.saltnservice.deleteSalutation(saltnId);

	}
	
	
	

}

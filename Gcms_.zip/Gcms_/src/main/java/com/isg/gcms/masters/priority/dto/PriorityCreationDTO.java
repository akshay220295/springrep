package com.isg.gcms.masters.priority.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class PriorityCreationDTO 
{

	private String priorityName;
	
	private String priorityFstTrkFlag;

	@JsonIgnore
    private final Date priorityCreatedDate = new Date();
	
	public PriorityCreationDTO() 
	{
		
	}
	
}

package com.isg.gcms.masters.education.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.education.dto.EducationCreationDTO;
import com.isg.gcms.masters.education.dto.EducationUpdateDTO;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.service.EducationService;


@RestController("*")
@RequestMapping("/education")
@CrossOrigin("http://localhost:4200")
public class EducationController {
	
	@Autowired
	private EducationService educationService;
	
	
	@PostMapping
	public ResponseObj createEducation(@RequestDTO(EducationCreationDTO.class) @Validated Education education)
	{
		return this.educationService.create(education);
	}
	
	@GetMapping
	public  ResponseObj findAllEducation(@RequestBody PaginationModel pagination)
	{
		//return 	this.educationService.getAllEducation(pagination);
		return this.educationService.getAllEducation(pagination);
	}
	
	@GetMapping(value="/{eduId}")
	public  ResponseObj findEducationByEduId(@PathVariable("eduId") Long educationId)
	{
		return 	this.educationService.getById(educationId);
	}
	
	@GetMapping(value="/name/{eduName}")
	public  ResponseObj findEducationByEduName(@PathVariable("eduName") String educationName)
	{
		return 	this.educationService.getByName(educationName);
	}
	
	@PutMapping
	public ResponseObj updateEducationById(@RequestDTO(EducationUpdateDTO.class) @Validated Education education)
	{
		return this.educationService.update(education);
	}
	
	@DeleteMapping(value = "/{eduId}")
	public ResponseObj deleteEducation(@PathVariable("eduId") Long educationId) {

		return this.educationService.deleteEducation(educationId);

	}
	
	
	

}

package com.isg.gcms.masters.decision.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.decision.dto.DecisnCreationDTO;
import com.isg.gcms.masters.decision.dto.DecisnUpdateDTO;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.service.DecisionService;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsCreationDTO;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsUpdateDTO;
import com.isg.gcms.masters.relationship.dto.RltnCreationDTO;
import com.isg.gcms.masters.relationship.dto.RltnUpdateDTO;


@RestController
@RequestMapping("/decision")
@CrossOrigin
public class DecisionController 
{
	@Autowired
	private DecisionService decisnService;
	
	@PostMapping
	public ResponseObj create(@RequestDTO(DecisnCreationDTO.class) @Validated Decision decision)
	{
		return this.decisnService.create(decision);
	}
	
	@GetMapping
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		return this.decisnService.getAllDecision(pagination);
	}
	
	@GetMapping( value = "/{id}")
	public ResponseObj getMrtlStsById(@PathVariable("id") Long id)
	
	{
		
		return this.decisnService.getById(id);
	}
	
	@GetMapping( value = "/name/{name}")
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.decisnService.findByName(name);
	}
	
	@DeleteMapping (value = "/{id}")
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.decisnService.deleteById(id);
	}
	
	@PutMapping 
	public ResponseObj update(@RequestDTO(DecisnUpdateDTO.class) @Validated Decision decision)
	{
		
		return this.decisnService.updateDecisn(decision);
	}

}

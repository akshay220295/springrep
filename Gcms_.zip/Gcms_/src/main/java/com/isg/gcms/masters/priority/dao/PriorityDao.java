package com.isg.gcms.masters.priority.dao;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.isg.gcms.masters.priority.model.Priority;


@Repository
public interface PriorityDao extends JpaRepository<Priority,Long>
{
	public Optional<Priority> findByPriorityNameEqualsIgnoreCase(String name);
	
	@Query("SELECT M FROM Priority M WHERE M.priorityCertified!=2")
	public Page<Priority> findAllByPagination(Pageable pageble);

}

package com.isg.gcms.masters.relationship.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
@Table (name = "GCMS_RELATION_TRAIL")
public class RelationshipTrail 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RLTN_TRAIL_ID")
	private Long relationshipTrailId;
	
	@ManyToOne
	@JoinColumn (name = "RLTN_ID" , referencedColumnName =  "RLTN_ID" )
	private Relationship relation;
	
	@Column (name = "RLTN_NAME")
	private String relationshipName;
	
	@Column (name = "RLTN_CRT_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String relationshipCreatedDate;
	
	@Column (name = "RLTN_CRT_BY")
	private String relationshipCreatedBy;
	
	@Column (name = "RLTN_MOD_DT")
	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private String relationshipModifiedDate;
	
	@Column (name = "RLTN_MOD_BY")
	private String relationshipModifiedBy;
	
	@Column (name = "RLTN_CERT")
	private Integer relationshipCertified;
	
	@Column (name = "RELATION_CERT_MODE")
	private Integer relationshipCertMode;
	
	@Column (name = "RELATION_ACT")
	private String relationshipAction;
	
	@Column (name = "RELATION_RMRK")
	private String relationshipRemark;
	

}

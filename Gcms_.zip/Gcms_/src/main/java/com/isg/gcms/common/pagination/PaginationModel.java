package com.isg.gcms.common.pagination;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.CollectionUtils;

public class PaginationModel {

	@NotNull(message = "{required}")
	@Min(value = 0)
	private Integer pageNumber = null;

	@NotNull(message = "{required}")
	@Min(value = 1)
	private Integer pageSize = null;

	@Valid
	private List<SortingModel> sorts;
	private List<FilterModel> filter;

	public PaginationModel() {
		super();
	}

	public Sort sort() {
		List<Order> sortList = new ArrayList<>();
		if (getSorts() != null && !getSorts().isEmpty()) {
			getSorts().forEach(k -> sortList.add(new Order(k.getDir(), k.getProp())));
		}
		return Sort.by(sortList);
	}

	public PageRequest pageRequest() {
		return PageRequest.of(getPageNumber(), getPageSize(), sort());
	}

	public <T> Specification<T> pagingSpecification() {
		return (root, query, builder) -> {
			Predicate p = builder.and();
			if (!CollectionUtils.isEmpty(filter)) {
				for (FilterModel f : filter) {

					String[] objKeys = f.getProp().split("\\.");

					Path<Object> objPath = root.get(objKeys[0]);

					for (int i = 1; i < objKeys.length; i++) {
						objPath = objPath.get(objKeys[i]);
					}

					Predicate currPredicate = null;
					String columnValue = f.getValue();

					if (columnValue != null) {
						if (objPath.getJavaType() == LocalDateTime.class) {
							currPredicate = builder.like(builder.function("TO_CHAR", String.class, objPath,
									builder.literal("MON fmdd, yyyy")), f.getValue().toUpperCase() + "%");
						} else {
							currPredicate = builder.and(builder.like(builder.upper(objPath.as(String.class)),
									columnValue.toUpperCase() + "%"));
						}
					}

					if (currPredicate != null) {
						p = builder.and(p, currPredicate);
					}
				}
			}
			return p;
		};
	}

	// GETTERS & SETTERS
	public int getPageNumber() {
		return pageNumber;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public List<FilterModel> getFilter() {
		return filter;
	}

	public void setFilter(List<FilterModel> filter) {
		this.filter = filter;
	}

	public List<SortingModel> getSorts() {
		return sorts;
	}

	public void setSorts(List<SortingModel> sorts) {
		this.sorts = sorts;
	}

	@Override
	public String toString() {
		return "{PaginationModel: {pageNumber:" + pageNumber + ", pageSize:" + pageSize + ", sorts:" + sorts
				+ ", filter:" + filter + "}}";
	}

}
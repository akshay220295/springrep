package com.isg.gcms.masters.salutation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_SALUTATION")
public class Salutation 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SALTN_ID")
	private Long salutationId;
	

	@Column(name="SALTN_NAME")
	private String salutationName;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name="SALTN_CRT_DT")
	private String salutationCreatedDate;

	@Column(name="SALTN_CRT_BY")
	private String salutationCreatedBy;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name="SALTN_MOD_DT")
	private String salutationModifiedDate;
	
	@Column(name = "SALTN_MOD_BY", length = 30)
	private String salutationModifiedBy;
	
	@Column(name="SALTN_CERT")
    private Integer salutationCertified;
}

package com.isg.gcms.masters.relationship.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class RltnCreationDTO 
{
	private String relationshipName;
	
	@JsonIgnore
	private final Date relationshipCreatedDate = new Date();
	

}

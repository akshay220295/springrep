package com.isg.gcms.masters.relationship.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.relationship.model.RelationshipTrail;

@Repository
public interface RelationshipTrailDao extends JpaRepository<RelationshipTrail, Long>{

}

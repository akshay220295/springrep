package com.isg.gcms.masters.salutation.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class SalutationUpdateDTO 
{

	@Id
    @NotNull
    private Long salutationId;
	private String salutationName;
	
	@JsonIgnore
    private final Date salutationModifiedDate = new Date();
}

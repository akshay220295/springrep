package com.isg.gcms.masters.occupation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.dto.OcptnCreationDTO;
import com.isg.gcms.masters.occupation.dto.OcptnUpdateDTO;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.service.OccupationService;

@RestController
@RequestMapping("/occupation")
public class OccupationController 
{
	@Autowired
	private OccupationService ocptnService;
	
	@GetMapping
	public ResponseObj getall(@RequestBody PaginationModel pagination)
	{
		return this.ocptnService.getAllOcptn(pagination);
	}
	
	@GetMapping( value = "/{id}")
	public ResponseObj getValue(@PathVariable("id") Long id)
	
	{
		
		return this.ocptnService.getById(id);
	}
	
	@GetMapping( value = "/name/{username}")
	public ResponseObj getbyName(@PathVariable("username") String username)
	{
		return this.ocptnService.findByName(username);
	}
	
	@PostMapping
	public ResponseObj create(@RequestDTO(OcptnCreationDTO.class) @Validated Occupation occupation)
	{
		
		return this.ocptnService.create(occupation) ;
	}
	
	@DeleteMapping (value = "/{id}")
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.ocptnService.deleteById(id);
	}
	
	@PutMapping 
	public ResponseObj updateOcptn(@RequestDTO(OcptnUpdateDTO.class) @Validated Occupation occupation)
	{
		
		return this.ocptnService.updateOcptn(occupation);
	}

}

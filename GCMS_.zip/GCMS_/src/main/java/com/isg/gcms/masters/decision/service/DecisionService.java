package com.isg.gcms.masters.decision.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.decision.model.Decision;


public interface DecisionService 
{
	public ResponseObj getAllDecision(PaginationModel pagination);
	
	public Optional<Decision> findById(Long id);

	public ResponseObj getById(Long id);

	public ResponseObj findByName(String name);
	
	public ResponseObj create(Decision decision);

	public ResponseObj deleteById(Long id);

	public ResponseObj updateDecisn(Decision decision);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllDecision();

}

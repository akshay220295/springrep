package com.isg.gcms.masters.channel.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.isg.gcms.masters.channel.model.Channel;
import com.isg.gcms.masters.channel.model.ChannelTrail;



public interface ChannelTrailDao extends JpaRepository< ChannelTrail, Long> 
{

	public List<ChannelTrail> findByChannel(Channel channel);	
	
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */

	
}




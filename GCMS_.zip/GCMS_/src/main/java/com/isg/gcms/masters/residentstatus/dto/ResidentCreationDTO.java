package com.isg.gcms.masters.residentstatus.dto;
import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;
import lombok.Data;


@Data
@DTO
public class ResidentCreationDTO
{

	private String residentName;

	@JsonIgnore
    private final Date  residentCreatedDate = new Date();
	
}

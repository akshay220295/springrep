package com.isg.gcms.masters.deferral.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class DefrlCreationDto {

	private String deferralName;
	
	@JsonIgnore
	private final Date deferralCreatedDate = new Date();
	
}

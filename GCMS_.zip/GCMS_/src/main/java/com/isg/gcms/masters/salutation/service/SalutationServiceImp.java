package com.isg.gcms.masters.salutation.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.residentstatus.model.Resident;
import com.isg.gcms.masters.salutation.dao.SalutationDao;
import com.isg.gcms.masters.salutation.dao.SalutationTrailDao;
import com.isg.gcms.masters.salutation.dto.SalutationUpdateDTO;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.model.SalutationTrail;

@Service
public class SalutationServiceImp implements SalutationService{
	
	/*
	 * To inject an instance of SalutationDao
	 */
	@Autowired
	private SalutationTrailDao salutationTrailDao;
	
	
	/*
	 * To inject an instance of Salutation Trail Dao
	 */
	@Autowired
	private SalutationDao salutationdao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
		
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To find Salutation based on id and to use in other methods.
	 */
	public Optional<Salutation> findBySaltnId(Long saltnId) 
	{
		
		return this.salutationdao.findById(saltnId);

	}
	
	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.salutationdao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.salutationdao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}
	
	/*
	 * To get all Salutation values.
	 */
	@Override
	public ResponseObj getAllSaltn() 
	{
		List<Salutation> saltn=this.salutationdao.findAll();
		if(!saltn.isEmpty())
		{
			res.addData(Constant.LIST_ALL, saltn);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllSaltn(PaginationModel pagination) 
	{
		
		Page<Salutation> saltn=this.salutationdao.findAll(pagination.pageRequest());
		List<Salutation> saltnList = saltn.getContent();
		if(!saltnList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, saltnList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	
	
	/*
	 * To get Salutation based on id.
	 */
	@Override
	public ResponseObj getById(Long saltnId) 
	{
		
		Optional<Salutation> salutation= this.salutationdao.findById(saltnId);
		if(salutation.isPresent() && salutation.get().getSalutationCertified()==0)
		{
			res.addData(Constant.BY_ID,ResponseDTO.accepted().convertTo(salutation.get(), SalutationUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
		
		
	}
	
	
	/*
	 * To get Salutation based on name.
	 */
	@Override
	public ResponseObj getByName(String name) 
	{
		
		Optional<Salutation> salutation=this.salutationdao.findBySalutationNameEqualsIgnoreCase(name);
		
		if(salutation.isPresent() && salutation.get().getSalutationCertified()==0)
		{
			res.addData(Constant.BY_NAME,ResponseDTO.accepted().convertTo(salutation.get(), SalutationUpdateDTO.class ) );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}


	/*
	 * To find Salutation based on name
	 */
	@Override
	public Optional<Salutation> findbySalutationName(String saltnName) 
	{
		return this.salutationdao.findBySalutationNameEqualsIgnoreCase(saltnName);

	}
	
	/*
	 * To create new Salutation value.
	 */
	@Override
	public ResponseObj create(@RequestBody Salutation salutation) 
	{
		salutation.setSalutationCertified(1);
		salutation.setSalutationCreatedBy("Ajit");
		Salutation salu = this.salutationdao.save(salutation);
		res.addData(Constant.VALUE_CREATED, salu);
		saveSalutationTrail(salutation, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(Salutation salutation) 
	{
		Optional<Salutation> saltn= findBySaltnId(salutation.getSalutationId());
		
		if(saltn.isPresent() &&  saltn.get().getSalutationCertified()==0)
		{
			Salutation saltnExisting = saltn.get();
			saltnExisting.setSalutationCertified(1);
			saltnExisting.setSalutationModifiedDate(new Date());
			saltnExisting.setSalutationModifiedBy("Ajit"); // jwt or session
			this.salutationdao.save(saltnExisting);
			saveSalutationTrail(salutation,Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, salutation);
		}
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteSalutation(Long saltnId) 
	{
		Optional<Salutation> salutation = findBySaltnId(saltnId);

		if (salutation.isPresent() && salutation.get().getSalutationCertified() == 0) {
			Salutation saltnExisting = salutation.get();
			saltnExisting.setSalutationCertified(1);
			this.salutationdao.save(saltnExisting);
			saveSalutationTrail(saltnExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	/*
	 * To save values in Salutation Trail table
	 */
	public void saveSalutationTrail(Salutation salutation, String remarks, String action) {

		SalutationTrail salutationTrail = (SalutationTrail) ResponseDTO.accepted().convertToEntity(salutation, SalutationTrail.class);
		salutationTrail.setSalutation(salutation);
		salutationTrail.setSalutationCreateddBy("Ajit");
		salutationTrail.setSalutationAction(action);
		salutationTrail.setSalutationRemark(remarks);
		salutationTrail.setSalutationCertified(1);
		this.salutationTrailDao.save(salutationTrail);
		saveCertification(salutationTrail);

	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(SalutationTrail salutationTrail) 
	{
			/*
			 * To inject an instance of Certification
			 */
			
			Certification cert=new Certification();
			
			cert.setAction(salutationTrail.getSalutationAction());
			cert.setTrailId(salutationTrail.getSalutationTrailId());
			cert.setTableName(MasterType.SALUTATION.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(salutationTrail.getSalutationCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

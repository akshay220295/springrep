package com.isg.gcms.masters.address.service;


import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.address.model.Address;



public interface AddressService {

	public ResponseObj getAllAddress(PaginationModel pagination);
	
	public Optional<Address> findAddressById(Long addressId);

	public ResponseObj getAddressById(long addressId);

	
	
	public ResponseObj saveAddress(Address address);

	public ResponseObj deleteAddress(Long id);

	public ResponseObj updateAddress(Address address);

}
package com.isg.gcms.masters.occupation.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.model.Occupation;

@Service
public interface OccupationService 
{
	public ResponseObj getAllOcptn(PaginationModel pagination);
	
	public ResponseObj create(Occupation occupation);
	
	public ResponseObj getById(Long id);
	
	public Optional<Occupation> findOccuById(Long id);

	public ResponseObj deleteById(Long id);
	
	public  ResponseObj findByName(String username);

	public ResponseObj updateOcptn( Occupation occupation);

	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllOcptn();
	
}

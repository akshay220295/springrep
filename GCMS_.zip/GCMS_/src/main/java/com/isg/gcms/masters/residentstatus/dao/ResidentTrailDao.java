package com.isg.gcms.masters.residentstatus.dao;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.isg.gcms.masters.residentstatus.model.Resident;
import com.isg.gcms.masters.residentstatus.model.ResidentTrail;


@Repository
public interface ResidentTrailDao extends JpaRepository< ResidentTrail, Long>
{ 

	public List<ResidentTrail> findByResident(Resident resident);	

	
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */

	
	
}

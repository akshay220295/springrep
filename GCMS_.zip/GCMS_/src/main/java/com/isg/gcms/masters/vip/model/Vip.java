package com.isg.gcms.masters.vip.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
@Table(name="GCMS_VIP_MST")
public class Vip {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "VIP_ID")
	private Long vipId;
	
	@Column (name = "VIP_NAME")
	private String vipName;
	
	@Column (name = "VIP_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date vipCreatedDate;
	
	@Column (name = "VIP_CRT_BY")
	private String vipCreatedBy;
	
	@Column (name = "VIP_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date vipModifiedDate;
	
	@Column (name = "VIP_MOD_BY")
	private String vipModifiedBy;
	
	@Column (name = "VIP_CERT")
	private Integer vipCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	

	
	







}

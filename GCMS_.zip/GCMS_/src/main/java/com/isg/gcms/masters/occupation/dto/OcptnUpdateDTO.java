package com.isg.gcms.masters.occupation.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class OcptnUpdateDTO 
{	
	@Id
	@NotNull
	private Long occupationId;
	
	private String occupationName;
	
	@JsonIgnore
    private final Date occupationModifiedDate = new Date();

}

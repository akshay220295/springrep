package com.isg.gcms.masters.residentstatus.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.residentstatus.dto.ResidentCreationDTO;
import com.isg.gcms.masters.residentstatus.dto.ResidentUpdateDTO;
import com.isg.gcms.masters.residentstatus.model.Resident;
import com.isg.gcms.masters.residentstatus.service.ResidentService;

@RestController
@CrossOrigin("*")
@RequestMapping(value=Constant.PATH_RESIDENTIAL_STS)
public class ResidentController {
	
	@Autowired
	private ResidentService residentService;
	
	/* To get all records with pagination */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAllResident(@RequestBody PaginationModel pagination) {
		return this.residentService.getAllResident(pagination);

	}
	
	/* To get all records */
	@GetMapping(value =Constant.PATH_GET_ALL)
	public ResponseObj getAll()
	{

		return this.residentService.getAll();

	}

	/* To get status based on(active/deactive)*/
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.residentService.getStatus(pagination, status) ;
	}
	
	/* To get records based on id */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public ResponseObj getById(@PathVariable("id") Long id) {

		return this.residentService.getById(id);
		
	}
	
	/* To get records based on name */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public ResponseObj getResidentByName(@PathVariable("name") String residentName) {

		return this.residentService.getByName(residentName);

	}
	
	
	
	/* To create a new resident . */
	@PostMapping
	public ResponseObj createResident(@RequestDTO(ResidentCreationDTO.class) @Validated Resident resident) {
		
		return this.residentService.createResident(resident);

	}
	
	
	/* To update existing resident. */
	@PutMapping
	public ResponseObj updateResident(@RequestDTO(ResidentUpdateDTO.class) @Validated Resident resident) {
		return this. residentService.updateResident(resident);

	}

	/* To soft delete a resident based on resident id */
	@DeleteMapping(value=Constant.PATH_DELETE)
	public ResponseObj deleteResident(@PathVariable("id") Long id) {

		return this.residentService.deleteById(id);
	}
	
	
    }
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



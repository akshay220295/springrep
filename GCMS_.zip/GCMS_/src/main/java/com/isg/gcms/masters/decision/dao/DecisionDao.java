package com.isg.gcms.masters.decision.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.decision.model.Decision;

@Repository
public interface DecisionDao extends JpaRepository<Decision, Long> 
{
	public Optional<Decision> findBydecisionNameEqualsIgnoreCase(String name);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified!=2")
	public Page<Decision> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified=0 AND M.decisionCertified!=2")
	public Page<Decision> getActiveDecisn(Pageable pageable);
	
	@Query ("SELECT M FROM Decision M WHERE M.decisionCertified=1 AND M.decisionCertified!=2")
	public Page<Decision> getInactDecisn(Pageable pageable);

	public List<Decision> findBydecisionCertified(int id);
	
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name and Query we provided it.
	 * 
	 */
}

package com.isg.gcms.masters.vip.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.vip.dao.VipDao;
import com.isg.gcms.masters.vip.dao.VipTrailDao;
import com.isg.gcms.masters.vip.dto.VipUpdateDTO;
import com.isg.gcms.masters.vip.model.Vip;
import com.isg.gcms.masters.vip.model.VipTrail;

@Service
public class VipServiceImple implements VipService {

	/*
	 * To inject instance of VipDao class 
	 */
	@Autowired
	private VipDao vipDao;
	
	/* 
	 * To inject instance of VipTrailDao class 
	*/
	@Autowired 
	private VipTrailDao vipTrailDao;
	
	/* 
	 * To inject instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
	
	/*
	 * To inject instance of certificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllVip(PaginationModel pagination) {
		Page<Vip> vipPage = this.vipDao.findAllByPagination(pagination.pageRequest());
		List<Vip> vipPageList = vipPage.getContent();
		if(!vipPageList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, vipPageList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get all Vip values.
	 */
	@Override
	public ResponseObj getAllVip() {
		List<Vip> vipList = this.vipDao.findAll();
		if(!vipList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, vipList );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new Vip value.
	 */
	public ResponseObj create (Vip vip)
	 {
		vip.setVipCertified(1);
		vip.setVipCreatedBy("Aditya"); // JWT OR SESSION
		vip.setBankId(1L);  // JWT OR SESSION
		vip.setEntityId(1L); // JWT OR SESSION
		Vip vp = this.vipDao.save(vip);
		vp.setBankId(1L);  // JWT OR SESSION
		vp.setEntityId(1L); // JWT OR SESSION
		saveVipTrail(vp,Constant.VALUE_CREATED,"NEW");
		res.addData(Constant.VALUE_CREATED, vp);
		return res;
	}

	/*
	 * To get Vip based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<Vip> vip = this.findById(id);
		if (vip.isPresent() && vip.get().getVipCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(vip.get(), VipUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;

	}

	/*
	 * To find Vip based on id and to use in other methods.
	 */
	@Override
	public Optional<Vip> findById(Long id) {
		return this.vipDao.findById(id);
	}
	
	/*
	 * To soft delete based on id
	 */
	public ResponseObj deleteById(Long id) {
		
		Optional<Vip> vip = this.findById(id);
		if(vip.isPresent() && vip.get().getVipCertified()==0) {
			Vip vipEx = vip.get();
			vipEx.setVipCertified(1);
			saveVipTrail(vipEx,Constant.VALUE_DELETED,"DELETED");
			this.vipDao.save(vipEx);
			res.setMsg(Constant.VALUE_DELETED,ResponseMsgType.SUCCESS);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Vip based on name
	 */
	public Optional<Vip> getByName(String name) {
		return vipDao.findByVipNameEqualsIgnoreCase(name);
	}

	/*
	 * To get Vip based on name.
	 */
	@Override
	public ResponseObj findByName(String name) {
		Optional<Vip> vip = this.getByName(name);
		if (vip.isPresent() && vip.get().getVipCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(vip.get(), VipUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateVip(@RequestBody   Vip vip) {
		
		Optional<Vip> vipOld = findById(vip.getVipId());
		
		if(vipOld.isPresent() && vipOld.get().getVipCertified() == 0)
		{
			Vip vipEx = vipOld.get();
			vipEx.setVipCertified(1);
			vipEx.setVipModifiedDate(new Date());
			vipEx.setVipModifiedBy("Abhishek");//JWT Token
			this.vipDao.save(vipEx);
			saveVipTrail(vip, Constant.VALUE_UPDATED, "MODIFY" );
			res.addData(Constant.VALUE_UPDATED, vip);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		
		return res;
	}
	
	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.vipDao.getActiveVip(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.vipDao.getInactVip(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in Vip Trail table
	 */
	public void saveVipTrail(Vip vip,String remark,String action) {
		VipTrail vipTrail = (VipTrail) ResponseDTO.accepted().convertToEntity(vip,VipTrail.class);
		vipTrail.setVip(vip);
		vipTrail.setVipCreatedBy("adi"); // JWT OR  Session
		vipTrail.setVipAction(action);
		vipTrail.setVipCertified(1);
		vipTrail.setVipRemark(remark);

		this.vipTrailDao.save(vipTrail);
		saveCertification(vipTrail);
		
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(VipTrail vipTrail) 
	{
		
		/*
		 * To inject an instance of Certification
		 */
		
		 Certification cert=new Certification();
		
			cert.setAction(vipTrail.getVipAction());
			cert.setTrailId(vipTrail.getVipTrailId());
			cert.setTableName(MasterType.VIP.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit");// To do replace maker with JWT
			cert.setMakerTime(vipTrail.getVipCreatedDate());
			cert.setCheckedTime(new Date());
			this.certificationDao.save(cert);
			
	}



}
package com.isg.gcms.masters.decision.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class DecisnCreationDTO 
{
	private String decisionName;

	@JsonIgnore
	private final Date decisionCreatedDate = new Date();
}

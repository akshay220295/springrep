package com.isg.gcms.masters.dsa.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.dsa.dto.DsaCreationDTO;
import com.isg.gcms.masters.dsa.dto.DsaUpdateDTO;
import com.isg.gcms.masters.dsa.model.Dsa;
import com.isg.gcms.masters.dsa.service.DsaService;

@CrossOrigin("*")
@RestController
@RequestMapping(value= Constant.PATH_DSA)
public class DsaController 
{
	
	/*
	 * To inject an instance of DsaDaoService
	*/
	@Autowired
	private DsaService dsaService;
	
	/*
	 * To get Dsa based on status (active/inactive) .
	 */	  
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.dsaService.getStatus(pagination, status) ;
	}
	
	/*
	 * Get all Dsa without pagination.
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj findAllDsa()
	{
		return this.dsaService.getAllDsa();
	}
	
	/*
	 * Get all Dsa with pagination.
	 */
	@PostMapping(value= Constant.PATH_GET_ALL_PAGI)
	public  ResponseObj findAllDsa(@RequestBody PaginationModel pagination)
	{
		
		return 	this.dsaService.getAllDsa(pagination);
	}
	
	/*
	 * To get Dsa based on id.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public  ResponseObj findDsaByDsaId(@PathVariable("dsaId") Long dsaId)
	{
		return 	this.dsaService.getById(dsaId);
	}
	
	/*
	 * To get Dsa based on name.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public  ResponseObj findDsaByDsaName(@PathVariable("dsaName") String dsaName)
	{
		return 	this.dsaService.getByName(dsaName);
	}
	
	/*
	 * To create a new Dsa .
	 */
	@PostMapping
	public ResponseObj createDsa(@RequestDTO(DsaCreationDTO.class) @Validated Dsa dsa)
	{
		return this.dsaService.create(dsa);
	}
	
	/*
	 * To update existing Dsa based on id.
	 */
	@PutMapping
	public ResponseObj updateDsaById(@RequestDTO(DsaUpdateDTO.class) @Validated Dsa dsa)
	{
		return this.dsaService.update(dsa);
	}
	
	/*
	 * To soft deleting Dsa based on id.
	 */
	@DeleteMapping(value = Constant.PATH_DELETE)
	public ResponseObj deleteDsa(@PathVariable("id") Long id) {

		return this.dsaService.deleteDsa(id);

	}

}

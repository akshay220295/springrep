package com.isg.gcms.masters.decision.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.channel.model.Channel;
import com.isg.gcms.masters.decision.dao.DecisionDao;
import com.isg.gcms.masters.decision.dao.DecisionTrailDao;
import com.isg.gcms.masters.decision.dto.DecisnUpdateDTO;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.model.DecisionTrail;

@Service
public class DecisionServiceImp implements DecisionService{
	
	/*
	 * To inject an instance of DecisonDao
	 */
	@Autowired
	private DecisionDao decisnDao;
	
	/*
	 * To inject an instance of Decison Trail Dao
	 */
	@Autowired
	private DecisionTrailDao decisnTrlDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
	
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllDecision(PaginationModel pagination) 
	{
		Page<Decision> decisn =  this.decisnDao.findAllByPagination(pagination.pageRequest());
		List<Decision> decisnlList = decisn.getContent();
		if(!decisnlList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, decisnlList );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all Decision values.
	 */
	@Override
	public ResponseObj getAllDecision() 
	{
		
		List<Decision> lsDecisn = this.decisnDao.findAll();
		if(!lsDecisn.isEmpty())
		{
		res.addData(Constant.LIST_ALL, lsDecisn );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find Decision based on id and to use in other methods.
	 */
	@Override
	public Optional<Decision> findById(Long id)
	{
		return this.decisnDao.findById(id);
	}
	
	/*
	 * To get Decision based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<Decision> decision = this.findById(id);
		if(decision.isPresent() && decision.get().getDecisionCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(decision.get(), DecisnUpdateDTO.class ));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Decision based on name
	 */
	public Optional<Decision> getByName(String name) {
		return decisnDao.findBydecisionNameEqualsIgnoreCase(name);
	}
	
	/*
	 * To get Decision based on name.
	 */
	@Override
	public ResponseObj findByName(String name) {
		Optional<Decision> decision = this.getByName(name);
		if (decision.isPresent() && decision.get().getDecisionCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(decision.get(), DecisnUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	

	/*
	 * To create new Decision value.
	 */
	@Override
	public ResponseObj create(@RequestBody Decision decision) 
	{
		decision.setDecisionCertified(1);
		decision.setDecisionCreatedBy("adi");  //JWT orSession
		
		Decision decisn = this.decisnDao.save(decision);
		saveDecisionTrail(decisn,Constant.VALUE_CREATED,"NEW" );
		res.addData(Constant.VALUE_CREATED, decisn);
		return res;
	
	}
	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<Decision> decision = this.findById(id);
		if (decision.isPresent() && decision.get().getDecisionCertified() == 0) 
		{
			Decision decisnEx = decision.get();
			decisnEx.setDecisionCertified(1);
			saveDecisionTrail(decisnEx,Constant.VALUE_DELETED,"DELETE" );
			this.decisnDao.save(decisnEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateDecisn(Decision decision) 
	{
		Optional<Decision> decisnOld = findById(decision.getDecisionId());
		if (decisnOld.isPresent() && decisnOld.get().getDecisionCertified() == 0)
		{
			Decision decisnEx = decisnOld.get();
			decisnEx.setDecisionCertified(1);
			decisnEx.setDecisionModifiedDate(new Date());
			decisnEx.setDecisionModifiedBy("adi"); // JWT or Session
			this.decisnDao.save(decisnEx);
			saveDecisionTrail(decision,Constant.VALUE_UPDATED,"MODIFY" );
			res.addData(Constant.VALUE_UPDATED, decision );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}
	
	
	/*
	 * To find status based on (active/inactive)
	 */
	public ResponseObj getstatus(String status, PaginationModel pagination)
	{
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.decisnDao.getActiveDecisn(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.decisnDao.getInactDecisn(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in Decision Trail table
	 */
	public void saveDecisionTrail(Decision decision, String remark, String action)
	{
		DecisionTrail decisnTrail = (DecisionTrail) ResponseDTO.accepted().convertToEntity(decision,
				DecisionTrail.class);
		decisnTrail.setDecision(decision);
		decisnTrail.setDecisionCreatedBy("adi"); //JWT OR Session
		decisnTrail.setDecisionAction(action);
		decisnTrail.setDecisionCertifed(1);
		decisnTrail.setDecisionRemark(remark);
		this.decisnTrlDao.save(decisnTrail);
		saveCertification(decisnTrail);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(DecisionTrail decisnTrail) 
	{
			/*
			 * To inject an instance of Certification
			 */
		
			Certification cert=new Certification();
		
			cert.setAction(decisnTrail.getDecisionAction());
			cert.setTrailId(decisnTrail.getDecisionTrailId());
			cert.setTableName(MasterType.DECISION.toString());
			cert.setCertified(1);
			cert.setMaker("aditya"); // To do replace maker with JWT
			//cert.setMakerTime(autoDebitAgainstTrail.getAutodbtAgnstCrtDte());
			this.certificationDao.save(cert);
			
	}

	

}
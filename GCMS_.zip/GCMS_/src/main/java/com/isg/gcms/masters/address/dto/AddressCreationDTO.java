package com.isg.gcms.masters.address.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class AddressCreationDTO {
	
	private String addressType;

	private String address1;

	private String addrCity;

	private Integer addrPin;

	private String addrState;

	private String addrCountry;

	private Integer addrTel1;

	private Integer addrTel2;

	private String addrFax;

	private String addrEmail;

	private String addrContactPerson;

	private Integer addrContactNumber;

	private String address2;

	private String address3;

	private String address4;
	
	@JsonIgnore
	private Date addressCreatedDate= new Date();
	
}

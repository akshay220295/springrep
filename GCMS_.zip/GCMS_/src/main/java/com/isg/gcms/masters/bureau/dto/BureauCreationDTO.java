package com.isg.gcms.masters.bureau.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class BureauCreationDTO 
{
	
	private String bureauMemberId;
	private String bureauPassword;
	private String bureauCategory;
	

	@JsonIgnore
    private final Date bureauCreatedDate = new Date();
	
	
}

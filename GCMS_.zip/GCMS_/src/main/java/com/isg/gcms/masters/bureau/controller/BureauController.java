package com.isg.gcms.masters.bureau.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.bureau.dto.BureauCreationDTO;
import com.isg.gcms.masters.bureau.dto.BureauUpdateDTO;
import com.isg.gcms.masters.bureau.model.Bureau;
import com.isg.gcms.masters.bureau.service.BureauService;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_BUREAU)
public class BureauController 

{

	/*
	 * To inject an instance of BureauService
	 */	 
	@Autowired
	private BureauService bureauService;
	
	/*
	 * To get Bureau based on status (active/inactive) .
	 */	  
	@GetMapping(value= Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.bureauService.getStatus(pagination, status) ;
	}
	
	 
	/*
	 * * To Get All Bureau
	 */	  	
	@GetMapping(value= Constant.PATH_GET_ALL)
	public ResponseObj findAllBureau()
	{
		return this.bureauService.getAllBureau();
	}
	
	/*
	 *To Get all BUREAU with pagination.
	 */
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI)
	public  ResponseObj findAllBureau(@RequestBody PaginationModel pagination)
	{
		
		return 	this.bureauService.getAllBureau(pagination);
	}
	
	/*
	 * To get BUREAU based on id.
	 */
	@GetMapping(value= Constant.PATH_VARIABLE_ID)
	public  ResponseObj findBureauByBureauId(@PathVariable("bureauId") Long bureauId)
	{
		return 	this.bureauService.getById(bureauId);
	}
	
	
	/*
	 * To create a new BUREAU .
	 */
	@PostMapping
	public ResponseObj createBureau(@RequestDTO(BureauCreationDTO.class) @Validated Bureau bureau)
	{
		return this.bureauService.create(bureau);
	}
	
	/*
	 * To update existing Bureau based on id.
	 */
	@PutMapping
	public ResponseObj updateBureauById(@RequestDTO(BureauUpdateDTO.class) @Validated Bureau bureau)
	{
		return this.bureauService.update(bureau);
	}
	
	/*
	 * To soft deleting Bureau based on id.
	 */
	@DeleteMapping(value = Constant.PATH_DELETE)
	public ResponseObj deleteBureau(@PathVariable("id") Long id) 
	{

		return this.bureauService.deleteBureau(id);

	}
	
	
}

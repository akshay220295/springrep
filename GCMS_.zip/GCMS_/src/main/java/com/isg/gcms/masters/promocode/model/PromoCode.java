package com.isg.gcms.masters.promocode.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@Data
@Table(name="GCMS_PROMOCODE_MST")
public class PromoCode {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "PRMOCDE_ID")
	private Long prmocdeId;
	
	@Column (name = "PRMOCDE_NAME")
	private String prmocdeName;
	
	@Column (name = "PRMOCDE_STRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date prmocdeStartDate;
	
	@Column (name = "PRMOCDE_EXP_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date prmocdeExpiryDate;
	
	@Column (name = "PRMOCDE_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date prmocdeCreatedDate;
	
	@Column (name = "PRMOCDE_CRT_BY")
	private String prmocdeCreatedBy;
	
	@Column (name = "PRMOCDE_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date prmocdeModifiedDate;
	
	@Column (name = "PRMOCDE_MOD_BY")
	private String prmocdeModifyBy;
	
	@Column (name = "PRMOCDE_CERT")
	private Integer prmocdeCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;

}

package com.isg.gcms.masters.entity.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class EntityCreationDTO {

	private String entityName;

	private String entityDescription;
	
	@JsonIgnore
    private final Date entityCreatedDate = new Date();
}

package com.isg.gcms.masters.relation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Entity
@Data
@Table (name = "GCMS_RELATIONSHIP_MST_TRAIL")
public class RelationTrail 
{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RLTN_TRAIL_ID")
	private Long relationTrailId;
	
	@ManyToOne
	@JoinColumn (name = "RLTN_ID" , referencedColumnName =  "RLTN_ID" )
	private Relation relation;
	
	@Column (name = "RLTN_NAME")
	private String relationName;
	
	@Column (name = "RLTN_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date relationCreatedDate;
	
	@Column (name = "RLTN_CRT_BY")
	private String relationCreatedBy;
	
	@Column (name = "RLTN_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date relationModifiedDate;
	
	@Column (name = "RLTN_MOD_BY")
	private String relationModifiedBy;
	
	@Column (name = "RLTN_CERT")
	private Integer relationCertifed;
	
	@Column (name = "RELATION_CERT_MODE")
	private Integer relationCertMode;
	
	@Column (name = "RELATION_ACT")
	private String relationAction;
	
	@Column (name = "RELATION_RMRK")
	private String relationRemark;
	

}

package com.isg.gcms.masters.bureau.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;
import com.isg.gcms.masters.bureau.dao.BureauDao;
import com.isg.gcms.masters.bureau.dao.BureauTrailDao;
import com.isg.gcms.masters.bureau.dto.BureauUpdateDTO;
import com.isg.gcms.masters.bureau.model.Bureau;
import com.isg.gcms.masters.bureau.model.BureauTrail;



@Service
public class BureauServiceImp implements BureauService 
{
	/*
	 * To inject an instance of BureauDao
	 */
	@Autowired
	BureauDao bureauDao; 
	
	/*
	 * To inject an instance of BureauTrailDao
	 */
	@Autowired
	BureauTrailDao bureauTrailDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	ResponseObj res;
	
	
			
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	
	/*
	 * To find Bureau based on id and to use in other methods.
	 */
	public Optional<Bureau> findByBureauId(Long bureauId) 
	{
		
		return this.bureauDao.findById(bureauId);

	}
	
	
	/*
	 * To get all Bureau values.
	 */
	@Override
	public ResponseObj getAllBureau() 
	{
		List<Bureau> bureau=this.bureauDao.findAll();
		if(!bureau.isEmpty())
		{
			res.addData(Constant.LIST_ALL, bureau);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}


	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllBureau(PaginationModel pagination) 
	{
		Page<Bureau> bureau=this.bureauDao.findAll(pagination.pageRequest());
		List<Bureau> bureauList = bureau.getContent();
		if(!bureauList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, bureauList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.bureauDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.bureauDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}

	/*
	 * To get Bureau based on id.
	 */  
	@Override
	public ResponseObj getById(Long id) 
	{
		Optional<Bureau> bureau= this.bureauDao.findById(id);
		if(bureau.isPresent() && bureau.get().getBureauCertified()==0)
		{
			res.addData(Constant.BY_ID,ResponseDTO.accepted().convertTo(bureau.get(),BureauUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}
	
	/*
	 * To create new Bureau value.
	 */
	@Override
	public ResponseObj create(Bureau bureau) 
	{
		bureau.setBureauCertified(1);
		bureau.setBureauCreatedBy("Ajit");
		bureau.setBankId(1L);  // JWT OR SESSION
		bureau.setEntityId(1L); // JWT OR SESSION
		Bureau bure = this.bureauDao.save(bureau);
		res.addData(Constant.VALUE_CREATED, bure);
		saveBureauTrail(bureau, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(Bureau bureau) 
	{
		Optional<Bureau> bure= findByBureauId(bureau.getBureauId());
		
		if(bure.isPresent() &&  bure.get().getBureauCertified()==0)
		{
			Bureau bureauExisting = bure.get();
			bureauExisting.setBureauCertified(1);
			bureauExisting.setBureauModifiedDate(new Date());
			bureauExisting.setBureauModifiedBy("Ajit");//JWT
			this.bureauDao.save(bureauExisting);
			saveBureauTrail(bureau, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, bureau);
		}
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteBureau(Long id) 
	{
		Optional<Bureau> bureau = findByBureauId(id);

		if (bureau.isPresent() && bureau.get().getBureauCertified() == 0) 
		{
			Bureau bureauExisting = bureau.get();
			bureauExisting.setBureauCertified(1);
			this.bureauDao.save(bureauExisting);
			saveBureauTrail(bureauExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}
	
	/*
	 * To save values in Bureau Trail table
	 */
	  public void saveBureauTrail(Bureau bureau, String remarks, String action) 
	  {
		
		BureauTrail bureauTrail = (BureauTrail) ResponseDTO.accepted().convertToEntity(bureau, BureauTrail.class);
		bureauTrail.setBureau(bureau);
		bureauTrail.setBureauCreatedBy("Ajit");
		bureauTrail.setBureauCertified(1);
		bureauTrail.setBureauAction(action);
		bureauTrail.setBureauRemark(remarks);
		this.bureauTrailDao.save(bureauTrail);
		saveCertification(bureauTrail);

	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(BureauTrail bureauTrail) 
	{
			
			/*
			 * To inject an instance of Certification
			 */
			
			Certification cert = new Certification();
			
			cert.setAction(bureauTrail.getBureauAction());
			cert.setTrailId(bureauTrail.getBureauTrailId());
			cert.setTableName(MasterType.BUREAU.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(bureauTrail.getBureauCreatedDate());
			this.certificationDao.save(cert);
			
	}


}

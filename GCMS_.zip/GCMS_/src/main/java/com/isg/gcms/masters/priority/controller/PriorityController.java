package com.isg.gcms.masters.priority.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.priority.dto.PriorityCreationDTO;
import com.isg.gcms.masters.priority.dto.PriorityUpdateDTO;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.priority.service.PriorityService;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_PRIORITY)
public class PriorityController 
{
	 /*To inject an instance of PriorityService
	 */
	@Autowired
	private PriorityService priorityService;
	
	/*
	 * To get Priority based on status (active/inactive) .
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.priorityService.getStatus(pagination, status) ;
	}
	
	/*
	 * Get all Priority without pagination.
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj findAllPriority()
	{
		return this.priorityService.getAllPriority();
	}
	
	/*
	 * Get all Priority with pagination.
	 */
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI)
	public  ResponseObj findAllPriority(@RequestBody PaginationModel pagination)
	{
		System.out.println(pagination);
		return 	this.priorityService.getAllPriority(pagination);
	}
	
	/*
	 * To get Priority based on id.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public  ResponseObj findPriorityByPriorityId(@PathVariable("priorityId") Long priorityId)
	{
		return 	this.priorityService.getById(priorityId);
	}
	
	/*
	 * To get Priority based on name.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public  ResponseObj findPriorityByPriorityName(@PathVariable("priorityName") String priorityName)
	{
		return 	this.priorityService.getByName(priorityName);
	}
	
	/*
	 * To create a new Priority .
	 */
	@PostMapping
	public ResponseObj createPriority(@RequestDTO(PriorityCreationDTO.class) @Validated Priority priority)
	{
		return this.priorityService.create(priority);
	}
	
	/*
	 * To update existing Priority based on id.
	 */
	@PutMapping
	public ResponseObj updatePriorityById(@RequestDTO(PriorityUpdateDTO.class) @Validated Priority priority)
	{
		return this.priorityService.update(priority);
	}
	
	/*
	 * To soft deleting Priority based on id.
	 */
	@DeleteMapping(value = Constant.PATH_DELETE)
	public ResponseObj deletePriority(@PathVariable("id") Long id) {

		return this.priorityService.deletePriority(id);

	}
	

}

package com.isg.gcms.masters.deferral.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



import lombok.Data;
@Data
@Entity
@Table(name="GCMS_DEFERRAL_MST")
public class Deferral {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="DEFRL_ID")
	private Long deferralId;
	
	@Column(name="DEFRL_NAME")
	private String deferralName;
	
	@Column(name="DEFRL_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date deferralCreatedDate;
	
	@Column(name="DEFRL_CRTDBY")
	private String deferralCreatedBy;
	
	@Column(name="DEFRL_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date deferralModifiedDate;
	
	@Column(name="DEFRL_MODBY")
	private String deferralModifiedBy;
	
	@Column(name="DEFRL_CERTIFIED")
	private int deferralCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	
	
	
	
}

package com.isg.gcms.certification.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import org.hibernate.annotations.CreationTimestamp;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "GCMS_CERTIFICATION_HDR")
@Component
public class Certification {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "CERT_ID")
	private Long certId;

	@Size(min = 3, max = 30)
	@Column(name = "TABLE_NAME", length = 30, nullable = false)
	private String tableName;

	@Column(name = "ACTION", nullable = false)
	private String action;

	@Column(name = "TRAIL_ID")
	private long trailId;

	@Size(min = 3, max = 30)
	@Column(name = "MAKER", length = 30, nullable = false)
	private String maker;

	@Size(min = 3, max = 30)
	@Column(name = "CHECKER", length = 30)
	private String checker;

	@Column(name = "CERTIFIED", length = 1)
	private Integer certified;

	
	@Column(name = "CHK_DT")
	private Date checkedTime;

	
	@Column(name = "MK_DT")
	@CreationTimestamp
	private Date makerTime;

}

package com.isg.gcms.masters.dsa.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class DsaCreationDTO 
{
	
	private String dsaName;
	private String dsaCategory;
	private String  dsaAdd1;
	private String  dsaAdd2;
	private String  dsaAdd3;
	private String dsaCity;
	private String  dsaState;
	private String dsaCountry;
	private String dsaPin;
	private String dsaWebsite;
	private String  dsaAuthPersonName;
	private Long dsaAuthPersonMobNo;
	private String dsaAuthPersonEmail;
	private Long dsaTaxId;
	private Long dsaRegistrationNo;
	

	@JsonIgnore
    private final Date dsaCreatedDate = new Date();
	
	
}

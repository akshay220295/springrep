package com.isg.gcms.masters.autodbtagnst.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.accounttype.model.AccountType;
import com.isg.gcms.masters.autodbtagnst.dao.AutoDbtAgnstDao;
import com.isg.gcms.masters.autodbtagnst.dao.AutoDbtAgnstTrailDao;
import com.isg.gcms.masters.autodbtagnst.dto.AutoDebitAgainstUpdateDTO;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainstTrail;






@Service
public class AutoDbtAgnstServiceImp implements AutoDbtAgnstService  
{
	
	/*
	 * To inject an instance of AutoDebitAgainstDao
	 */	
	@Autowired
	private AutoDbtAgnstDao autoDbtAgnstDao;
	
	/*
	 * To inject an instance of AutoDebitAgainstTrailDao
	 */	
	@Autowired
	private AutoDbtAgnstTrailDao autoDbtAgnstTrailDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */	  
	@Autowired
	ResponseObj res;
	
	
		
	/*
	 * To inject an instance of CertificationDao
	 */	  
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To find AutoDebitAgainst based on id and to use in other methods.
	 */	  
	public Optional<AutoDebitAgainst> findByAutodbtAgnstId(Long autodbtAgnstId) 
	{
		
		return this.autoDbtAgnstDao.findById(autodbtAgnstId);

	}
	
	/*
	 * To find status based on (active/inactive)
	 */	  
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.autoDbtAgnstDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.autoDbtAgnstDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}
	
	/*
	 * To get all AutoDebitAgainst values.
	 */	  
	@Override
	public ResponseObj getAllAutoDebitAgainst() 
	{
	
		List<AutoDebitAgainst> pabt=this.autoDbtAgnstDao.findAll();
		if(!pabt.isEmpty())
		{
			res.addData(Constant.LIST_ALL, pabt);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
		
	}

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */	  
	@Override
	public ResponseObj getAllAutoDebitAgainst(PaginationModel pagination) 
	{
	
		Page<AutoDebitAgainst> pabt=this.autoDbtAgnstDao.findAll(pagination.pageRequest());
		List<AutoDebitAgainst> pabtList = pabt.getContent();
		if(!pabtList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, pabtList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
		
	}

	/*
	 * To get AutoDebitAgainst based on id.
	 */	  
	@Override
	public ResponseObj getById(Long id) {
		
		Optional<AutoDebitAgainst> autoDebitAgainst= this.autoDbtAgnstDao.findById(id);
		
		if(autoDebitAgainst.isPresent() && autoDebitAgainst.get().getAutodbtAgnstCertified()==0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(autoDebitAgainst.get(), AutoDebitAgainstUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get AutoDebitAgainst based on name.
	 */	  
	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<AutoDebitAgainst> autoDebitAgainst= this.autoDbtAgnstDao.findByautodbtAgnstNameEqualsIgnoreCase(name);
		
		if(autoDebitAgainst.isPresent() && autoDebitAgainst.get().getAutodbtAgnstCertified()==0)
		{
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(autoDebitAgainst.get(), AutoDebitAgainstUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find AutoDebitAgainst based on name
	 */	  
	@Override
	public Optional<AutoDebitAgainst> findbyAutodbtAgnstName(String autodbtAgnstName) 
	{
		return this.autoDbtAgnstDao.findByautodbtAgnstNameEqualsIgnoreCase(autodbtAgnstName);
	}
	
	/*
	 * To create new AutoDebitAgainst value.
	 */	  
	@Override
	public ResponseObj create(@RequestBody AutoDebitAgainst autoDbtAgnst) {
		autoDbtAgnst.setAutodbtAgnstCertified(1);
		autoDbtAgnst.setAutodbtAgnstCrtdBy("Ajit");
		autoDbtAgnst.setBankId(1L);  // JWT OR SESSION
		autoDbtAgnst.setEntityId(1L); // JWT OR SESSION
		AutoDebitAgainst autoDbt = this.autoDbtAgnstDao.save(autoDbtAgnst);
		res.addData(Constant.VALUE_CREATED, autoDbt);
		saveAutoDebitAgainstTrail(autoDbtAgnst, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id .
	 */	  
	@Override
	public ResponseObj update(AutoDebitAgainst autoDbtAgnst) {
		Optional<AutoDebitAgainst> autoDebitAgainst= findByAutodbtAgnstId(autoDbtAgnst.getAutodbtAgnstId());
		if(autoDebitAgainst.isPresent() && autoDebitAgainst.get().getAutodbtAgnstCertified()==0)
		{
			AutoDebitAgainst autoDebitAgainstExisting = autoDebitAgainst.get();
			autoDebitAgainstExisting.setAutodbtAgnstCertified(1);
			autoDebitAgainstExisting.setAutodbtAgnstModDte(new Date());
			autoDebitAgainstExisting.setAutodbtAgnstModBy("Ajit");//JWT
			this.autoDbtAgnstDao.save(autoDebitAgainstExisting);
			saveAutoDebitAgainstTrail(autoDbtAgnst, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, autoDbtAgnst);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To soft delete based on id
	 */	  
	@Override
	public ResponseObj deleteAutoDebitAgainst(Long id) {
		Optional<AutoDebitAgainst> autoDebitAgainst = findByAutodbtAgnstId(id);

		if (autoDebitAgainst.isPresent() && autoDebitAgainst.get().getAutodbtAgnstCertified()==0) 
		{
			AutoDebitAgainst autoDebitAgainstExisting = autoDebitAgainst.get();
			autoDebitAgainstExisting.setAutodbtAgnstCertified(1);
			this.autoDbtAgnstDao.save(autoDebitAgainstExisting);
			saveAutoDebitAgainstTrail(autoDebitAgainstExisting, Constant.VALUE_DELETED,"DELETE");
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	
	/*
	 * To save values in AutoDebitAgainst Trail table
	 */	  
	public void saveAutoDebitAgainstTrail(AutoDebitAgainst autoDebitAgainst, String remarks, String action) {

		AutoDebitAgainstTrail autoDebitAgainstTrail = (AutoDebitAgainstTrail) ResponseDTO.accepted().convertToEntity(autoDebitAgainst, AutoDebitAgainstTrail.class);
		autoDebitAgainstTrail.setAutodbtAgnst(autoDebitAgainst);
		autoDebitAgainstTrail.setAutodbtAgnstCrtdBy("Ajit");
		autoDebitAgainstTrail.setAutodbtAgnstAction(action);
		autoDebitAgainstTrail.setAutodbtAgnstRemark(remarks);
		autoDebitAgainstTrail.setAutodbtAgnstCertified(1);
		this.autoDbtAgnstTrailDao.save(autoDebitAgainstTrail);
		saveCertification(autoDebitAgainstTrail);

	}
	
	/*
	 * To save values in Certification table
	 */	  
	public void saveCertification(AutoDebitAgainstTrail autoDebitAgainstTrail) 
	{
		
			/*
			 * To inject an instance of Certification
			 */	
			
			Certification cert= new Certification();
		
			cert.setAction(autoDebitAgainstTrail.getAutodbtAgnstAction());
			cert.setTrailId(autoDebitAgainstTrail.getAutodbtAgnstTrailId());
			cert.setTableName(MasterType.AUTODBTAGNST.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(autoDebitAgainstTrail.getAutodbtAgnstCrtDte());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.relation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.relation.model.Relation;

@Repository
public interface RelationDao extends JpaRepository<Relation, Long>
{
	public Optional<Relation> findByrelationNameEqualsIgnoreCase(String name);
	
	//@Query ("SELECT M FROM Relation M WHERE M.relationCertified!=2")
	//public Page<Relation> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Relation M WHERE M.relationCertifed!=2")
	public Page<Relation> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM PromoCode M WHERE M.prmocdeCertified=0 AND M.prmocdeCertified!=2")
	public Page<PromoCode> getActiveRltn(Pageable pageable);
	
	@Query ("SELECT M FROM PromoCode M WHERE M.prmocdeCertified=1 AND M.prmocdeCertified!=2")
	public Page<PromoCode> getInactRltn(Pageable pageable);
	
	public List<Relation> findByRelationCertifed(int id);
	
}

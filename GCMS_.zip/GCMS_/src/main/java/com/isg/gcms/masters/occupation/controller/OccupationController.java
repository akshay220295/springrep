package com.isg.gcms.masters.occupation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.dto.OcptnCreationDTO;
import com.isg.gcms.masters.occupation.dto.OcptnUpdateDTO;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.service.OccupationService;

@RestController
@CrossOrigin
@RequestMapping(value=Constant.PATH_OCCUPATION)
public class OccupationController 
{
	/*
	 * To inject instance of occupation service
	 */
	@Autowired
	private OccupationService ocptnService;
	
	/*
	 * To get all values based on pagination
	 */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getall(@RequestBody PaginationModel pagination)
	{
		return this.ocptnService.getAllOcptn(pagination);
	}
	
	/*
	 * To get all values based on JpaRepository method
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj getallOccupation()
	{
		return this.ocptnService.getAllOcptn();
	}
	
	/*
	 * To get value based on id
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getValue(@PathVariable("id") Long id)
	{
		return this.ocptnService.getById(id);
	}
	
	/*
	 * To get value based on name
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("username") String username)
	{
		return this.ocptnService.findByName(username);
	}
	
	/*
	 * To create new value
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(OcptnCreationDTO.class) @Validated Occupation occupation)
	{
		return this.ocptnService.create(occupation) ;
	}
	
	/*
	 * To soft deleting value based on id
	 */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.ocptnService.deleteById(id);
	}
	
	/*
	 * To update existing value based on id
	 */
	@PutMapping 
	public ResponseObj updateOcptn(@RequestDTO(OcptnUpdateDTO.class) @Validated Occupation occupation)
	{
		return this.ocptnService.updateOcptn(occupation);
	}
	
	/*
	 * To get list of values based on status (active/inactive)
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.ocptnService.getstatus(status, pagination);
		
	}

}

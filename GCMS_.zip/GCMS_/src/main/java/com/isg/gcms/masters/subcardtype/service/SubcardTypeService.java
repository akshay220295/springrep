package com.isg.gcms.masters.subcardtype.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;

import com.isg.gcms.masters.subcardtype.model.SubcardType;

public interface SubcardTypeService {
	
	public ResponseObj getAllSubcrdTyp(PaginationModel pagination);
	
	public Optional<SubcardType> findById(Long id);

	public ResponseObj getById(Long id);

	public ResponseObj findByName(String name);
	
	public ResponseObj create(SubcardType subcrdTyp);

	public ResponseObj deleteById(Long id);

	public ResponseObj updateSubcrdTyp(SubcardType subcrdTyp);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllSubcrdTyp();


}

package com.isg.gcms.masters.address.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RBAC_ADDRESS_HDR")

public class Address  {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "AD_ID", length = 12)
	private Long addressId;

	@Column(name = "AD_TYPE")
	private String addressType;

	//@Size(min = 5, max = 50)
	@Column(name = "AD_ADDRS1", length = 50)
	private String address1;

	//@Pattern(regexp = "^[ A-Za-z]+$")
	//@Size(min = 3, max = 15)
	@Column(name = "AD_CITY", length = 12)
	private String addrCity;

	@Column(name = "AD_PIN", length = 6, nullable = false)
	private Integer addrPin;

	/*@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)*/
	@Column(name = "AD_STATE", length = 12)
	private String addrState;

	/*@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)*/
	@Column(name = "AD_CNT", length = 12)
	private String addrCountry;

	@Column(name = "AD_TEL1", length = 15)
	private Integer addrTel1;

	@Column(name = "AD_TEL2", length = 15)
	private Integer addrTel2;

	@Column(name = "AD_FAX", length = 15)
	private String addrFax;

	//@Email(regexp = "^(.+)@(.+).(.+)$")
	@Column(name = "AD_EMAIL", length = 100)
	private String addrEmail;

	/*@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)*/
	@Column(name = "AD_CON_PER", length = 150)
	private String addrContactPerson;

	@Column(name = "AD_CONT_NUM", length = 15)
	private Integer addrContactNumber;

	//@Size(min = 5, max = 50)
	@Column(name = "AD_ADDRS2", length = 50)
	private String address2;

	//@Size(min = 5, max = 50)
	@Column(name = "AD_ADDRS3", length = 50)
	private String address3;


	@Column(name = "AD_ADDRS4", length = 50)
	private String address4;

/*	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)*/
	@Column(name = "AD_CRTDBY", length = 150)
	private String addressCreatedBy;

	/*@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)
	*/
	@Column(name = "AD_MODBY", length = 150)
	private String addressModifiedBy;
	
	@Column(name = "AD_MODDT")
	private Date addressModifiedDate;
	
	@Column(name = "AD_CRTDDT", length = 50)
	private Date addressCreatedDate;

}

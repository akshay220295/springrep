package com.isg.gcms.masters.bank.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;


import org.hibernate.validator.constraints.URL;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isg.gcms.masters.address.model.Address;
import com.isg.gcms.masters.entity.model.EntityBean;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "RBAC_BANK_HDR")
public class Bank  {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "BNK_ID", length = 12)
	private Long bankId;

	@ManyToOne
	@JoinColumn(name = "BNK_EN_ID", referencedColumnName = "EN_ID")
	private EntityBean bankEntity;

	@ManyToOne
	@JoinColumn(name = "BNK_ADD_ID", referencedColumnName = "AD_ID")
	private Address bankAddress;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 15)
	@Column(name = "BNK_NAME", unique = true, length = 128, nullable = false)
	private String bankName;

	@Size(min = 2, max = 256)
	@Column(name = "BNK_DESC", length = 256, nullable = false)
	private String bankDescription;
	
	@URL(protocol = "http")
	@NotBlank(message = "Url is mandatory")
	@Column(name = "BNK_URL", length = 100)
	private String bankUrl;

	@Column(name = "BNK_CERTIFIED", length = 1)
	private Integer bankCertified;

	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name = "BNK_MODDT")
	private Date bankModifiedDate;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name = "BNK_CRTDDT", length = 50)
	private Date bankCreatedDate;
	
	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)
	@Column(name = "BNK_CRTDBY", length = 150)
	private String bankCreatedBy;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)
	@Column(name = "BNK_MODBY", length = 150)
	private String bankModifiedBy;
}

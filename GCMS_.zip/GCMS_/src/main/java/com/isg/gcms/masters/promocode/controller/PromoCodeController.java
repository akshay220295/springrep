package com.isg.gcms.masters.promocode.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.promocode.dto.PromoCodeCreationDTO;
import com.isg.gcms.masters.promocode.dto.PromoCodeUpdateDTO;
import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.promocode.service.PromoCodeService;


@RestController
@CrossOrigin("*")
@RequestMapping(value=Constant.PATH_PROMOCODE)
public class PromoCodeController {
	
	
	@Autowired
	private PromoCodeService prmocdeService;
	
	/*
	 * Getting PromoCode data with pagination
	 */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAll(@RequestBody PaginationModel pagination) {
		return this.prmocdeService.getAllPrmocde(pagination);
	}
	
	/*
	 * Getting PromoCode data without pagination
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj getAll() {
		return this.prmocdeService.getAllPrmocde();
	}
	
	/*
	 * Getting PromoCode data based on Id
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getPromoCodeById(@PathVariable("id") Long id) {
		return this.prmocdeService.getById(id);
	}
	

	/*
	 * Getting PromoCode data based on Name
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.prmocdeService.findByName(name);
	}
	
	/*
	 * To create new PromoCode
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(PromoCodeCreationDTO.class) @Validated PromoCode prmocde)
	{
		return this.prmocdeService.create(prmocde);
	}
	
	/*
	 * Soft Deleting PromoCode based on ID
	 */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.prmocdeService.deleteById(id);
	}
	
	/*
	 * Updating existing PromoCode
	 */
	@PutMapping 
	public ResponseObj update(@RequestDTO(PromoCodeUpdateDTO.class) @Validated PromoCode prmocde)
	{
		return this.prmocdeService.updatePrmocde(prmocde);
	}
	
	/*
	 * Getting PromoCode based on status
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.prmocdeService.getstatus(status,pagination);
		
	}

}

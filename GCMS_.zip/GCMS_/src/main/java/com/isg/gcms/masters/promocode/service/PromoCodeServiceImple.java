package com.isg.gcms.masters.promocode.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.promocode.dao.PromoCodeDao;
import com.isg.gcms.masters.promocode.dao.PromoCodeTrailDao;
import com.isg.gcms.masters.promocode.dto.PromoCodeUpdateDTO;
import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.promocode.model.PromoCodeTrail;




@Service
public class PromoCodeServiceImple implements PromoCodeService {
	
	/*
	 * To inject instance of PromoCode class
	 */
	@Autowired
	private PromoCodeDao prmocdeDao;
	
	/*
	 * To inject instance of PromoCodeTrail class
	 */
	@Autowired 
	private PromoCodeTrailDao prmocdeTrailDao;
	
	/*
	 * To inject instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
	
	/*
	 * To inject instance of certificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllPrmocde(PaginationModel pagination) 
	{
		Page<PromoCode> promoCode=this.prmocdeDao.findAll(pagination.pageRequest());
		List<PromoCode> promoCodeList = promoCode.getContent();
		if(!promoCodeList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, promoCodeList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new PromoCode value.
	 */
	@Override
	public ResponseObj create(PromoCode prmocde) {
		prmocde.setPrmocdeCertified(1);
		prmocde.setPrmocdeCreatedBy("Aditya");
		prmocde.setBankId(1L);  // JWT OR SESSION
		prmocde.setEntityId(1L); // JWT OR SESSION
		PromoCode pc = this. prmocdeDao.save(prmocde);
		savePromoCodeTrail(pc,Constant.VALUE_CREATED,"New");
		res.addData(Constant.VALUE_CREATED,pc);
		return res;
		
	}

	/*
	 * To get PromoCode based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<PromoCode> prmocde = this.findById(id);
		if (prmocde.isPresent() && prmocde.get().getPrmocdeCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(prmocde.get(), PromoCodeUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;

	}

	/*
	 * To find PromoCode based on id and to use in other methods.
	 */
	@Override
	public Optional<PromoCode> findById(Long id) {
		return this.prmocdeDao.findById(id);
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<PromoCode> prmocde = this.findById(id);
		if(prmocde.isPresent() && prmocde.get().getPrmocdeCertified()==0) {
			PromoCode prmocdeEx = prmocde.get();
			prmocdeEx.setPrmocdeCertified(1);
			savePromoCodeTrail(prmocdeEx,Constant.VALUE_DELETED,"DELETED");
			this.prmocdeDao.save(prmocdeEx);
			res.setMsg(Constant.VALUE_DELETED,ResponseMsgType.SUCCESS);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
			}
	
	/*
	 * To find PromoCode based on name
	 */
	public Optional<PromoCode> getByName(String name) {
		return prmocdeDao.findByPrmocdeNameEqualsIgnoreCase(name);
	}

	/*
	 * To get PromoCode based on name.
	 */
	@Override
	public ResponseObj findByName(String name) {
		Optional<PromoCode> prmocde = this.getByName(name);
		if (prmocde.isPresent() && prmocde.get().getPrmocdeCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(prmocde.get(),PromoCodeUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updatePrmocde(@RequestBody PromoCode prmocde) {
		Optional<PromoCode> prmocdeOld = findById(prmocde.getPrmocdeId());
		
		if(prmocdeOld.isPresent() && prmocdeOld.get().getPrmocdeCertified() == 0)
		{
			PromoCode prmocdeEx = prmocdeOld.get();
			prmocdeEx.setPrmocdeCertified(1);
			prmocdeEx.setPrmocdeModifiedDate(new Date());
			prmocdeEx.setPrmocdeModifyBy("Abhishek");
			this.prmocdeDao.save(prmocdeEx);
			savePromoCodeTrail(prmocde, Constant.VALUE_UPDATED , "MODIFY" );
			res.addData(Constant.VALUE_UPDATED, prmocde);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		
		return res;
	}
	
	

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.prmocdeDao.getActivePrmocde(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this. prmocdeDao. getInactPrmocde(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in PromoCode Trail table
	 */
	public void savePromoCodeTrail(PromoCode prmocde,String remark,String action) 
	{
		
		PromoCodeTrail prmocdeTrail = (PromoCodeTrail) ResponseDTO.accepted().convertToEntity(prmocde,PromoCodeTrail.class);
		prmocdeTrail.setPromoCode(prmocde);
		prmocdeTrail.setPrmocdeCreatedBy("adi");
		prmocdeTrail.setPrmocdeAction(action);
		prmocdeTrail.setPrmocdeCertified(1);
		prmocdeTrail.setPrmocdeRemark(remark);
		
		this.prmocdeTrailDao.save(prmocdeTrail);
		saveCertification(prmocdeTrail);
		
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(PromoCodeTrail prmocdeTrail) 
	{
		
		/*
		 * To inject an instance of Certification
		 */
		
		 Certification cert=new Certification();
		
			cert.setAction(prmocdeTrail.getPrmocdeAction());
			cert.setTrailId(prmocdeTrail.getPrmocdeTrailId());
			cert.setTableName(MasterType.PROMOCODE.toString());
			cert.setCertified(1);
			cert.setMaker("Abhishek"); /* To do replace maker with JWT */
			cert.setMakerTime(prmocdeTrail.getPrmocdeModifiedDate());
			this.certificationDao.save(cert);
			
	}

	/*
	 * To get all PromoCode values.
	 */
	@Override
	public ResponseObj getAllPrmocde() 
	{
		List<PromoCode> promoCode=this.prmocdeDao.findAll();
		if(!promoCode.isEmpty())
		{
			res.addData(Constant.LIST_ALL, promoCode);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

}

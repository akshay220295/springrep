package com.isg.gcms.masters.autodbtagnst.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;
import com.isg.gcms.masters.bank.model.Bank;

import lombok.Data;

@Data
@DTO
public class AutoDebitAgainstCreationDTO 
{
	
	private String autodbtAgnstName;
	

	@JsonIgnore
    private final Date autodbtAgnstCrtDte = new Date();
	
}

package com.isg.gcms.masters.maritalstatus.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;

@Repository
public interface MaritalStatusTrailDao extends JpaRepository<MaritalStatusTrail, Long> {
	
	public List<MaritalStatusTrail> findByMaritalStatus(MaritalStatus maritlSts);

}

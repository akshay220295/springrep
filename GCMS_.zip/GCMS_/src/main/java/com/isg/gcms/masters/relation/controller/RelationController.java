package com.isg.gcms.masters.relation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relation.dto.RltnCreationDTO;
import com.isg.gcms.masters.relation.dto.RltnUpdateDTO;
import com.isg.gcms.masters.relation.model.Relation;
import com.isg.gcms.masters.relation.service.RelationService;

@RestController
@CrossOrigin
@RequestMapping(value=Constant.PATH_RELATIONSHIP)
public class RelationController
{
	@Autowired
	private	RelationService rltnService;
	
	/* Getting Relation data with pagination */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		return this.rltnService.getAllRltn(pagination);
	}
	
	/* Getting Relation data without pagination */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj getAll() {
		return this.rltnService.getAllRltn();
	}
	
	/* Getting Relation data based on Id */
	@GetMapping( value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getRltnById(@PathVariable("id") Long id){
		return this.rltnService.getById(id);
	}
	

	/* Getting Relation data based on Name */
	@GetMapping( value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.rltnService.findByName(name);
	}
	
	/* To create new Relation */
	@PostMapping
	public ResponseObj create(@RequestDTO(RltnCreationDTO.class) @Validated Relation relation)
	{
		return this.rltnService.create(relation);
	}
	
	/*Soft Deleting Relation based on ID */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.rltnService.deleteById(id);
	}
	
	/* Updating existing Relation */
	@PutMapping 
	public ResponseObj update(@RequestDTO(RltnUpdateDTO.class) @Validated Relation relation)
	{
		return this.rltnService.updateRltn(relation);
	}

	/* Getting PromoCode based on status */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.rltnService.getstatus(status,pagination);
		
	}
}

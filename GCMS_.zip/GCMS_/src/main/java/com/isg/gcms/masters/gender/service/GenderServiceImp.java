package com.isg.gcms.masters.gender.service;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.employee.model.Employee;
import com.isg.gcms.masters.gender.dao.GenderDao;
import com.isg.gcms.masters.gender.dao.GenderTrailDao;
import com.isg.gcms.masters.gender.dto.GenderUpdateDTO;
import com.isg.gcms.masters.gender.model.Gender;
import com.isg.gcms.masters.gender.model.GenderTrail;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;


@Service
public class GenderServiceImp implements GenderService {

	
	/*
	 * To inject an instance of GenderDao
	 */
	@Autowired
	private GenderDao genderDao;

	
	/*
	 * To inject an instance of GenderTrailDao
	 */
	@Autowired
	private GenderTrailDao genderTrailDao;

	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
	
	
	
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllGender(PaginationModel pagination) {
		
		Page<Gender> gender=this.genderDao.findAll(pagination.pageRequest());
		List<Gender> genderList = gender.getContent();
		if(!genderList.isEmpty())
		{
			res.addData(Constant.LIST_ALL,genderList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
	
		return res;
	    }
	
	/*
	 * To get all Gender values.
	 */
	@Override
	public ResponseObj getAll() 
	{
		List<Gender> gender=this.genderDao.findAll();
		
		if(!gender.isEmpty())
		{
			res.addData(Constant.LIST_ALL,gender);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
	
		return res;
	}


	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.genderDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.genderDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}
	
	/*
	 * To get Gender based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {

		Optional<Gender> gender = this.genderDao.findById(id);

		if (gender.isPresent() && gender.get().getGenderCertified() == 0)
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(gender.get(), GenderUpdateDTO.class));
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;

	}	
	

	/*
	 * To get Gender based on name.
	 */
	@Override
	public ResponseObj getByName(String genderName) {
		
		Optional<Gender> gender = findbyGenderName(genderName);
		if (gender.isPresent() && gender.get().getGenderCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(gender.get(), GenderUpdateDTO.class));
		} else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	    }
	

	/*
	 * To find Gender based on name
	 */
	public Optional<Gender>findbyGenderName(String genderName) {

		return this.genderDao.findByGenderNameEqualsIgnoreCase(genderName);

	     }
	
	
	/*
	 * To find Gender based on id and to use in other methods.
	 */
	public Optional<Gender> findByGenderId(Long genderId) {

		return this.genderDao.findById(genderId);

	    }
	
	/*
	 * To create new Gender value.
	 */
	@Override
	public ResponseObj createGender(@RequestBody Gender gender) {
		gender.setGenderCertified(1);
		gender.setGenderCreatedBy("Pooja");
		Gender gen=this.genderDao.save(gender);
		res.addData(Constant.VALUE_CREATED, gen);
		saveGenderTrail(gender, Constant.VALUE_CREATED, "NEW");
		return res;

	    }
	
	/*
	 * To save values in GenderTrail table
	 */
	public void saveGenderTrail(Gender gender, String remarks, String action) {

		GenderTrail genderTrail = (GenderTrail) ResponseDTO.accepted().convertToEntity(gender, GenderTrail.class);
		genderTrail.setGender(gender);
		genderTrail.setGenderCreatedBy("Pooja");        /* To do replace maker with JWT */  
		genderTrail.setGenderAction(action);
		genderTrail.setGenderRemark(remarks);
		genderTrail.setGenderCertified(1); /* Pending under Certification */
		this.genderTrailDao.save(genderTrail);
		saveCertification(genderTrail);

	   }
	
	/*
	 * To save values in certification table
	 */ 
	public void saveCertification(GenderTrail genderTrail) 
	{

		/*
		 * To inject an instance of Certification
		 */
		
		Certification cert=new Certification();
		
		cert.setAction(genderTrail.getGenderAction());
		cert.setTrailId(genderTrail.getGenderTrailId());
		cert.setTableName(MasterType.GENDER.toString());
		cert.setCertified(1);
		cert.setMaker("Pooja"); /* To do replace maker with JWT */ 
		cert.setMakerTime(genderTrail.getGenderCreatedDate());
		this.certificationDao.save(cert);
	    }
	
	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateGender(Gender gender) {

		Optional<Gender> genderold= findByGenderId(gender.getGenderID());
		System.out.println("genderID is: " + gender.getGenderID());
		if (genderold.isPresent() && genderold.get().getGenderCertified() == 0) {
			Gender genderEx = genderold.get();
	     	genderEx.setGenderCertified(1);
			genderEx.setGenderModifiedDate(new Date());
			this.genderDao.save(genderEx);
			saveGenderTrail(gender, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, gender);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);
		return res;

	    }

	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) 
	{

		Optional<Gender> gender = this.genderDao.findById(id);
		if (gender.isPresent() && gender.get().getGenderCertified() == 0) 
		{
			Gender genderEx = gender.get();
			genderEx.setGenderCertified(1);
			this.genderDao.save(genderEx);
			saveGenderTrail(genderEx,Constant.VALUE_DELETED,"DELETE");
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);	
		}
		
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	 }

}
package com.isg.gcms.masters.gender.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.gender.model.Gender;

@Repository
public interface GenderDao extends JpaRepository< Gender, Long>
{
	
	public List<Gender> findByGenderCertified(int id);

	public Optional<Gender> findByGenderNameEqualsIgnoreCase(String genderName);
	
	@Query("SELECT G FROM Gender G WHERE G.genderCertified!=2")
	public Page<Gender>findAllByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Gender M where M.genderCertified=0 AND M.genderCertified!=2")
	public Page<Gender> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Gender M where M.genderCertified=1 AND M.genderCertified!=2")
	public Page<Gender> FindAllInActiveByPagination(Pageable pageable);

	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
	
	
}

package com.isg.gcms.certification.dto;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class CertificationDTO {

	@Id
	@NotNull
	private Long trailId;
	
	private Integer accept;
	
	private Integer reject;
	
	private String remarks;
}

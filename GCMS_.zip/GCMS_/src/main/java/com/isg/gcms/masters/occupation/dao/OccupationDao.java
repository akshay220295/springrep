package com.isg.gcms.masters.occupation.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.occupation.model.Occupation;

@Repository
public interface OccupationDao extends JpaRepository<Occupation, Long>
{
	
	public List<Occupation> findByOccupationCertified(int id);
	
	public Optional<Occupation> findByoccupationNameEqualsIgnoreCase(String username);
	
	@Query("SELECT M FROM Occupation M WHERE M.occupationCertified!=2")
	public Page<Occupation>  findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Occupation M WHERE M.occupationCertified=0 AND M.occupationCertified!=2")
	public Page<Occupation> getActiveOccupation(Pageable pageable);
	
	@Query ("SELECT M FROM Occupation M WHERE M.occupationCertified=1 AND M.occupationCertified!=2")
	public Page<Occupation> getInactOccupation(Pageable pageable);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name and Query we provided it.
	 */
	
}

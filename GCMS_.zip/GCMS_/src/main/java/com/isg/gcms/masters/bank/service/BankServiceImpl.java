package com.isg.gcms.masters.bank.service;

import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.address.model.Address;
import com.isg.gcms.masters.address.service.AddressService;
import com.isg.gcms.masters.bank.dao.BankDao;
import com.isg.gcms.masters.bank.dao.BankTrailDao;
import com.isg.gcms.masters.bank.dto.BankCreationDTO;
import com.isg.gcms.masters.bank.dto.BankUpdateDTO;
import com.isg.gcms.masters.bank.model.Bank;
import com.isg.gcms.masters.bank.model.BankTrail;
import com.isg.gcms.masters.entity.dao.EntityDao;
import com.isg.gcms.masters.entity.model.EntityBean;
import com.isg.gcms.masters.entity.service.EntityService;



@Service
@Transactional
public class BankServiceImpl implements BankService {

	final Logger logger = LogManager.getLogger(BankServiceImpl.class);

	// To inject an instance of BankDao
	@Autowired
	public BankDao bankDao;

	// To inject an instance of EntityDao
	@Autowired
	public EntityDao entityDao;

	// To inject an instance of BankTrailDao
	@Autowired
	private BankTrailDao bankTrailDao;

	// To inject an instance of CertificationDao
//	@Autowired
//	private CertificationDao certificationDao;

	// To inject an instance of EntityService
	@Autowired
	private EntityService entityService;

	@Autowired
	private AddressService addressService;

	// To inject an instance of Certification
	@Autowired
	private Certification cert;
	
	@Autowired
	private CertificationDao certificationDao;

	// To inject an instance of ResponseObj
	@Autowired
	private ResponseObj res;
	

	// To Do - applying validations, if list is empty or all not certified
	@Override
	public ResponseObj getAllBank(Pageable xPageable) {

		res.addData("Bank List", this.bankDao.findAll(xPageable));
		return res;
	}

	@Override
	public ResponseObj getByName(String bankName) {

		Optional<Bank> bank = findbyBankName(bankName);
		if (bank.isPresent() && bank.get().getBankCertified() == 0) {
			res.addData("Bank by bank name", ResponseDTO.accepted().convertTo(bank.get(), BankCreationDTO.class));
		} 
		else
			res.setActionError("Bank not found with name: " + bankName);

		return res;
	}

	@Override
	public Optional<Bank> findbyBankName(String bankName) {

		return this.bankDao.findByBankNameIgnoreCase(bankName);
	}

	public Optional<Bank> findByBankId(Long bankId) {
		
		return this.bankDao.findById(bankId);   // To Think filter wrt certification here or not 

	}

	@Override
	public ResponseObj getBankById(long bankId) {

		Optional<Bank> bank = findByBankId(bankId);
		if (bank.isPresent() && bank.get().getBankCertified() == 0) {
			res.addData("Bank by bank Id", ResponseDTO.accepted().convertTo(bank.get(), BankCreationDTO.class));
		}

		else
			res.setActionError("Bank not found for id: " + bankId);

		return res;
	}

	@Override
	public ResponseObj getByEntity(Long entityId) {

		res.addData("Bank Dropdown by Entity", ResponseDTO.accepted()
				.convertTo(this.bankDao.findAll().stream()
						.filter(b -> b.getBankCertified() == 0 && b.getBankEntity().getEntityId().equals(entityId))
						.collect(Collectors.toList()), BankUpdateDTO.class));
		return res;
	}

	@Override
	public ResponseObj saveBank(Bank bank) {

		Optional<EntityBean> entity = this.entityService.findByEntityId(bank.getBankEntity().getEntityId());
		Optional<Address> address =  this.addressService.findAddressById(bank.getBankAddress().getAddressId());
		
		if (entity.isPresent() && address.isPresent()) {

			bank.setBankEntity(entity.get());
			bank.setBankCreatedBy("Srushti"); // To do replace maker with JWT
			bank.setBankCertified(1);

			this.bankDao.save(bank);

			saveBankTrail(bank, "Bank Created", "New");
			res.addData("Save Bank", ResponseDTO.accepted().convertTo(bank, BankCreationDTO.class));

		} 
		else
			res.setActionError("Bank could not be saved as entity or address not found ");

		return res;
	}

	public void saveCertification(BankTrail bankTrail) {

		cert.setAction(bankTrail.getBankAction());
		cert.setTrailId(bankTrail.getBankTrailId());
		cert.setTableName("Bank");
		cert.setCertified(1);
		cert.setMaker("Srushti"); // To do replace maker with JWT
		cert.setMakerTime(bankTrail.getBankCreatedDate());
		this.certificationDao.save(cert);
	}

	public void saveBankTrail(Bank bank, String remarks, String action) {

		BankTrail bankTrail = (BankTrail) ResponseDTO.accepted().convertToEntity(bank, BankTrail.class);
		bankTrail.setBank(bank);
		bankTrail.setBankCreatedBy("Srushti"); // To do replace maker with JWT
		bankTrail.setBankAction(action);
		bankTrail.setBankRemark(remarks);
		bankTrail.setBankCertified(1); // Pending under Certification

		this.bankTrailDao.save(bankTrail);

		//saveCertification(bankTrail);

	}

	@Override
	public ResponseObj updateBank(Bank bank) {

		Optional<Bank> bankO = findByBankId(bank.getBankId());
		if (bankO.isPresent() && bankO.get().getBankCertified() == 0) {
			Bank bankExisting = bankO.get();
			bankExisting.setBankCertified(1);
			this.bankDao.save(bankExisting);

			saveBankTrail(bank, "Bank Updated", "MODIFY");
			res.addData("Bank Update", bank);

		} 
		else
			res.setActionError("Bank not found with Id " + bank.getBankId());

		return res;
	}

	@Override
	public ResponseObj deleteBank(Long id) {

		Optional<Bank> bank = findByBankId(id);

		if (bank.isPresent() && bank.get().getBankCertified() == 0) 
		{
			Bank bankExisting = bank.get();
			bankExisting.setBankCertified(1);
			this.bankDao.save(bankExisting);
			
			saveBankTrail(bankExisting, "Bank Delete", "DELETE");
			
			res.setMsg("Bank Deleted", ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError("Bank not found with id " + id);

		return res;
	}

	/*
	 * @Override public ResponseObj getAllBank() {
	 * 
	 * List<Bank> listBank = this.bankDao.findAll();
	 * 
	 * if (listBank.isEmpty() || listBank.stream().allMatch(b ->
	 * b.getBankCertified() != 0)) res.setActionError(API_CALL + message); else
	 * res.addData("List of Banks", listBank.stream().filter(b ->
	 * b.getBankCertified() == 0).collect(Collectors.toList()));
	 * 
	 * return res;
	 * 
	 * }
	 */
}

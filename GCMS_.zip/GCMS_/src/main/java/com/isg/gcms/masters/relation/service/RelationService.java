package com.isg.gcms.masters.relation.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relation.model.Relation;

public interface RelationService 
{	
	public ResponseObj getAllRltn(PaginationModel pagination);

	public ResponseObj create(Relation relation);

	public ResponseObj getById(Long id);

	public Optional<Relation> findById(Long id);

	public ResponseObj deleteById(Long id);

	public ResponseObj findByName(String name);

	public ResponseObj updateRltn(Relation relation);

	public ResponseObj getAllRltn();
	
	public ResponseObj getstatus(String status, PaginationModel pagination);
}

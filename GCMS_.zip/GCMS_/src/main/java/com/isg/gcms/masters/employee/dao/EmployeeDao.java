package com.isg.gcms.masters.employee.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.employee.model.Employee;

@Repository
public interface EmployeeDao extends JpaRepository<Employee, Long>
{
	
	@Query ("SELECT M FROM Employee M WHERE M.employeeFullName LIKE %:fname%")
	public Optional<Employee> findByemployeeFullNameEqualsIgnoreCase(String fname );
	
	@Query ("SELECT M FROM Employee M WHERE M.employeeCertified!=2")
	public Page<Employee> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Employee M WHERE M.employeeCertified=0 AND M.employeeCertified!=2")
	public Page<Employee> getActiveEmp(Pageable pageable);
	
	@Query ("SELECT M FROM Employee M WHERE M.employeeCertified=1 AND M.employeeCertified!=2")
	public Page<Employee> getInactEmp(Pageable pageable);

	public List<Employee> findByemployeeCertified(int id);
}

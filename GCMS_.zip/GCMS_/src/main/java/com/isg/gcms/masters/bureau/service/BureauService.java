package com.isg.gcms.masters.bureau.service;


import org.springframework.stereotype.Service;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.bureau.model.Bureau;


@Service
public interface BureauService 
{
	public ResponseObj getAllBureau();
	public ResponseObj getAllBureau(PaginationModel pagination);
	public ResponseObj getStatus(PaginationModel pagination, String status);
	public ResponseObj getById(Long id);
	public ResponseObj update(Bureau bureau);
	public ResponseObj deleteBureau(Long id);
	public ResponseObj create(Bureau bureau);
	
	
}

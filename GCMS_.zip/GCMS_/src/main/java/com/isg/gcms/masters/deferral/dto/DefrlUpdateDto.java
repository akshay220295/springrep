package com.isg.gcms.masters.deferral.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class DefrlUpdateDto {
	@Id
	@NotNull
	private Long deferralId;
	
	private String deferralName;
	
	@JsonIgnore
	private final Date deferralModifiedDate = new Date();
	
	
}

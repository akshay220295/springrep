package com.isg.gcms.masters.deferral.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.deferral.model.Deferral;

@Service
public interface DeferralService {

	public ResponseObj getAllDefrl(PaginationModel pagination);
	
	public ResponseObj create(Deferral deferral);
	
	public ResponseObj getById(Long id);
	
	public Optional<Deferral> findDefrlId(Long id);
	
	public ResponseObj deletebyId(Long id);
	
	public ResponseObj findByName(String username);
	
	public ResponseObj updateDefrl(Deferral deferral);
	
	public ResponseObj getStatus(String status, PaginationModel pagination);
	
	public ResponseObj getAllDefrl();
}


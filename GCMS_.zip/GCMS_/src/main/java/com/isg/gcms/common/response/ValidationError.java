package com.isg.gcms.common.response;

import java.util.ArrayList;
import java.util.List;

public class ValidationError
{

	private List<FieldError> fieldErrors = new ArrayList<>();

	private String actionError;

	public ValidationError()
	{
		super();
	}

	/* To add field errors */
	public void addFieldError(String path, String message)
	{
		FieldError error = new FieldError(path, message);
		fieldErrors.add(error);
	}

	/* To get list of field errors */
	public List<FieldError> getFieldErrors()
	{
		return fieldErrors;
	}

	/* To set field errors */
	public void setFieldErrors(List<FieldError> fieldErrors)
	{
		this.fieldErrors = fieldErrors;
	}

	/* To get action error */
	public String getActionError()
	{
		return actionError;
	}

	/* To set action error */
	public void setActionError(String actionError)
	{
		this.actionError = actionError;
	}

	@Override
	public String toString()
	{
		StringBuilder strBuilder = new StringBuilder("");
		for (FieldError FieldError : fieldErrors)
		{
			strBuilder.append(FieldError.toString() + ", ");
		}
		if (strBuilder.length() > 2)
			strBuilder.deleteCharAt(strBuilder.length() - 2);
		return strBuilder.toString();
	}
}

package com.isg.gcms.masters.cardtype.dto;

import java.util.Date;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class CardTypeCreationDTO 
{
	
	private String cardTypeName;

	@JsonIgnore
    private final Date cardTypeCreatedDate = new Date();
	
	
}

package com.isg.gcms.masters.deferral.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


import lombok.Data;

@Data
@Entity
@Table(name="GCMS_DEFERRAL_MST_TRAIL")
public class DeferralTrail {

	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column(name="DEFRL_TRAIL_ID")
	private long deferralTrailId;
	
	@ManyToOne
	@JoinColumn(name = "DEFRL_ID", referencedColumnName = "DEFRL_ID")
	private Deferral deferral;
	
	@Column(name="DEFRL_NAME")
	private String deferralName;
	
	@Column(name="DEFRL_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date deferralCreatedDate;
	
	@Column(name="DEFRL_CRTDBY")
	private String deferralCreatedBy;
	
	@Column(name="DEFRL_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date deferralModifiedDate;
	
	@Column(name="DEFRL_MODBY")
	private String deferralModifiedBy;
	
	@Column(name="DEFRL_CERTIFIED")
	private int deferralCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column(name="DEFRL_CERT_MODE")
	private Integer deferralCertMode;
	
	@Column(name="DEFRL_ACTION")
	private String deferralAction;
	
	@Column(name="DEFRL_REMARK")
	private String deferralRemark;
}

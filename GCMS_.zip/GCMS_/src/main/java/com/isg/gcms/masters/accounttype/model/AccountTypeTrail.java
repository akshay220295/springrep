package com.isg.gcms.masters.accounttype.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "GCMS_ACCOUNT_TYPE_MST_TRAIL")
public class AccountTypeTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "AC_TYP_TRAIL_ID")
	private Long accountTypeTrailId;
	
	@ManyToOne
	@JoinColumn(name = "AC_TYP_ID" , referencedColumnName= "AC_TYP_ID" )
	private AccountType accountType;
	
	@Column (name = "AC_TYP_NAME")
	private String accountTypeName;
	
	@Column (name = "AC_TYP_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date accountTypeCreatedDate;
	
	@Column (name = "AC_TYP_CRT_BY")
	private String accountTypeCreatedBy;
	
	@Column (name = "AC_TYP_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date accountTypeModifiedDate;
	
	@Column (name = "AC_TYP_MOD_BY")
	private String accountTypeModifiedBy;
	
	@Column (name = "AC_TYP_CERT")
	private Integer accountTypeCertified;
	
	@Column (name = "AC_TYP_CERT_MODE")
	private Integer accountTypeCertMode;
	
	@Column (name = "DECISN_ACT")
	private String accountTypeAction;
	
	@Column (name = "AC_TYP_RMRK")
	private String accountTypeRemark;

}

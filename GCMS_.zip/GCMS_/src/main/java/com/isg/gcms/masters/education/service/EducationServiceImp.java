package com.isg.gcms.masters.education.service;



import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.dsa.model.Dsa;
import com.isg.gcms.masters.education.dao.EducationDao;
import com.isg.gcms.masters.education.dao.EducationTrailDao;
import com.isg.gcms.masters.education.dto.EducationUpdateDTO;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.model.EducationTrail;

@Service
public class EducationServiceImp implements EducationService
{
	
	/*
	 * To inject an instance of EducationDao
	 */	 
	@Autowired
	private EducationTrailDao educationTrailDao;
	
	
	/*
	 * To inject an instance of Education Trail Dao
	 */
	@Autowired
	EducationDao educationDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	ResponseObj res;
	
	
	
				
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To find Education based on id and to use in other methods.
	 */
	public Optional<Education> findByEducationId(Long educationId) 
	{
		
		return this.educationDao.findById(educationId);

	}
	
	/*
	 * To get all Education values.
	 */
	@Override
	public ResponseObj getAllEducation() 
	{
		List<Education> education=this.educationDao.findAll();
		if(!education.isEmpty())
		{
			res.addData(Constant.LIST_ALL, education);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllEducation(PaginationModel pagination) 
	{
		
		Page<Education> education=this.educationDao.findAll(pagination.pageRequest());
		List<Education> educationList = education.getContent();
		if(!educationList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, educationList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
		
		
	}

	
	/*
	 * To get Education based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		
		Optional<Education> education=this.educationDao.findById(id);
		if(education.isPresent() && education.get().getEducationCertified()==0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(education.get(), EducationUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}

		return res; 
		
		
	}
	
	/*
	 * To get Education based on name.
	 */
	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<Education> education=this.educationDao.findByEducationNameEqualsIgnoreCase(name);
		
		if(education.isPresent() && education.get().getEducationCertified()==0)
		{
			res.addData(Constant.BY_NAME,ResponseDTO.accepted().convertTo(education.get(), EducationUpdateDTO.class ) );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To find Education based on name
	 */
	@Override
	public Optional<Education> findbyEducationName(String educationName) 
	{
		
		return this.educationDao.findByEducationNameEqualsIgnoreCase(educationName);
	}
	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.educationDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.educationDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}

	/*
	 * To create new Education value.
	 */
	@Override
	public ResponseObj create(@RequestBody Education education) 
	{
		education.setEducationCertified(1);
		education.setEducationCreatedBy("Ajit");
		Education edu = this.educationDao.save(education);
		res.addData(Constant.VALUE_CREATED, edu);
		saveEducationTrail(education, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(Education education) 
	{
		Optional<Education> edu= findByEducationId(education.getEducationId());
		if(edu.isPresent() && edu.get().getEducationCertified()==0)
		{
			Education eduExisting=edu.get();
			eduExisting.setEducationCertified(1);
			eduExisting.setEducationModifiedBy("Ajit");//JWT
			this.educationDao.save(eduExisting);
			saveEducationTrail(education,Constant.VALUE_UPDATED,"MODIFY");
			res.addData(Constant.VALUE_UPDATED, education);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteEducation(Long id) 
	{
		Optional<Education> education = findByEducationId(id);

		if (education.isPresent() && education.get().getEducationCertified() == 0) {
			Education eduExisting = education.get();
			eduExisting.setEducationCertified(1);
			this.educationDao.save(eduExisting);
			saveEducationTrail(eduExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
		
	}

	

	/*
	 * To save values in EducationTrail table
	 */
	private void saveEducationTrail(Education education, String remark, String action) 
	{
		EducationTrail educationTrail = (EducationTrail) ResponseDTO.accepted().convertToEntity(education, EducationTrail.class);
		educationTrail.setEducation(education);
		educationTrail.setEducationCreatedBy("Ajit");
		educationTrail.setEducationAction(action);
		educationTrail.setEducationRemark(remark);
		educationTrail.setEducationCertified(1);
		
		this.educationTrailDao.save(educationTrail);
		saveCertification(educationTrail);
		
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(EducationTrail educationTrail) 
	{
			/*
			 * To inject an instance of Certification
			 */
		
		 	Certification cert=new Certification() ;
		
			cert.setAction(educationTrail.getEducationAction());
			cert.setTrailId(educationTrail.getEducationTrailId());
			cert.setTableName(MasterType.EDUCATION.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(educationTrail.getEducationCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.priority.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.priority.dao.PriorityDao;
import com.isg.gcms.masters.priority.dao.PriorityTrailDao;
import com.isg.gcms.masters.priority.dto.PriorityUpdateDTO;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.priority.model.PriorityTrail;

@Service
public class PriorityServiceImp implements PriorityService
{
	/*
	 * To inject an instance of PriorityDao
	 */
	@Autowired
	private PriorityDao priorityDao;
	
	
	/*
	 * To inject an instance of Priority Trail Dao
	 */
	@Autowired
	private PriorityTrailDao priorityTrailDao; 
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	ResponseObj res;
	
	
				
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	
	/*
	 * To find Priority based on id and to use in other methods.
	 */
	public Optional<Priority> findByPriorityId(Long priorityId) 
	{
		
		return this.priorityDao.findById(priorityId);

	}
	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.priorityDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.priorityDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}
	
	/*
	 * To get all Priority values.
	 */
	@Override
	public ResponseObj getAllPriority() 
	{
		List<Priority> priority=this.priorityDao.findAll();
		if(!priority.isEmpty())
		{
			res.addData(Constant.LIST_ALL, priority);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllPriority(PaginationModel pagination) 
	{
		Page<Priority> priority=this.priorityDao.findAll(pagination.pageRequest());
		List<Priority> priorityList = priority.getContent();
		if(!priorityList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, priorityList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get Priority based on id.
	 */
	@Override
	public ResponseObj getById(Long id) 
	{
		Optional<Priority> priority=this.priorityDao.findById(id);
		if(priority.isPresent() && priority.get().getPriorityCertified()==0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(priority.get(), PriorityUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Priority based on name
	 */
	@Override
	public Optional<Priority> findbyPriorityName(String priorityName) 
	{
		
		return this.priorityDao.findByPriorityNameEqualsIgnoreCase(priorityName);
	}
	
	/*
	 * To get Priority based on name.
	 */
	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<Priority> priority=this.priorityDao.findByPriorityNameEqualsIgnoreCase(name);
		if(priority.isPresent() && priority.get().getPriorityCertified()==0)
		{
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(priority.get(), PriorityUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}
	
	/*
	 * To create new Priority value.
	 */
	@Override
	public ResponseObj create(@RequestBody Priority priority) 
	{
		priority.setPriorityCertified(1);
		priority.setPriorityCreatedBy("Ajit");
		priority.setBankId(1L);  // JWT OR SESSION
		priority.setEntityId(1L); // JWT OR SESSION
		Priority prior = this.priorityDao.save(priority);
		res.addData(Constant.VALUE_CREATED, prior);
		savePriorityTrail(priority, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(Priority priority) 
	{
		Optional<Priority> prior= findByPriorityId(priority.getPriorityId());
		
		if(prior.isPresent() &&  prior.get().getPriorityCertified()==0)
		{
			Priority priorityExisting = prior.get();
			priorityExisting.setPriorityCertified(1);
			priorityExisting.setPriorityModifiedDate(new Date());
			priorityExisting.setPriorityModifiedBy("Ajit");//JWT
			this.priorityDao.save(priorityExisting);
			savePriorityTrail(priority, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED , priority);
		}
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deletePriority(Long id) 
	{
		Optional<Priority> priority = findByPriorityId(id);

		if (priority.isPresent() && priority.get().getPriorityCertified() == 0) {
			Priority priorityExisting = priority.get();
			priorityExisting.setPriorityCertified(1);
			this.priorityDao.save(priorityExisting);
			savePriorityTrail(priorityExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}


	/*
	 * To save values in Priority Trail table
	 */
	public void savePriorityTrail(Priority priority, String remarks, String action) 
	{

		PriorityTrail priorityTrail = (PriorityTrail) ResponseDTO.accepted().convertToEntity(priority, PriorityTrail.class);
		priorityTrail.setPriority(priority);
		
		priorityTrail.setPriorityCreatedBy("Ajit");
		priorityTrail.setPriorityAction(action);
		priorityTrail.setPriorityRemark(remarks);
		priorityTrail.setPriorityCertified(1);
		
		
		this.priorityTrailDao.save(priorityTrail);
		saveCertification(priorityTrail);

	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(PriorityTrail priorityTrail) 
	{
			
			/*
			 * To inject an instance of Certification
			 */
		
			Certification cert=new Certification();
			
			cert.setAction(priorityTrail.getPriorityAction());
			cert.setTrailId(priorityTrail.getPriorityTrailId());
			cert.setTableName(MasterType.PRIORITY.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(priorityTrail.getPriorityCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.subcardtype.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class SubcrdTypCreationDTO 
{
	private String subcardTypeName;

	@JsonIgnore
	private final Date subcardTypeCreatedDate = new Date();

}

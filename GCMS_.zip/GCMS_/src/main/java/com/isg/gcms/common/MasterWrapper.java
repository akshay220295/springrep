package com.isg.gcms.common;

import java.util.List;

import com.isg.gcms.masters.accounttype.model.AccountTypeTrail;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainstTrail;
import com.isg.gcms.masters.bank.model.BankTrail;
import com.isg.gcms.masters.bureau.model.BureauTrail;
import com.isg.gcms.masters.cardtype.model.CardTypeTrail;
import com.isg.gcms.masters.channel.model.ChannelTrail;
import com.isg.gcms.masters.decision.model.DecisionTrail;
import com.isg.gcms.masters.deferral.model.DeferralTrail;
import com.isg.gcms.masters.dsa.model.DsaTrail;
import com.isg.gcms.masters.education.model.EducationTrail;
import com.isg.gcms.masters.employee.model.EmployeeTrail;
import com.isg.gcms.masters.exception.model.ExceptionMstTrail;
import com.isg.gcms.masters.gender.model.GenderTrail;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;
import com.isg.gcms.masters.occupation.model.OccupationTrail;
import com.isg.gcms.masters.priority.model.PriorityTrail;
import com.isg.gcms.masters.promocode.model.PromoCodeTrail;
import com.isg.gcms.masters.relation.model.RelationTrail;
import com.isg.gcms.masters.residentstatus.model.ResidentTrail;
import com.isg.gcms.masters.salutation.model.SalutationTrail;
import com.isg.gcms.masters.subcardtype.model.SubcardTypeTrail;
import com.isg.gcms.masters.vip.model.VipTrail;

import lombok.Data;

@Data
public class MasterWrapper
{
	private List<BankTrail> banks;

	private List<AutoDebitAgainstTrail> autoDebitAgainsts;

	private List<BureauTrail> bureaus;

	private List<CardTypeTrail> cardTypes;

	private List<DsaTrail> dsas;

	private List<EducationTrail> educations;

	private List<PriorityTrail> prioritys;

	private List<SalutationTrail> salutations;
	
	private List<DecisionTrail> decisions;
	
	private List<ChannelTrail> channels;
	
	private List<ResidentTrail> residents;
	
	private List<GenderTrail> genders;
	
	private List<AccountTypeTrail> accountTypes;
	
	private List<DeferralTrail> deferrels;
	
	private List<ExceptionMstTrail> exceptions;
	 
	private List<OccupationTrail> occupations;
	
	private List<PromoCodeTrail> promocodes;
	
	private List<RelationTrail> relations;
	
	private List<SubcardTypeTrail> subCardTypes;
	
	private List<VipTrail> vips;
	
	private List<EmployeeTrail> employees;
	
	private List<MaritalStatusTrail> masritalSatus;
	
	

}

package com.isg.gcms.masters.salutation.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.salutation.model.Salutation;

@Repository
public interface SalutationDao extends JpaRepository<Salutation,Long> 
	{
	
		public List<Salutation> findBySalutationCertified(int id);
	
		public Optional<Salutation> findBySalutationNameEqualsIgnoreCase(String name);
		
		@Query("SELECT M FROM Salutation M WHERE M.salutationCertified!=2")
		public Page<Salutation> findAllByPagination(Pageable pageble);
		
		@Query("SELECT M FROM Salutation M where M.salutationCertified=0 AND M.salutationCertified!=2")
		public Page<Salutation> FindAllActiveByPagination(Pageable pageable);
		
		@Query("SELECT M FROM Salutation M where M.salutationCertified=1 AND M.salutationCertified!=2")
		public Page<Salutation> FindAllInActiveByPagination(Pageable pageable);
	}

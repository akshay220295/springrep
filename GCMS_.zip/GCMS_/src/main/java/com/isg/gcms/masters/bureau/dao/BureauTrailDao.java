package com.isg.gcms.masters.bureau.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.bureau.model.Bureau;
import com.isg.gcms.masters.bureau.model.BureauTrail;

@Repository
public interface BureauTrailDao extends JpaRepository<BureauTrail , Long>
{

	public List<BureauTrail> findByBureau(Bureau Bureau);
}

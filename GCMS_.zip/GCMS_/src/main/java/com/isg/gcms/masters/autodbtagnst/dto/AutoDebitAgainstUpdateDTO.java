package com.isg.gcms.masters.autodbtagnst.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class AutoDebitAgainstUpdateDTO 
{

	@Id
    @NotNull
    private Long autodbtAgnstId;
	private String autodbtAgnstName;
	
	@JsonIgnore
    private final Date autodbtAgnstModDte = new Date();
}

package com.isg.gcms.masters.bureau.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@DTO
@Data
public class BureauUpdateDTO 
{

	@Id
    @NotNull
    private Long bureauId;
	private String bureauMemberId;
	private String bureauPassword;
	private String bureauCategory;
	
	
	@JsonIgnore
    private final Date bureauModifiedDate = new Date();
}

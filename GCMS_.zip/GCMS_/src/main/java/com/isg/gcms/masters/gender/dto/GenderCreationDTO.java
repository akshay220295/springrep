package com.isg.gcms.masters.gender.dto;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;


@Data
@DTO
public class GenderCreationDTO
 {
	private String genderName;

	@JsonIgnore
    private final Date genderCreatedDate = new Date();
	
 }

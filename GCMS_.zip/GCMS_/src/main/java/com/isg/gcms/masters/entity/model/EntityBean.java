package com.isg.gcms.masters.entity.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "ACS_ENTITY_HDR")
public class EntityBean
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "EN_ID", length = 12)
	private Long entityId;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 15)
	@Column(name = "EN_NAME", length = 128)
	private String entityName;

	@Column(name = "EN_DESCRIPTION", length = 256)
	private String entityDescription;

	@Column(name = "EN_CRTDDT")
	private Date entityCreatedDate;

	@Column(name = "EN_CRTDBY", length = 30)
	private String entityCreatedBy;

	@Column(name = "EN_MODDT")
	private Date entityModifiedDate;

	@Column(name = "EN_MODBY", length = 30)
	private String entityModifiedBy;

}

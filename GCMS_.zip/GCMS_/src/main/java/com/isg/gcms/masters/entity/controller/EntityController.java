package com.isg.gcms.masters.entity.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.entity.dto.EntityCreationDTO;
import com.isg.gcms.masters.entity.dto.EntityUpdateDTO;
import com.isg.gcms.masters.entity.model.EntityBean;
import com.isg.gcms.masters.entity.service.EntityService;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_ENTITY)
public class EntityController {

	// To inject instance of EntityService
	@Autowired
	private EntityService entityService;

//	@Autowired
//	private ResponseObj responseObj;

	@GetMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getEntityById(@PathVariable("id") int entityId) {

		return this.entityService.getEntity(entityId);
	}

	@GetMapping(value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getEntityByName(@PathVariable("name") String entityName) {

		return this.entityService.getEntityByName(entityName);

	}

	@GetMapping
	public ResponseObj getAllEntities(Pageable pageable) {

		return this.entityService.getAllEntities(pageable);
	}

	@PostMapping
	public ResponseObj saveEntity(@RequestDTO(EntityCreationDTO.class) @Validated EntityBean entity) {
	
			return this.entityService.saveEntity(entity);

	}

	@PutMapping
	public ResponseObj updateEntity(@RequestDTO(EntityUpdateDTO.class) @Validated EntityBean entity) {
		
			return this.entityService.updateEntity(entity);

	}

	@DeleteMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj deleteEntity(@PathVariable("id") Long id) {
		
		
		return this.entityService.deleteEntity(id);
	}
}

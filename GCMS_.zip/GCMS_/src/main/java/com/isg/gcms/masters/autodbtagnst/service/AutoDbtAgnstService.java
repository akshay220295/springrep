package com.isg.gcms.masters.autodbtagnst.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;


@Service
public interface AutoDbtAgnstService 
{
	public ResponseObj getAllAutoDebitAgainst();
	public ResponseObj getAllAutoDebitAgainst(PaginationModel pagination);
	public ResponseObj getStatus(PaginationModel pagination, String status);
	public ResponseObj getById(Long id);
	public ResponseObj create(AutoDebitAgainst autoDbtAgnst);
	public ResponseObj update(AutoDebitAgainst autoDbtAgnst);
	public ResponseObj deleteAutoDebitAgainst(Long id);
	public ResponseObj getByName(String name);
	public Optional<AutoDebitAgainst> findbyAutodbtAgnstName(String autodbtAgnstName);
}

package com.isg.gcms.masters.occupation.service;


import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;
import com.isg.gcms.masters.occupation.dao.OccupationDao;
import com.isg.gcms.masters.occupation.dao.OccupationTrailDao;
import com.isg.gcms.masters.occupation.dto.OcptnCreationDTO;
import com.isg.gcms.masters.occupation.dto.OcptnUpdateDTO;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.model.OccupationTrail;

@Service
public class OccupationServiceImp implements OccupationService
{
	/*
	 * To inject instance of occupationDao
	 */
	@Autowired
	private OccupationDao ocptnDao;
	
	/*
	 * To inject instance of occupationTrailDao
	 */
	@Autowired
	private OccupationTrailDao ocptnTrlDao;
	
	/*
	 * To inject instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
							
	/*
	 * To inject instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllOcptn(PaginationModel pagination)
	{
		Page<Occupation> occPage = this.ocptnDao.findAllByPagination(pagination.pageRequest());
		List<Occupation> occPageList = occPage.getContent();
		if(!occPageList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, occPageList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
		
	}
	
	/*
	 * To get all Occupation values.
	 */
	@Override
	public ResponseObj getAllOcptn() {
		List<Occupation> occList = this.ocptnDao.findAll();
		if(!occList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, occList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find Occupation based on id and to use in other methods.
	 */
	public Optional<Occupation> findOccuById(Long id)
	{
		return this.ocptnDao.findById(id);
		
	}

	/*
	 * To get Occupation based on id.
	 */
	@Override
	public ResponseObj getById(Long id) 
	{
		
		Optional<Occupation> occupation = findOccuById(id);
		if(occupation.isPresent() && occupation.get().getOccupationCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(occupation.get(),OcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get Occupation based on name.
	 */
	@Override
	public ResponseObj findByName(String username) 
	{
		Optional<Occupation> occupation = findByOccuName(username);
		if(occupation.isPresent() && occupation.get().getOccupationCertified()==0)
		{
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(occupation.get(), OcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Occupation based on name
	 */
	public Optional<Occupation> findByOccuName(String username)
	{
		return this.ocptnDao.findByoccupationNameEqualsIgnoreCase(username);
	}
	
	/*
	 * To create new Occupation value.
	 */
	@Override
	public ResponseObj create(@RequestBody Occupation occupation) 
	{
		occupation.setOccupationCertified(1);
		occupation.setBankId(1L);  // JWT OR SESSION
		occupation.setEntityId(1L); // JWT OR SESSION
		Occupation occu=this.ocptnDao.save(occupation);
		res.addData(Constant.VALUE_CREATED, occu );
		saveOcptnTrail(occupation , Constant.VALUE_CREATED , "NEW");
		return res;
	}

	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id)
	{
		Optional<Occupation> occupation = findOccuById(id);
		if(occupation.isPresent() && occupation.get().getOccupationCertified() == 0)
		{
			Occupation occupationEx = occupation.get();
			occupationEx.setOccupationCertified(1);
			saveOcptnTrail(occupationEx , Constant.VALUE_DELETED, "DELETE");
			this.ocptnDao.save(occupationEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateOcptn(Occupation occupation)
	{
		
		Optional<Occupation> occupationOld = findOccuById(occupation.getOccupationId());
		
		if(occupationOld.isPresent() && occupation.getOccupationCertified()==0)
		{
			
			Occupation ocptnExisting = occupationOld.get();
			ocptnExisting.setOccupationCertified(1);
			this.ocptnDao.save(ocptnExisting);
			
			saveOcptnTrail(occupation , Constant.VALUE_UPDATED , "MODIFY");
			res.addData(Constant.VALUE_UPDATED, occupation);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in Occupation Trail table
	 */
	public void saveOcptnTrail(Occupation occupation, String remark , String action)
	{
		OccupationTrail ocptnTrail =  (OccupationTrail) ResponseDTO.accepted().convertToEntity(occupation, OccupationTrail.class);
		ocptnTrail.setOccupation(occupation);
		ocptnTrail.setOccupationCreatedBy("adi");   //JWT
		ocptnTrail.setOccupationAction(action);  
		ocptnTrail.setOccupationCertified(1);
		ocptnTrail.setOccupationRemark(remark);
		
		this.ocptnTrlDao.save(ocptnTrail);
		saveCertification(ocptnTrail);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(OccupationTrail ocptnTrail) 
	{
		/*
		 * To inject an instance of Certification
		 */
		
		 Certification cert=new Certification();
		
			cert.setAction(ocptnTrail.getOccupationAction());
			cert.setTrailId(ocptnTrail.getOccupationTrailId());
			cert.setTableName(MasterType.OCCUPATION.toString());
			cert.setCertified(1);
			cert.setMaker("adi"); // To do replace maker with JWT
			cert.setMakerTime(ocptnTrail.getOccupationCreatedDate());
			cert.setCheckedTime(new Date ());
			this.certificationDao.save(cert);
			
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.ocptnDao.getActiveOccupation(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.ocptnDao.getInactOccupation(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}


	

}
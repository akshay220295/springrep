package com.isg.gcms.masters.entity.service;

import java.util.Optional;

import org.springframework.data.domain.Pageable;

import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.entity.model.EntityBean;


public interface EntityService {

	public ResponseObj getAllEntities(Pageable xPageable);

	public ResponseObj getEntityByName(String entityName);

	public ResponseObj getEntity(long entityId);

	public ResponseObj saveEntity(EntityBean entity);

	public ResponseObj updateEntity(EntityBean entity);

	public ResponseObj deleteEntity(Long id);

	public Optional<EntityBean> findbyEntityName(String entityName);
	
	public Optional<EntityBean> findByEntityId(Long entityId);
	
}

package com.isg.gcms.masters.bank.service;

import java.util.Optional;

import org.springframework.data.domain.Pageable;
import org.springframework.transaction.annotation.Transactional;

import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.bank.model.Bank;



@Transactional
public interface BankService
{

	public ResponseObj getAllBank(Pageable xPageable);
	
	public ResponseObj getByName(String bankName);
	
	public Optional<Bank> findbyBankName(String bankName);

	public ResponseObj getBankById(long bankId);
	
	public ResponseObj getByEntity(Long entityId);

	public ResponseObj saveBank(Bank bank);

	public ResponseObj updateBank(Bank bank);
	
	public ResponseObj deleteBank(Long id);

}

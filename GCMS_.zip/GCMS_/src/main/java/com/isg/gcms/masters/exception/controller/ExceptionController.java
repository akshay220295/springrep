package com.isg.gcms.masters.exception.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.exception.dto.ExcptnCreationDTO;
import com.isg.gcms.masters.exception.dto.ExcptnUpdateDTO;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.exception.service.ExceptionMstService;


@RestController
@RequestMapping(value= Constant.PATH_EXCEPTION)
@CrossOrigin("*")
public class ExceptionController {
	
	/*
	 * To inject an instance of ExceptionMstService
	 */
	@Autowired
	private ExceptionMstService excptnService;
	

	/*
	 * Getting exception data with pagination
	 */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getall(@RequestBody PaginationModel pagination)
	{
		return this.excptnService.getAllExcptn(pagination);
	}

	/*
	 * Getting exception data without pagination
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj getall()
	{
		return this.excptnService.getAllExcptn();
	}
	
	/*
	 * Getting exception data based on Id
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getValue(@PathVariable("id") Long id)
	
	{
		return this.excptnService.getById(id); 
	}

	/*
	 * Getting exception data based on name
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("username") String username)
	{
		return this.excptnService.findByName(username);
	}

	/*
	 * To create new Exception
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(ExcptnCreationDTO.class) @Validated ExceptionMst exception)
	{
		return this.excptnService.create(exception) ;
	}
	
	/*
	 * Soft Deleting exception based on ID
	 */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.excptnService.deleteById(id);
	}
	
	/*
	 * Updating existing exception
	 */
	@PutMapping 
	public ResponseObj updateExcptn(@RequestDTO(ExcptnUpdateDTO.class) @Validated ExceptionMst exception)
	{
		System.out.println(exception + "in contro @@@@@@@@@@");
		return this.excptnService.updateExcptn(exception);
	}

	/*
	 * Getting exception based on status
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.excptnService.getStatus(status, pagination);
		
	}
	
}

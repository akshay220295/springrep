package com.isg.gcms.certification.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.certification.dto.CertificationDTO;
import com.isg.gcms.certification.service.CertificationService;
import com.isg.gcms.common.response.ResponseObj;


@RestController
@RequestMapping("/certification")
public class CertificationController
{
	// To inject an instance of CertificationService
	@Autowired
	private CertificationService certificationService;

	/* To get list of master name where certification is pending */
	@GetMapping(path = "/certify")
	public ResponseObj listPendingCertification()
	{

		
		return this.certificationService.populateMaster();
	}

	/* To get the list of Certification based on master name. */

	@GetMapping
	public ResponseObj listCertification(@RequestBody String masterName)
	{
		
		return this.certificationService.listCertification(masterName);
	}
	
	

	
	/* To certify the master based on master name */
	@PutMapping(path = "/do/certify/{masterName}")
	public ResponseEntity<Void> confirmCertification(@RequestBody List<CertificationDTO> certify,
			@PathVariable("masterName") String masterName)
	{
		
		this.certificationService.confirmCertify(certify, masterName);
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
	}

}

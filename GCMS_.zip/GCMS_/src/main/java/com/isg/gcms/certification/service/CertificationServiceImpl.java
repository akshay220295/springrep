package com.isg.gcms.certification.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.dto.CertificationDTO;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.MasterWrapper;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.masters.accounttype.dao.AccountTypeDao;
import com.isg.gcms.masters.accounttype.dao.AccountTypeTrailDao;
import com.isg.gcms.masters.accounttype.model.AccountType;
import com.isg.gcms.masters.accounttype.model.AccountTypeTrail;
import com.isg.gcms.masters.autodbtagnst.dao.AutoDbtAgnstDao;
import com.isg.gcms.masters.autodbtagnst.dao.AutoDbtAgnstTrailDao;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainstTrail;
import com.isg.gcms.masters.bank.dao.BankDao;
import com.isg.gcms.masters.bank.dao.BankTrailDao;
import com.isg.gcms.masters.bank.model.Bank;
import com.isg.gcms.masters.bank.model.BankTrail;
import com.isg.gcms.masters.bureau.dao.BureauDao;
import com.isg.gcms.masters.bureau.dao.BureauTrailDao;
import com.isg.gcms.masters.bureau.model.Bureau;
import com.isg.gcms.masters.bureau.model.BureauTrail;
import com.isg.gcms.masters.cardtype.dao.CardTypeDao;
import com.isg.gcms.masters.cardtype.dao.CardTypeTrailDao;
import com.isg.gcms.masters.cardtype.model.CardType;
import com.isg.gcms.masters.cardtype.model.CardTypeTrail;
import com.isg.gcms.masters.channel.dao.ChannelDao;
import com.isg.gcms.masters.channel.dao.ChannelTrailDao;
import com.isg.gcms.masters.channel.model.Channel;
import com.isg.gcms.masters.channel.model.ChannelTrail;
import com.isg.gcms.masters.decision.dao.DecisionDao;
import com.isg.gcms.masters.decision.dao.DecisionTrailDao;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.model.DecisionTrail;
import com.isg.gcms.masters.deferral.dao.DeferralDao;
import com.isg.gcms.masters.deferral.dao.DeferralTrailDao;
import com.isg.gcms.masters.deferral.model.Deferral;
import com.isg.gcms.masters.deferral.model.DeferralTrail;
import com.isg.gcms.masters.dsa.dao.DsaDao;
import com.isg.gcms.masters.dsa.dao.DsaTrailDao;
import com.isg.gcms.masters.dsa.model.Dsa;
import com.isg.gcms.masters.dsa.model.DsaTrail;
import com.isg.gcms.masters.education.dao.EducationDao;
import com.isg.gcms.masters.education.dao.EducationTrailDao;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.model.EducationTrail;
import com.isg.gcms.masters.employee.dao.EmployeeDao;
import com.isg.gcms.masters.employee.dao.EmployeeTrailDao;
import com.isg.gcms.masters.employee.model.Employee;
import com.isg.gcms.masters.employee.model.EmployeeTrail;
import com.isg.gcms.masters.exception.dao.ExceptionDao;
import com.isg.gcms.masters.exception.dao.ExceptionTrailDao;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.exception.model.ExceptionMstTrail;
import com.isg.gcms.masters.gender.dao.GenderDao;
import com.isg.gcms.masters.gender.dao.GenderTrailDao;
import com.isg.gcms.masters.gender.model.Gender;
import com.isg.gcms.masters.gender.model.GenderTrail;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusDao;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusTrailDao;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;
import com.isg.gcms.masters.occupation.dao.OccupationDao;
import com.isg.gcms.masters.occupation.dao.OccupationTrailDao;
import com.isg.gcms.masters.occupation.model.Occupation;
import com.isg.gcms.masters.occupation.model.OccupationTrail;
import com.isg.gcms.masters.priority.dao.PriorityDao;
import com.isg.gcms.masters.priority.dao.PriorityTrailDao;
import com.isg.gcms.masters.priority.model.Priority;
import com.isg.gcms.masters.priority.model.PriorityTrail;
import com.isg.gcms.masters.promocode.dao.PromoCodeDao;
import com.isg.gcms.masters.promocode.dao.PromoCodeTrailDao;
import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.promocode.model.PromoCodeTrail;
import com.isg.gcms.masters.relation.dao.RelationDao;
import com.isg.gcms.masters.relation.dao.RelationTrailDao;
import com.isg.gcms.masters.relation.model.Relation;
import com.isg.gcms.masters.relation.model.RelationTrail;
import com.isg.gcms.masters.residentstatus.dao.ResidentDao;
import com.isg.gcms.masters.residentstatus.dao.ResidentTrailDao;
import com.isg.gcms.masters.residentstatus.model.Resident;
import com.isg.gcms.masters.residentstatus.model.ResidentTrail;
import com.isg.gcms.masters.salutation.dao.SalutationDao;
import com.isg.gcms.masters.salutation.dao.SalutationTrailDao;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.model.SalutationTrail;
import com.isg.gcms.masters.subcardtype.dao.SubcardTypeDao;
import com.isg.gcms.masters.subcardtype.dao.SubcardTypeTrailDao;
import com.isg.gcms.masters.subcardtype.model.SubcardType;
import com.isg.gcms.masters.subcardtype.model.SubcardTypeTrail;
import com.isg.gcms.masters.vip.dao.VipDao;
import com.isg.gcms.masters.vip.dao.VipTrailDao;
import com.isg.gcms.masters.vip.model.Vip;
import com.isg.gcms.masters.vip.model.VipTrail;
import com.isg.gcms.common.response.ResponseObj;

import javafx.util.Pair;

@SuppressWarnings("restriction")
@Service
public class CertificationServiceImpl implements CertificationService {
	// To inject an instance of an BankDao class
	@Autowired
	public BankDao bankDao;

	// To inject an instance of an BankTrailDao class
	@Autowired
	public BankTrailDao bankTrailDao;
	
	@Autowired
	public AutoDbtAgnstDao autoDbtAgnstDao;
	
	@Autowired
	public AutoDbtAgnstTrailDao autoDbtAgnstTrailDao;
	
	@Autowired
	public BureauDao bureauDao;
	
	@Autowired
	public BureauTrailDao bureauTrailDao;
	
	@Autowired
	public CardTypeDao cardTypeDao; 
	
	@Autowired
	public CardTypeTrailDao cardTypeTrailDao;
	
	@Autowired
	public DsaDao dsaDao;
	
	@Autowired
	public DsaTrailDao dsaTrailDao;
	
	
	
	@Autowired 
	public PriorityDao priorityDao;
	
	@Autowired 
	public PriorityTrailDao priorityTrailDao;
	
	@Autowired 
	public SalutationDao salutationDao;
	
	@Autowired 
	public SalutationTrailDao salutationTrailDao;
	
	@Autowired 
	public EducationDao educationDao;
	
	@Autowired 
	public EducationTrailDao educationTrailDao;
	
	@Autowired
	public DecisionDao decisnDao;
	
	@Autowired
	public DecisionTrailDao decisnTrlDao;
	
	/* To inject an instance of an GenderDao class */
	   @Autowired
	  	public GenderDao genderDao;
	   
	   
	   /* To inject an instance of an GenderTrailDao class */
	   @Autowired
	 	public GenderTrailDao genderTrailDao;
	   
	   
	   /* To inject an instance of an ResidentDao class */
	   @Autowired
	 	public ResidentDao residentDao;
	  

	   /* To inject an instance of an ResidentTrailDao class */
	    @Autowired
	 	public ResidentTrailDao residentTrailDao;
	    
	    
	    /* To inject an instance of an ChannelDao class */
	    @Autowired
	 	public ChannelDao channelDao;
	  
	    /* To inject an instance of an ChannelTrailDao class */
	    @Autowired
	 	public ChannelTrailDao channelTrailDao;
	    
	    
	    @Autowired 
		public PromoCodeDao promoCodeDao;
		
		@Autowired 
		public PromoCodeTrailDao promoCodeTrailDao;
		
		@Autowired 
		public VipDao vipDao;
		
		@Autowired 
		public VipTrailDao vipTrailDao;
		
		@Autowired 
		public AccountTypeDao accTypDao;
		
		@Autowired 
		public AccountTypeTrailDao acctypTrlDao;
		
		
		@Autowired
		public EmployeeDao empDao;

		@Autowired
		public EmployeeTrailDao empTrlDao;
		
		@Autowired
		public MaritalStatusDao mrtlStsDao;
		
		@Autowired
		public MaritalStatusTrailDao mrtlStsTrlDao;

		
		@Autowired
		public DeferralDao deferraldao;
		
		@Autowired
		public DeferralTrailDao deferralTrailDao;
		
		@Autowired
		public OccupationDao occupationDao;
		
		@Autowired
		public OccupationTrailDao occupationTrailDao;
		
		@Autowired
		public RelationDao relationDao;
		
		@Autowired
		public RelationTrailDao relationTrailDao;
		
		
		@Autowired
		public SubcardTypeDao subcrdTypDao;

		@Autowired
		public SubcardTypeTrailDao subcrdTypeTrailDao;
		

		@Autowired
		public ExceptionDao exctpnDao;

		@Autowired
		public ExceptionTrailDao exctpnTrlDao;

	

//	@Autowired
//	public AddressService addressService;
//	
//	@Autowired
//	public EntityService entityService;
//


	@Autowired
	public ResponseObj res;
//
//	// To inject an instance of ConfigDao
//	@Autowired
//	public ConfigDao configDao;
//	@Autowired
//	public ConfigTrailDao configTrailDao;
//	// To inject an instance of CertificationDao
	@Autowired
	public CertificationDao certificationDao;

	/* To populate list of masters where certification is pending */
	public ResponseObj populateMaster() {
		List<Certification> listCert = this.certificationDao.findByCertified(1);
		
		

		res.addData("Populate Masters",
				listCert.stream().map(c -> c.getTableName()).distinct().collect(Collectors.toList()));

		
		return res;
	}

	/* To certify list of master based on master name given */
	public ResponseObj confirmCertify(List<CertificationDTO> certify, String masterName) {
		System.out.println("  ---"+certify+"   "+masterName);
		switch (MasterType.valueOf(masterName.toUpperCase())) {
		case BANK:
			bankCertify(certify);
			break;
			
		case AUTODBTAGNST:
			System.out.println("#$#$#$#$#$#$#$#$#$#$");
			autoDbtAgnstCertify(certify);
			break;
		case BUREAU:
			bureauCertify(certify);
			break;
		case CARDTYPE:
			cardTypeCertify(certify);
			break;
		case DSA:
			dsaCertify(certify);
			break;
		case EDUCATION:
			educationCertify(certify);
			break;
		case PRIORITY:
			priorityCertify(certify);
			break;
		case SALUTATION:
			salutationCertify(certify);
			break;
		case DECISION:
		
			decisionCertify(certify);
			break;
		case GENDER:
			genderCertify(certify);
			break;
		case CHANNEL:
			channelCertify(certify);
			break;
		case RESIDENT:
			residentCertify( certify);
			break;	
		case ACCOUNTTYPE:
			accountTypCertify(certify);
			break;
		
		case OCCUPATION:
			occupationCertify(certify);
			break;
		case DEFERRAL:
			deferralCertify(certify);
			break;
		case EXCEPTION:
			exceptionCertify(certify);
			break;
		case SUBCARDTYPE:
			subcrdTypCertify(certify);
			break;
		case RELATION:
			relationCertify(certify);
			break;
		case MARITALSTATUS:
			martlStsCertify(certify);
			break;
		case PROMOCODE:
			promoCodeCertify(certify);
			break;
		case VIP:
			vipCertify(certify);
			break;
			
		case EMPLOYEE:
			employeeCertify(certify);
				break;
		
		default:
			res.setActionError("Master not found");
		}
		return res;
	}

	/* To list all the certification pending records given the master name */
	@SuppressWarnings("unchecked")
	@Override
	public <K, V> ResponseObj listCertification(String masterName) {
		List<Pair<K, V>> pairList = new ArrayList<>();
		switch (MasterType.valueOf(masterName.toUpperCase())) {
		case BANK:
			this.bankDao.findByBankCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.bankTrailDao.findByBank(c).stream()
									.filter(bt -> bt.getBankCertified() == 1
											&& !Optional.ofNullable(bt.getBankCertifiedMode()).isPresent())
									.findFirst().get())));
			res.addData("Bank Certification", pairList);
			return res;

		case AUTODBTAGNST:
			this.autoDbtAgnstDao.findByAutodbtAgnstCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.autoDbtAgnstTrailDao.findByAutodbtAgnst(c).stream()
									.filter(bt -> bt.getAutodbtAgnstCertified() == 1
											&& !Optional.ofNullable(bt.getAutoDebitAgainstCertMod()).isPresent())
									.findFirst().get())));
			res.addData("AUTODBTAGNST Certification", pairList);
			return res;

		case BUREAU:
			this.bureauDao.findByBureauCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.bureauTrailDao.findByBureau(c).stream()
									.filter(bt -> bt.getBureauCertified() == 1
											&& !Optional.ofNullable(bt.getBureauCertMod()).isPresent())
									.findFirst().get())));
			res.addData("BUREAU Certification", pairList);
			return res;

		case CARDTYPE:
			this.cardTypeDao.findByCardTypeCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.cardTypeTrailDao.findByCardType(c).stream()
									.filter(bt -> bt.getCardTypeCertified() == 1
											&& !Optional.ofNullable(bt.getCardTypeCertMod()).isPresent())
									.findFirst().get())));
			res.addData("CARDTYPE Certification", pairList);
			return res;

		case DSA:
			this.dsaDao.findByDsaCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.dsaTrailDao.findByDsa(c).stream()
									.filter(bt -> bt.getDsaCertified() == 1
											&& !Optional.ofNullable(bt.getDsaCertMod()).isPresent())
									.findFirst().get())));
			res.addData("DSA Certification", pairList);
			return res;

		case EDUCATION:
			this.educationDao.findByEducationCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.educationTrailDao.findByEducation(c).stream()
									.filter(bt -> bt.getEducationCertified() == 1
											&& !Optional.ofNullable(bt.getEducationCertMod()).isPresent())
									.findFirst().get())));
			res.addData("EDUCATION Certification", pairList);
			return res;

		case PRIORITY:
			this.priorityDao.findByPriorityCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.priorityTrailDao.findByPriority(c).stream()
									.filter(bt -> bt.getPriorityCertified() == 1
											&& !Optional.ofNullable(bt.getPriorityCertifiedMode()).isPresent())
									.findFirst().get())));
			res.addData("PRIORITY Certification", pairList);
			return res;

		case SALUTATION:
			this.salutationDao.findBySalutationCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.salutationTrailDao.findBySalutation(c).stream()
									.filter(bt -> bt.getSalutationCertified() == 1
											&& !Optional.ofNullable(bt.getSalutationCertifiedMode()).isPresent())
									.findFirst().get())));
			res.addData("SALUTATION Certification", pairList);
			return res;
			
		case DECISION:
			System.out.println(" in list pairs @@@@@@@@@");
			this.decisnDao.findBydecisionCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.decisnTrlDao.findByDecision(c).stream()
									.filter(bt -> bt.getDecisionCertifed() == 1
											&& !Optional.ofNullable(bt.getDecisionCertMode()).isPresent())
									.findFirst().get())));
			res.addData("DECISION CERTIFICATION", pairList);
			
		
			System.out.println(res);
			return res;
			
		case GENDER:
			this.genderDao.findByGenderCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.genderTrailDao.findByGender(c).stream()
									.filter(bt -> bt.getGenderCertified() == 1
											&& !Optional.ofNullable(bt.getGenderCertMode()).isPresent())
									.findFirst().get())));
			res.addData("GENDER Certification", pairList);
			return res;
			
			

		case CHANNEL:
			this.channelDao.findByChannelCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.channelTrailDao.findByChannel(c).stream()
									.filter(bt -> bt.getChannelCertified() == 1
											&& !Optional.ofNullable(bt.getChannelCertMode()).isPresent())
									.findFirst().get())));
			res.addData("Channel Certification", pairList);
			return res;

			
			
			

		case RESIDENT:
			this.residentDao.findByResidentCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.residentTrailDao.findByResident(c).stream()
									.filter(bt -> bt.getResidentCertified()==1
											&& !Optional.ofNullable(bt.getResidentCertMode()).isPresent())
									.findFirst().get())));
			res.addData("resident Certification", pairList);
			return res;
			
		case PROMOCODE:
			this.promoCodeDao.findByPrmocdeCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.promoCodeTrailDao.findByPromoCode(c).stream()
									.filter(bt -> bt.getPrmocdeCertified() == 1
											&& !Optional.ofNullable(bt.getPrmocdeCertifiedMode()).isPresent())
									.findFirst().get())));
			res.addData("PROMOCODE Certification", pairList);
			return res;
			
		case VIP:
			this.vipDao.findByVipCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.vipTrailDao.findByVip(c).stream()
									.filter(bt -> bt.getVipCertified() == 1
											&& !Optional.ofNullable(bt.getVipCertMode()).isPresent())
									.findFirst().get())));
			res.addData("VIP Certification", pairList);
			return res;
			
		case ACCOUNTTYPE:
			this.accTypDao.findByaccountTypeCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.acctypTrlDao.findByAccountType(c).stream()
									.filter(bt -> bt.getAccountTypeCertified() == 1
											&& !Optional.ofNullable(bt.getAccountTypeCertMode()).isPresent())
									.findFirst().get())));
			res.addData("Account Type Certification", pairList);
			return res;


		case EMPLOYEE:
			this.empDao.findByemployeeCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.empTrlDao.findByEmployee(c).stream()
									.filter(bt -> bt.getEmployeeCertified() == 1
											&& !Optional.ofNullable(bt.getEmployeeCertMode()).isPresent())
									.findFirst().get())));
			res.addData("EMPLOYEE CERTIFICATION", pairList);
			return res;


		case MARITALSTATUS:
			this.mrtlStsDao.findBymaritalStatusCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.mrtlStsTrlDao.findByMaritalStatus(c).stream()
									.filter(bt -> bt.getMaritalStatusCertified() == 1
											&& !Optional.ofNullable(bt.getMaritalStatusCertMode()).isPresent())
									.findFirst().get())));
			res.addData("Marital Status Certification", pairList);
			return res;

		case DEFERRAL:
			this.deferraldao.findByDeferralCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.deferralTrailDao.findByDeferral(c).stream()
									.filter(bt -> bt.getDeferralCertified() == 1
											&& !Optional.ofNullable(bt.getDeferralCertMode()).isPresent())
									.findFirst().get())));
			res.addData("DEFERRAL CERTIFICATION", pairList);
			return res;

		case OCCUPATION:
			this.occupationDao.findByOccupationCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.occupationTrailDao.findByOccupation(c).stream()
									.filter(bt -> bt.getOccupationCertified() == 1
											&& !Optional.ofNullable(bt.getOccupationCertifiedMode()).isPresent())
									.findFirst().get())));
			res.addData("OCCUPATION Certification", pairList);
			return res;
			
		case RELATION:
			this.relationDao.findByRelationCertifed(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.relationTrailDao.findByRelation(c).stream()
									.filter(bt -> bt.getRelationCertifed() == 1
											&& !Optional.ofNullable(bt.getRelationCertMode()).isPresent())
									.findFirst().get())));
			res.addData("RELATION Certification", pairList);
			return res;
			
		case EXCEPTION:
			this.exctpnDao.findByexceptionMstCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.exctpnTrlDao.findByExceptionMst(c).stream()
									.filter(bt -> bt.getExceptionMstCertified() == 1
											&& !Optional.ofNullable(bt.getExceptionMstCertMode()).isPresent())
									.findFirst().get())));
			res.addData("EXCEPTION CERTIFICATION", pairList);
			return res;
			

		case SUBCARDTYPE:
			this.subcrdTypDao.findBySubcardTypeCertified(1).stream()
					.forEach(c -> pairList.add((Pair<K, V>) new Pair<>(c,
							this.subcrdTypeTrailDao.findBySubcardType(c).stream()
									.filter(bt -> bt.getSubcardTypeCertified() == 1
											&& !Optional.ofNullable(bt.getSubcardTypeCertMode()).isPresent())
									.findFirst().get())));
			res.addData("SUBCARD TYPE CERTIFICATION", pairList);
			return res;
			
		
		default:
			res.setActionError("MASTER NOT VALID");
			return res;

		}
	}
	
	
	
//------------------------------------------------------------------------------------------------------------------------------------	
	
	
	

	/* 
	 * To certify list of bank master records 
	*/

	public void bankCertify(List<CertificationDTO> certify) {
		

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			BankTrail bankTrail = this.bankTrailDao.findById(ap.getTrailId()).get();

			Bank bank= (Bank)ResponseDTO.accepted().convertToEntity(bankTrail, Bank.class);

			bank.setBankId(bankTrail.getBank().getBankId());

			bank.setBankModifiedBy(bankTrail.getBankModifiedBy());
			bank.setBankModifiedDate(bankTrail.getBankModifiedDate());

			if (bankTrail.getBankAction().equalsIgnoreCase("delete"))
				bank.setBankCertified(2);
			else
				bank.setBankCertified(0);
			this.bankDao.save(bank);
			bankTrail.setBankCertified(0);
			bankTrail.setBankCertifiedMode(0);
			bankTrail.setBankRemark(ap.getRemarks());
			this.bankTrailDao.save(bankTrail);
			setCertificationCertify(bankTrail.getBankTrailId());
		});
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			BankTrail bankTrail = this.bankTrailDao.findById(rj.getTrailId()).get();

			Bank bank = (Bank) ResponseDTO.accepted().convertToEntity(bankTrail, Bank.class);
			bank.setBankCertified(0);
			this.bankDao.save(bank);
			bankTrail.setBankCertified(0);
			bankTrail.setBankCertifiedMode(1);
			this.bankTrailDao.save(bankTrail);
			setCertificationCertify(bankTrail.getBankTrailId());

		});
	}
	
	

	
	
	/////////////
	
	public void salutationCertify(List<CertificationDTO> certify) {
	

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			SalutationTrail salutationTrail = this.salutationTrailDao.findById(ap.getTrailId()).get();

			Salutation salutation= (Salutation)ResponseDTO.accepted().convertToEntity(salutationTrail, Salutation.class);

			salutation.setSalutationId(salutationTrail.getSalutation().getSalutationId());

			salutation.setSalutationModifiedBy(salutationTrail.getSalutationModifiedBy());
			salutation.setSalutationModifiedDate(salutationTrail.getSalutationModifiedDate());

			if (salutationTrail.getSalutationAction().equalsIgnoreCase("delete"))
				salutation.setSalutationCertified(2);
			else
				salutation.setSalutationCertified(0);
			this.salutationDao.save(salutation);
			salutationTrail.setSalutationCertified(0);
			salutationTrail.setSalutationCertifiedMode(0);
			salutationTrail.setSalutationRemark(ap.getRemarks());
			this.salutationTrailDao.save(salutationTrail);
			setCertificationCertify(salutationTrail.getSalutationTrailId());
		});
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			SalutationTrail salutationTrail = this.salutationTrailDao.findById(rj.getTrailId()).get();

			Salutation salutation = (Salutation) ResponseDTO.accepted().convertToEntity(salutationTrail, Salutation.class);
			salutation.setSalutationCertified(0);
			this.salutationDao.save(salutation);
			salutationTrail.setSalutationCertified(0);
			salutationTrail.setSalutationCertifiedMode(1);
			this.salutationTrailDao.save(salutationTrail);
			setCertificationCertify(salutationTrail.getSalutationTrailId());

		});
	}
	
	
	
	public void educationCertify(List<CertificationDTO> certify) 
	{
	
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			EducationTrail educationTrail = this.educationTrailDao.findById(ap.getTrailId()).get();

			Education education= (Education)ResponseDTO.accepted().convertToEntity(educationTrail, Education.class);

			education.setEducationId(educationTrail.getEducation().getEducationId());

			education.setEducationModifiedBy(educationTrail.getEducationModifiedBy());
			education.setEducationModifiedDate(educationTrail.getEducationModifiedDate());

			if (educationTrail.getEducationAction().equalsIgnoreCase("delete"))
				education.setEducationCertified(2);
			else
				education.setEducationCertified(0);
			this.educationDao.save(education);
			educationTrail.setEducationCertified(0);
			educationTrail.setEducationCertMod(0);
			educationTrail.setEducationRemark(ap.getRemarks());
			this.educationTrailDao.save(educationTrail);
			setCertificationCertify(educationTrail.getEducationTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			EducationTrail educationTrail = this.educationTrailDao.findById(rj.getTrailId()).get();

			Education education = (Education) ResponseDTO.accepted().convertToEntity(educationTrail, Education.class);
			education.setEducationCertified(0);
			this.educationDao.save(education);
			educationTrail.setEducationCertified(0);
			educationTrail.setEducationCertMod(1);
			this.educationTrailDao.save(educationTrail);
			setCertificationCertify(educationTrail.getEducationTrailId());

		});
	}
	
	
	public void dsaCertify(List<CertificationDTO> certify) 
	{
	
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			DsaTrail dsaTrail = this.dsaTrailDao.findById(ap.getTrailId()).get();

			Dsa dsa= (Dsa)ResponseDTO.accepted().convertToEntity(dsaTrail, Dsa.class);

			dsa.setDsaId(dsaTrail.getDsa().getDsaId());

			dsa.setDsaModifiedBy(dsaTrail.getDsaModifiedBy());
			dsa.setDsaModifiedDate(dsaTrail.getDsaModifiedDate());

			if (dsaTrail.getDsaAction().equalsIgnoreCase("delete"))
				dsa.setDsaCertified(2);
			else
				dsa.setDsaCertified(0);
			this.dsaDao.save(dsa);
			dsaTrail.setDsaCertified(0);
			dsaTrail.setDsaCertMod(0);
			dsaTrail.setDsaRemark(ap.getRemarks());
			this.dsaTrailDao.save(dsaTrail);
			setCertificationCertify(dsaTrail.getDsaTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			DsaTrail dsaTrail = this.dsaTrailDao.findById(rj.getTrailId()).get();

			Dsa dsa = (Dsa) ResponseDTO.accepted().convertToEntity(dsaTrail, Dsa.class);
			dsa.setDsaCertified(0);
			this.dsaDao.save(dsa);
			dsaTrail.setDsaCertified(0);
			dsaTrail.setDsaCertMod(1);
			this.dsaTrailDao.save(dsaTrail);
			setCertificationCertify(dsaTrail.getDsaTrailId());

		});
	}
	
	public void cardTypeCertify(List<CertificationDTO> certify) 
	{
	
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			CardTypeTrail cardTypeTrail = this.cardTypeTrailDao.findById(ap.getTrailId()).get();

			CardType cardType= (CardType)ResponseDTO.accepted().convertToEntity(cardTypeTrail, CardType.class);

			cardType.setCardTypeId(cardTypeTrail.getCardType().getCardTypeId());

			cardType.setCardTypeModifiedBy(cardTypeTrail.getCardTypeModifiedBy());
			cardType.setCardTypeModifiedDate(cardTypeTrail.getCardTypeModifiedDate());

			if (cardTypeTrail.getCardTypeAction().equalsIgnoreCase("delete"))
				cardType.setCardTypeCertified(2);
			else
				cardType.setCardTypeCertified(0);
			this.cardTypeDao.save(cardType);
			cardTypeTrail.setCardTypeCertified(0);
			cardTypeTrail.setCardTypeCertMod(0);
			cardTypeTrail.setCardTypeRemark(ap.getRemarks());
			this.cardTypeTrailDao.save(cardTypeTrail);
			setCertificationCertify(cardTypeTrail.getCardTypeTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			CardTypeTrail cardTypeTrail = this.cardTypeTrailDao.findById(rj.getTrailId()).get();

			CardType cardType = (CardType) ResponseDTO.accepted().convertToEntity(cardTypeTrail, CardType.class);
			cardType.setCardTypeCertified(0);
			this.cardTypeDao.save(cardType);
			cardTypeTrail.setCardTypeCertified(0);
			cardTypeTrail.setCardTypeCertMod(1);
			this.cardTypeTrailDao.save(cardTypeTrail);
			setCertificationCertify(cardTypeTrail.getCardTypeTrailId());

		});
	}
	
	public void autoDbtAgnstCertify(List<CertificationDTO> certify) 
	{
	System.out.println("#######$$$$$$$$$@#$@$@$@$@$@$@$@$@$");
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			AutoDebitAgainstTrail autoDebitAgainstTrail = this.autoDbtAgnstTrailDao.findById(ap.getTrailId()).get();

			AutoDebitAgainst autoDebitAgainst= (AutoDebitAgainst)ResponseDTO.accepted().convertToEntity(autoDebitAgainstTrail, AutoDebitAgainst.class);

			autoDebitAgainst.setAutodbtAgnstId(autoDebitAgainstTrail.getAutodbtAgnst().getAutodbtAgnstId());

			autoDebitAgainst.setAutodbtAgnstModBy(autoDebitAgainstTrail.getAutodbtAgnstModBy());
			autoDebitAgainst.setAutodbtAgnstModDte(autoDebitAgainstTrail.getAutodbtAgnstModDte());
			

			if (autoDebitAgainstTrail.getAutodbtAgnstAction().equalsIgnoreCase("delete"))
				autoDebitAgainst.setAutodbtAgnstCertified(2);
			else
				autoDebitAgainst.setAutodbtAgnstCertified(0);
			this.autoDbtAgnstDao.save(autoDebitAgainst);
			autoDebitAgainstTrail.setAutodbtAgnstCertified(0);
			autoDebitAgainstTrail.setAutoDebitAgainstCertMod(0);
			autoDebitAgainstTrail.setAutodbtAgnstRemark(ap.getRemarks());
			this.autoDbtAgnstTrailDao.save(autoDebitAgainstTrail);
			setCertificationCertify(autoDebitAgainstTrail.getAutodbtAgnstTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			AutoDebitAgainstTrail autoDebitAgainstTrail = this.autoDbtAgnstTrailDao.findById(rj.getTrailId()).get();

			AutoDebitAgainst autoDebitAgainst = (AutoDebitAgainst) ResponseDTO.accepted().convertToEntity(autoDebitAgainstTrail, AutoDebitAgainst.class);
			autoDebitAgainst.setAutodbtAgnstCertified(0);
			this.autoDbtAgnstDao.save(autoDebitAgainst);
			autoDebitAgainstTrail.setAutodbtAgnstCertified(0);
			autoDebitAgainstTrail.setAutoDebitAgainstCertMod(1);
			this.autoDbtAgnstTrailDao.save(autoDebitAgainstTrail);
			setCertificationCertify(autoDebitAgainstTrail.getAutodbtAgnstTrailId());

		});
	}
	
	public void priorityCertify(List<CertificationDTO> certify) 
	{
	
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			PriorityTrail priorityTrail = this.priorityTrailDao.findById(ap.getTrailId()).get();

			Priority priority= (Priority)ResponseDTO.accepted().convertToEntity(priorityTrail, Priority.class);

			priority.setPriorityId(priorityTrail.getPriority().getPriorityId());

			priority.setPriorityModifiedBy(priorityTrail.getPriorityModifiedBy());
			priority.setPriorityModifiedDate(priorityTrail.getPriorityModifiedDate());

			if (priorityTrail.getPriorityAction().equalsIgnoreCase("delete"))
				priority.setPriorityCertified(2);
			else
				priority.setPriorityCertified(0);
			this.priorityDao.save(priority);
			priorityTrail.setPriorityCertified(0);
			priorityTrail.setPriorityCertifiedMode(0);
			priorityTrail.setPriorityRemark(ap.getRemarks());
			this.priorityTrailDao.save(priorityTrail);
			setCertificationCertify(priorityTrail.getPriorityTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			PriorityTrail priorityTrail = this.priorityTrailDao.findById(rj.getTrailId()).get();

			Priority priority = (Priority) ResponseDTO.accepted().convertToEntity(priorityTrail, Priority.class);
			priority.setPriorityCertified(0);
			this.priorityDao.save(priority);
			priorityTrail.setPriorityCertified(0);
			priorityTrail.setPriorityCertifiedMode(1);
			this.priorityTrailDao.save(priorityTrail);
			setCertificationCertify(priorityTrail.getPriorityTrailId());

		});
	}
	
	public void bureauCertify(List<CertificationDTO> certify) 
	{
	
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			BureauTrail bureauTrail = this.bureauTrailDao.findById(ap.getTrailId()).get();

			Bureau bureau= (Bureau)ResponseDTO.accepted().convertToEntity(bureauTrail, Bureau.class);

			bureau.setBureauId(bureauTrail.getBureau().getBureauId());

			bureau.setBureauModifiedBy(bureauTrail.getBureauModifiedBy());
			bureau.setBureauModifiedDate(bureauTrail.getBureauModifiedDate());

			if (bureauTrail.getBureauAction().equalsIgnoreCase("delete"))
				bureau.setBureauCertified(2);
			else
				bureau.setBureauCertified(0);
			this.bureauDao.save(bureau);
			bureauTrail.setBureauCertified(0);
			bureauTrail.setBureauCertMod(0);
			bureauTrail.setBureauRemark(ap.getRemarks());
			this.bureauTrailDao.save(bureauTrail);
			setCertificationCertify(bureauTrail.getBureauTrailId());
		});
		
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			BureauTrail bureauTrail = this.bureauTrailDao.findById(rj.getTrailId()).get();

			Bureau bureau = (Bureau) ResponseDTO.accepted().convertToEntity(bureauTrail, Bureau.class);
			bureau.setBureauCertified(0);
			this.bureauDao.save(bureau);
			bureauTrail.setBureauCertified(0);
			bureauTrail.setBureauCertMod(1);
			this.bureauTrailDao.save(bureauTrail);
			setCertificationCertify(bureauTrail.getBureauTrailId());

		});
	}
	
	/* To certify list of branch master records */
	public void decisionCertify(List<CertificationDTO> certify) 
	{
			
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
		DecisionTrail decisionTrail = this.decisnTrlDao.findById(ap.getTrailId()).get();

		Decision decision= (Decision)ResponseDTO.accepted().convertToEntity(decisionTrail, Decision.class);

		decision.setDecisionId(decisionTrail.getDecision().getDecisionId());

		decision.setDecisionModifiedBy(decisionTrail.getDecisionModifiedBy());
		decision.setDecisionModifiedDate(decisionTrail.getDecisionModifiedDate());

		if (decisionTrail.getDecisionAction().equalsIgnoreCase("delete"))
			decision.setDecisionCertified(2);
		else
			decision.setDecisionCertified(0);
		
		this.decisnDao.save(decision);
		decisionTrail.setDecisionCertifed(0);
		decisionTrail.setDecisionCertMode(0);
		decisionTrail.setDecisionRemark(ap.getRemarks());
		this.decisnTrlDao.save(decisionTrail);
		setCertificationCertify(decisionTrail.getDecisionTrailId());
	});
	
	certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
		DecisionTrail decisionTrail = this.decisnTrlDao.findById(rj.getTrailId()).get();

		Decision decision = (Decision) ResponseDTO.accepted().convertToEntity(decisionTrail, Decision.class);
		decision.setDecisionCertified(0);
		this.decisnDao.save(decision);
		decisionTrail.setDecisionCertifed(0);
		decisionTrail.setDecisionCertMode(1);
		this.decisnTrlDao.save(decisionTrail);
		setCertificationCertify(decisionTrail.getDecisionTrailId());

	});
}
	
	
	public void channelCertify(List<CertificationDTO> certify) {

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			ChannelTrail channelTrail = this.channelTrailDao.findById(ap.getTrailId()).get();

			Channel channel= (Channel)ResponseDTO.accepted().convertToEntity(channelTrail, Channel.class);

			channel.setChannelId(channelTrail.getChannel().getChannelId());

		channel.setChannelModifiedBy(channelTrail.getChannelModifiedBy());
			channel.setChannelModifiedDate(channelTrail.getChannelModifiedDate());

			if (channelTrail.getChannelAction().equalsIgnoreCase("delete"))
				channel.setChannelCertified(2);
			else
				channel.setChannelCertified(0);
			this.channelDao.save(channel);
			channelTrail.setChannelCertified(0);
			channelTrail.setChannelCertMode(0);
			channelTrail.setChannelRemark(ap.getRemarks());
			this.channelTrailDao.save(channelTrail);
			setCertificationCertify(channelTrail.getChannelTrailId());
		});
		
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			ChannelTrail channelTrail = this.channelTrailDao.findById(rj.getTrailId()).get();

			Channel channel = (Channel) ResponseDTO.accepted().convertToEntity(channelTrail, Channel.class);
			channel.setChannelCertified(0);
			this.channelDao.save(channel);
			channelTrail.setChannelCertified(0);
			channelTrail.setChannelCertMode(1);
			this.channelTrailDao.save(channelTrail);
			setCertificationCertify(channelTrail.getChannelTrailId());

		});
	}
	
	public void genderCertify(List<CertificationDTO> certify) {

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			GenderTrail genderTrail = this.genderTrailDao.findById(ap.getTrailId()).get();

			Gender gender= (Gender)ResponseDTO.accepted().convertToEntity(genderTrail, Gender.class);

			gender.setGenderID(genderTrail.getGender().getGenderID());

		gender.setGenderModifiedBy(genderTrail.getGenderModifiedBy());
			gender.setGenderModifiedDate(genderTrail.getGenderModifiedDate());

			if (genderTrail.getGenderAction().equalsIgnoreCase("delete"))
				gender.setGenderCertified(2);
			else
				gender.setGenderCertified(0);
			this.genderDao.save(gender);
			genderTrail.setGenderCertified(0);
			genderTrail.setGenderCertMode(0);
			genderTrail.setGenderRemark(ap.getRemarks());
			this.genderTrailDao.save(genderTrail);
			setCertificationCertify(genderTrail.getGenderTrailId());
		});
		
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			GenderTrail genderTrail = this.genderTrailDao.findById(rj.getTrailId()).get();

		Gender gender = (Gender) ResponseDTO.accepted().convertToEntity(genderTrail,Gender.class);
		gender.setGenderCertified(0);
			this.genderDao.save(gender);
			genderTrail.setGenderCertified(0);
			genderTrail.setGenderCertMode(1);
			this.genderTrailDao.save(genderTrail);
			setCertificationCertify(genderTrail.getGenderTrailId());

		});
	}

	public void residentCertify(List<CertificationDTO> certify) {

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			ResidentTrail residentTrail = this.residentTrailDao.findById(ap.getTrailId()).get();

			Resident resident= (Resident)ResponseDTO.accepted().convertToEntity(residentTrail, Resident.class);

			resident.setResidentId(residentTrail.getResident().getResidentId());

			resident.setResidentModifiedBy(residentTrail.getResidentModifiedBy());
			resident.setResidentModifiedDate(residentTrail.getResidentModifiedDate());

			if (residentTrail.getResidentAction().equalsIgnoreCase("delete"))
				resident.setResidentCertified(2);
			else
				resident.setResidentCertified(0);
			this.residentDao.save(resident);
			residentTrail.setResidentCertified(0);
			residentTrail.setResidentCertMode(0);
			residentTrail.setResidentRemark(ap.getRemarks());
			this.residentTrailDao.save(residentTrail);
			setCertificationCertify(residentTrail.getResidentTrailId());
		});
		
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			ResidentTrail residentTrail = this.residentTrailDao.findById(rj.getTrailId()).get();

			Resident resident = (Resident) ResponseDTO.accepted().convertToEntity(residentTrail,Resident.class);
			resident.setResidentCertified(0);
			this.residentDao.save(resident);
			residentTrail.setResidentCertified(0);
			residentTrail.setResidentCertMode(1);
			this.residentTrailDao.save(residentTrail);
			setCertificationCertify(residentTrail.getResidentTrailId());

		});
	}
	
	public void accountTypCertify(List<CertificationDTO> certify) 
	{
			System.out.println("in service impl ===================================");
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
		AccountTypeTrail accTypeTrail = this.acctypTrlDao.findById(ap.getTrailId()).get();

		AccountType accType= (AccountType)ResponseDTO.accepted().convertToEntity(accTypeTrail, AccountType.class);

		accType.setAccountTypeId(accTypeTrail.getAccountType().getAccountTypeId());

		accType.setAccountTypeModifiedBy(accTypeTrail.getAccountTypeModifiedBy());
		accType.setAccountTypeModifiedDate(accTypeTrail.getAccountTypeModifiedDate());

		if (accTypeTrail.getAccountTypeAction().equalsIgnoreCase("delete"))
			accType.setAccountTypeCertified(2);
		else
			accType.setAccountTypeCertified(0);
		
		this.accTypDao.save(accType);
		accTypeTrail.setAccountTypeCertified(0);
		accTypeTrail.setAccountTypeCertMode(0);
		accTypeTrail.setAccountTypeRemark(ap.getRemarks());
		this.acctypTrlDao.save(accTypeTrail);
		setCertificationCertify(accTypeTrail.getAccountTypeTrailId());
	});
	
	certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
		AccountTypeTrail accTypeTrail = this.acctypTrlDao.findById(rj.getTrailId()).get();

		AccountType accType = (AccountType) ResponseDTO.accepted().convertToEntity(accTypeTrail, AccountType.class);
		accType.setAccountTypeCertified(0);
		this.accTypDao.save(accType);
		accTypeTrail.setAccountTypeCertified(0);
		accTypeTrail.setAccountTypeCertMode(1);
		this.acctypTrlDao.save(accTypeTrail);
		setCertificationCertify(accTypeTrail.getAccountTypeTrailId());

	});
}



/* To certify list of role master records */
public void martlStsCertify(List<CertificationDTO> certify) 
{

	certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

	{
		MaritalStatusTrail maritalStatusTrail = this.mrtlStsTrlDao.findById(ap.getTrailId()).get();

		MaritalStatus maritalStatus= (MaritalStatus)ResponseDTO.accepted().convertToEntity(maritalStatusTrail, MaritalStatus.class);

		maritalStatus.setMaritalStatusId(maritalStatusTrail.getMaritalStatus().getMaritalStatusId());

		maritalStatus.setMaritalStatusModifiedBy(maritalStatusTrail.getMaritalStatusModifiedBy());
		maritalStatus.setMaritalStatusModifiedDate(maritalStatusTrail.getMaritalStatusModifiedDate());

		if (maritalStatusTrail.getMaritalStatusAction().equalsIgnoreCase("delete"))
			maritalStatus.setMaritalStatusCertified(2);
		else
			maritalStatus.setMaritalStatusCertified(0);
		this.mrtlStsDao.save(maritalStatus);
		maritalStatusTrail.setMaritalStatusCertified(0);
		maritalStatusTrail.setMaritalStatusCertMode(0);
		maritalStatusTrail.setMaritalStatusRemark(ap.getRemarks());
		this.mrtlStsTrlDao.save(maritalStatusTrail);
		setCertificationCertify(maritalStatusTrail.getMaritalStatusTrailId());
	});
	
	certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
		MaritalStatusTrail maritalStatusTrail = this.mrtlStsTrlDao.findById(rj.getTrailId()).get();

		MaritalStatus maritalStatus = (MaritalStatus) ResponseDTO.accepted().convertToEntity(maritalStatusTrail, MaritalStatus.class);
		maritalStatus.setMaritalStatusCertified(0);
		this.mrtlStsDao.save(maritalStatus);
		maritalStatusTrail.setMaritalStatusCertified(0);
		maritalStatusTrail.setMaritalStatusCertMode(1);
		this.mrtlStsTrlDao.save(maritalStatusTrail);
		setCertificationCertify(maritalStatusTrail.getMaritalStatusTrailId());

	});
}

	public void occupationCertify(List<CertificationDTO> certify) 
	{

		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
		OccupationTrail occupationTrail = this.occupationTrailDao.findById(ap.getTrailId()).get();

		Occupation occupation= (Occupation)ResponseDTO.accepted().convertToEntity(occupationTrail, Occupation.class);

		occupation.setOccupationId(occupationTrail.getOccupation().getOccupationId());
		occupation.setOccupationModifiedBy(occupationTrail.getOccupationModifiedBy());
		occupation.setOccupationModifiedDate(occupationTrail.getOccupationModifiedDate());

		if (occupationTrail.getOccupationAction().equalsIgnoreCase("delete"))
			occupation.setOccupationCertified(2);
		else
			occupation.setOccupationCertified(0);
		this.occupationDao.save(occupation);
		occupationTrail.setOccupationCertified(0);
		occupationTrail.setOccupationCertifiedMode(0);
		occupationTrail.setOccupationRemark(ap.getRemarks());
		this.occupationTrailDao.save(occupationTrail);
		setCertificationCertify(occupationTrail.getOccupationTrailId());
	});
	
	certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
		OccupationTrail occupationTrail = this.occupationTrailDao.findById(rj.getTrailId()).get();

		Occupation occupation = (Occupation) ResponseDTO.accepted().convertToEntity(occupationTrail, Occupation.class);
		occupation.setOccupationCertified(0);
		this.occupationDao.save(occupation);
		occupationTrail.setOccupationCertified(0);
		occupationTrail.setOccupationCertifiedMode(1);
		this.occupationTrailDao.save(occupationTrail);
		setCertificationCertify(occupationTrail.getOccupationTrailId());

	});
}
	
	private void deferralCertify(List<CertificationDTO> certify) {
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			DeferralTrail deferralTrail = this.deferralTrailDao.findById(ap.getTrailId()).get();

			Deferral deferral = (Deferral) ResponseDTO.accepted().convertToEntity(deferralTrail, Deferral.class);

			deferral.setDeferralId(deferralTrail.getDeferral().getDeferralId());

			deferral.setDeferralModifiedBy(deferralTrail.getDeferralModifiedBy());
			deferral.setDeferralModifiedDate(deferralTrail.getDeferralModifiedDate());

			if (deferralTrail.getDeferralAction().equalsIgnoreCase("delete"))
				deferral.setDeferralCertified(2);
			else
				deferral.setDeferralCertified(0);
			this.deferraldao.save(deferral);
			deferralTrail.setDeferralCertified(0);
			deferralTrail.setDeferralCertMode(0);
			deferralTrail.setDeferralRemark(ap.getRemarks());
			this.deferralTrailDao.save(deferralTrail);
			setCertificationCertify(deferralTrail.getDeferralTrailId());
		});
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			DeferralTrail deferralTrail = this.deferralTrailDao.findById(rj.getTrailId()).get();

			Deferral deferral = (Deferral) ResponseDTO.accepted().convertToEntity(deferralTrail, Deferral.class);
			deferral.setDeferralCertified(0);
			this.deferraldao.save(deferral);
			deferralTrail.setDeferralCertified(0);
			deferralTrail.setDeferralCertMode(1);
			this.deferralTrailDao.save(deferralTrail);
			setCertificationCertify(deferralTrail.getDeferralTrailId());

		});
	}
	
	private void exceptionCertify(List<CertificationDTO> certify) {
		certify.stream().filter(c -> Optional.ofNullable(c.getAccept()).isPresent()).forEach(cp -> {
			ExceptionMstTrail exceptionTrail = this.exctpnTrlDao.findById(cp.getTrailId()).get();

			ExceptionMst exception = (ExceptionMst) ResponseDTO.accepted().convertToEntity(exceptionTrail,
					ExceptionMst.class);

			exception.setExceptionMstId(exceptionTrail.getExceptionMst().getExceptionMstId());

			exception.setExceptionMstModifiedBy(exceptionTrail.getExceptionMstModifiedBy());
			exception.setExceptionMstModifiedDate(exceptionTrail.getExceptionMstModifiedDate());

			if (exceptionTrail.getExceptionMstAction().equalsIgnoreCase("delete"))
				exception.setExceptionMstCertified(2);
			else
				exception.setExceptionMstCertified(0);
			this.exctpnDao.save(exception);
			exceptionTrail.setExceptionMstCertified(0);
			exceptionTrail.setExceptionMstCertMode(0);
			exceptionTrail.setExceptionMstRemark(cp.getRemarks());
			this.exctpnTrlDao.save(exceptionTrail);
			setCertificationCertify(exceptionTrail.getExceptionMstTrailId());

		});

		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			ExceptionMstTrail exceptionTrail = this.exctpnTrlDao.findById(rj.getTrailId()).get();

			ExceptionMst exception = (ExceptionMst) ResponseDTO.accepted().convertToEntity(exceptionTrail,
					ExceptionMst.class);
			exception.setExceptionMstCertified(0);
			this.exctpnDao.save(exception);
			exceptionTrail.setExceptionMstCertified(0);
			exceptionTrail.setExceptionMstCertMode(1);
			this.exctpnTrlDao.save(exceptionTrail);
			setCertificationCertify(exceptionTrail.getExceptionMstTrailId());

		});

	}

	public void subcrdTypCertify(List<CertificationDTO> certify) {
		
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			SubcardTypeTrail subcardTypeTrail = this.subcrdTypeTrailDao.findById(ap.getTrailId()).get();

			SubcardType subcardType = (SubcardType) ResponseDTO.accepted().convertToEntity(subcardTypeTrail,
					SubcardType.class);

			subcardType.setSubcardTypeId(subcardTypeTrail.getSubcardType().getSubcardTypeId());

			subcardType.setSubcardTypeModifiedBy(subcardTypeTrail.getSubcardTypeModifiedBy());
			subcardType.setSubcardTypeModifiedDate(subcardTypeTrail.getSubcardTypeModifiedDate());

			if (subcardTypeTrail.getSubcardTypeAction().equalsIgnoreCase("delete"))
				subcardType.setSubcardTypeCertified(2);
			else
				subcardType.setSubcardTypeCertified(0);
			this.subcrdTypDao.save(subcardType);
			subcardTypeTrail.setSubcardTypeCertified(0);
			subcardTypeTrail.setSubcardTypeCertMode(0);
			subcardTypeTrail.setSubcardTypeRemark(ap.getRemarks());
			this.subcrdTypeTrailDao.save(subcardTypeTrail);
			setCertificationCertify(subcardTypeTrail.getSubcardTypeTrailId());
		});
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			SubcardTypeTrail subcardTypeTrail = this.subcrdTypeTrailDao.findById(rj.getTrailId()).get();

			SubcardType subcardType = (SubcardType) ResponseDTO.accepted().convertToEntity(subcardTypeTrail,
					SubcardType.class);
			subcardType.setSubcardTypeCertified(0);
			this.subcrdTypDao.save(subcardType);
			subcardTypeTrail.setSubcardTypeCertified(0);
			subcardTypeTrail.setSubcardTypeCertMode(1);
			this.subcrdTypeTrailDao.save(subcardTypeTrail);
			setCertificationCertify(subcardTypeTrail.getSubcardTypeTrailId());

		});

	}
	
	public void vipCertify(List<CertificationDTO> certify) {
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			VipTrail vipTrail = this.vipTrailDao.findById(ap.getTrailId()).get();

			Vip vip= (Vip)ResponseDTO.accepted().convertToEntity(vipTrail, Vip.class);

			vip.setVipId(vipTrail.getVip().getVipId());

			vip.setVipModifiedBy(vipTrail.getVipModifiedBy());
			vip.setVipModifiedDate(vipTrail.getVipModifiedDate());

			if (vipTrail.getVipAction().equalsIgnoreCase("delete"))
				vip.setVipCertified(2);
			else
				vip.setVipCertified(0);
			this.vipDao.save(vip);
			vipTrail.setVipCertified(0);
			vipTrail.setVipCertMode(0);
			vipTrail.setVipRemark(ap.getRemarks());
			this.vipTrailDao.save(vipTrail);
			setCertificationCertify(vipTrail.getVipTrailId());
		});
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			VipTrail vipTrail = this.vipTrailDao.findById(rj.getTrailId()).get();

			Vip vip = (Vip) ResponseDTO.accepted().convertToEntity(vipTrail, Vip.class);
			vip.setVipCertified(0);
			this.vipDao.save(vip);
			vipTrail.setVipCertified(0);
			vipTrail.setVipCertMode(1);
			this.vipTrailDao.save(vipTrail);
			setCertificationCertify(vipTrail.getVipTrailId());

		});
	}
	
	public void promoCodeCertify(List<CertificationDTO> certify) {
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			PromoCodeTrail prmocdeTrail = this.promoCodeTrailDao.findById(ap.getTrailId()).get();

			PromoCode prmocde= (PromoCode)ResponseDTO.accepted().convertToEntity(prmocdeTrail, PromoCode.class);

			prmocde.setPrmocdeId(prmocdeTrail.getPromoCode().getPrmocdeId());

			prmocde.setPrmocdeModifyBy(prmocdeTrail.getPrmocdeModifyBy());
			prmocde.setPrmocdeModifiedDate(prmocdeTrail.getPrmocdeModifiedDate());

			if (prmocdeTrail.getPrmocdeAction().equalsIgnoreCase("delete"))
				prmocde.setPrmocdeCertified(2);
			else
				prmocde.setPrmocdeCertified(0);
			this.promoCodeDao.save(prmocde);
			System.out.print(prmocde+"promoCodeDao");
			prmocdeTrail.setPrmocdeCertified(0);
			prmocdeTrail.setPrmocdeCertifiedMode(0);
			prmocdeTrail.setPrmocdeRemark(ap.getRemarks());
			this.promoCodeTrailDao.save(prmocdeTrail);
			System.out.print(prmocdeTrail+"promoCodeTrailDao");
			setCertificationCertify(prmocdeTrail.getPrmocdeTrailId());
		});
		// Code if the record is Rejected
				certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
					PromoCodeTrail prmocdeTrail = this.promoCodeTrailDao.findById(rj.getTrailId()).get();

					PromoCode prmocde = (PromoCode) ResponseDTO.accepted().convertToEntity(prmocdeTrail, PromoCode.class);
					prmocde.setPrmocdeCertified(0);
					this.promoCodeDao.save(prmocde);
					prmocdeTrail.setPrmocdeCertified(0);
					prmocdeTrail.setPrmocdeCertifiedMode(1);
					this.promoCodeTrailDao.save(prmocdeTrail);
					setCertificationCertify(prmocdeTrail.getPrmocdeTrailId());

				});
	}
	
	private void relationCertify(List<CertificationDTO> certify) {
		System.out.println(certify+"in relationCertify");
		certify.stream().filter(c -> Optional.ofNullable(c.getAccept()).isPresent()).forEach(cp ->
		{
		RelationTrail relationTrail = this.relationTrailDao.findById(cp.getTrailId()).get();

		Relation relation= (Relation)ResponseDTO.accepted().convertToEntity(relationTrail, Relation.class);

		relation.setRelationId(relationTrail.getRelation().getRelationId());

		relation.setRelationModifiedBy(relationTrail.getRelationModifiedBy());
		relation.setRelationModifiedDate(relationTrail.getRelationModifiedDate());

		if (relationTrail.getRelationAction().equalsIgnoreCase("delete"))
			relation.setRelationCertifed(2);
		else
			relation.setRelationCertifed(0);
		this.relationDao.save(relation);
		relationTrail.setRelationCertifed(0);
		relationTrail.setRelationCertMode(0);
		relationTrail.setRelationRemark(cp.getRemarks());
		this.relationTrailDao.save(relationTrail);
		setCertificationCertify(relationTrail.getRelationTrailId());
			
		});
		
		// Code if the record is Rejected
		certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
			ExceptionMstTrail exceptionTrail = this.exctpnTrlDao.findById(rj.getTrailId()).get();

			ExceptionMst exception = (ExceptionMst) ResponseDTO.accepted().convertToEntity(exceptionTrail, ExceptionMst.class);
			exception.setExceptionMstCertified(0);
			this.exctpnDao.save(exception);
			exceptionTrail.setExceptionMstCertified(0);
			exceptionTrail.setExceptionMstCertMode(1);
			this.exctpnTrlDao.save(exceptionTrail);
			setCertificationCertify(exceptionTrail.getExceptionMstTrailId());

		});	
}
	/* To certify list of designation master records */
	public void employeeCertify(List<CertificationDTO> certify) {
		certify.stream().filter(a -> Optional.ofNullable(a.getAccept()).isPresent()).forEach(ap ->

		{
			EmployeeTrail employeeTrail = this.empTrlDao.findById(ap.getTrailId()).get();

			Employee employee= (Employee)ResponseDTO.accepted().convertToEntity(employeeTrail, Employee.class);

			employee.setEmployeeId(employeeTrail.getEmployee().getEmployeeId());

			employee.setEmployeeModifiedBy(employeeTrail.getEmployeeModifiedBy());
			employee.setEmployeeModifiedDate(employeeTrail.getEmployeeModifiedDate());

			if (employeeTrail.getEmployeeAction().equalsIgnoreCase("delete"))
				employee.setEmployeeCertified(2);
			else
				employee.setEmployeeCertified(0);
			this.empDao.save(employee);
			employeeTrail.setEmployeeCertified(0);
			employeeTrail.setEmployeeCertMode(0);
			employeeTrail.setEmployeeRemark(ap.getRemarks());
			this.empTrlDao.save(employeeTrail);
			setCertificationCertify(employeeTrail.getEmployeeTrailId());
		});
		// Code if the record is Rejected
				certify.stream().filter(r -> Optional.ofNullable(r.getReject()).isPresent()).forEach(rj -> {
					EmployeeTrail employeeTrail = this.empTrlDao.findById(rj.getTrailId()).get();

					Employee employee = (Employee) ResponseDTO.accepted().convertToEntity(employeeTrail, Employee.class);
					employee.setEmployeeCertified(0);
					this.empDao.save(employee);
					employeeTrail.setEmployeeCertified(0);
					employeeTrail.setEmployeeCertMode(1);
					this.empTrlDao.save(employeeTrail);
					setCertificationCertify(employeeTrail.getEmployeeTrailId());

				});
	}


	
	//////////
	
	
	

	/* To set the status in Certification table as certified */
	public void setCertificationCertify(long id) {
		Certification cert = this.certificationDao.findByTrailId(id);
		cert.setCertified(0);
		cert.setCheckedTime(new Date());
		this.certificationDao.save(cert);
	}
}

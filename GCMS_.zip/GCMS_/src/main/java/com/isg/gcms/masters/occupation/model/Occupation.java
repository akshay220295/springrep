package com.isg.gcms.masters.occupation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;



@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_OCCUPATION_MST")
@Data
public class Occupation
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "OCPTN_ID")
	private Long occupationId; 
	
	@Column (name = "OCPTN_NAME")
	private String occupationName;
	
	@Column (name = "OCPTN_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date occupationCreatedDate;
	
	@Column (name = "OCPTN_CRT_BY")
	private String occupationCreatedBy;
	
	@Column (name = "OCPTN_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date occupationModifiedDate;
	
	@Column (name = "OCPTN_MOD_BY")
	private String occupationModifiedBy;
	
	@Column (name = "OCPTN_CERT")
	private Integer occupationCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;

}

package com.isg.gcms.masters.employee.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.isg.gcms.masters.salutation.model.Salutation;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table (name = "GCMS_EMPLOYEE_MST")
public class Employee {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "EMP_ID")
	private Long employeeId;
	
	@Column (name = "EMP_CODE")
	private String employeeCode;
	
	@Column (name = "EMP_SSO_ID")
	private String employeeSsoId;
	
	@Column (name = "EMP_ECN")
	private String employeeEcn;
	
	//@ManyToOne
	//@JoinColumn (name = "EMP_SALTN_ID" , referencedColumnName =  "SALTN_ID" )
	@Column (name = "EMP_SALTN_ID")
	private Long employeeSalutationId;
	
	@Column (name = "EMP_FNAME")
	private String employeeFirstName;
	
	@Column (name = "EMP_MNAME")
	private String employeeMiddleName;
	
	@Column (name = "EMP_LNAME")
	private String employeeLastName;
	
	@Column (name = "EMP_FL_NAME")
	private String employeeFullName;
	
	@Column (name = "EMP_MOB_NO")
	private Long employeeMobileNumber;
	
	@Column (name = "EMP_EMAIL")
	private String employeeEmail;
	
	@Column (name = "EMP_BR_CODE")
	private String employeeBarCode;  
	
	@Column (name = "EMP_DESIG_ID")
	private String employeeDesignationId; // May have Separate Master
 
	@Column (name = "EMP_DEPT_ID")
	private String employeeDepartmentId;  //  May have Separate Master
	
	@Column (name = "EMP_SEPTN_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date employeeSeparationDate;
	
	@Column (name = "EMP_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date employeeCreatedDate;  
	
	@Column (name = "EMP_CRT_BY")
	private String employeeCreatedby; 
	
	@Column (name = "EMP_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date employeeModifiedDate; 
	
	@Column (name = "EMP_MOD_BY")
	private String employeeModifiedBy; 
	
	@Column (name = "EMP_CERT")
	private Integer employeeCertified; 
	
	@Column (name = "BANK_ID")
	private Long BankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
}

package com.isg.gcms.masters.channel.service;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;
import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.cardtype.model.CardType;
import com.isg.gcms.masters.channel.dao.ChannelDao;
import com.isg.gcms.masters.channel.dao.ChannelTrailDao;
import com.isg.gcms.masters.channel.dto.ChannelUpdateDTO;
import com.isg.gcms.masters.channel.model.Channel;
import com.isg.gcms.masters.channel.model.ChannelTrail;
import com.isg.gcms.masters.channel.service.ChannelService;

  @Service
  public class ChannelServiceImp implements ChannelService {
	
	  
	/*
	 * To inject an instance of ChannelDao
	 */
	 @Autowired
	 private ChannelDao channelDao;
	 
	/*
	 * To inject an instance of ChannelTrailDao
	 */
	 @Autowired
	 private ChannelTrailDao channelTrailDao;
	 
	 
	 
	/*
	 * To inject an instance of CertificationDao
	 */	 
	 @Autowired
	 private CertificationDao certificationDao;

	/*
	 * To inject an instance of ResponseObj
	 */
	 @Autowired
	 private ResponseObj res;	  
	 

	/*
	 * Get all Decision with pagination.
	 */
	@Override
	public ResponseObj getAllChannel(PaginationModel pagination) 
	{
			
		Page<Channel> channel=this.channelDao.findAll(pagination.pageRequest());
		List<Channel> channelList = channel.getContent();
		if(!channelList.isEmpty())
		{
			res.addData(Constant.LIST_ALL,channelList);
		}
		else
	    {
			res.setActionError(Constant.ERROR_MSG);
		}
		
			return res;
	}
	

	/*
	 * Get all Decision without pagination.
	 */
	@Override
	public ResponseObj getAllChannel() 
	{
		List<Channel>channel=this.channelDao.findAll();
		
		if(!channel.isEmpty())
		{
			res.addData(Constant.LIST_ALL,channel);
		}
		else
	    {
			res.setActionError(Constant.ERROR_MSG);
		}
		
			return res;		
	}

	 
	/*
	 * To get Decisions based on status (active/inactive) .
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
	
		 if(status.equalsIgnoreCase("ACTIVE"))
		 {
			res.addData(Constant.ALL_ACTIVE, this.channelDao.FindAllActiveByPagination(pagination.pageRequest()));
		 }
		 else if(status.equalsIgnoreCase("INACTIVE"))
		 {
			res.addData(Constant.ALL_INACTIVE, this.channelDao.FindAllInActiveByPagination(pagination.pageRequest()));
		 }
		
		return res;
	  }
	
	
	/*
	 * To get Channel based on id.
	 */
	@Override
	public ResponseObj getById(Long id) 
	{

		Optional<Channel>channel = this.channelDao.findById(id);
		if (channel.isPresent() &&channel.get().getChannelCertified() == 0)
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(channel.get(), ChannelUpdateDTO.class));
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;

	}

	/*
	 * To get Channel based on name.
	 */
	@Override
	public ResponseObj getByName(String channelName) 
	{

		Optional<Channel> channel = findbychannelName(channelName);
		if(channel.isPresent() && channel.get().getChannelCertified()==0) {
			res.addData(Constant.BY_NAME,
					ResponseDTO.accepted().convertTo(channel.get(),ChannelUpdateDTO.class));
			
		} else
			res.setActionError(Constant.ERROR_MSG);

		  return res;
	}

	
	/*
	 * To find Channel based on name
	 */
	private Optional<Channel>findbychannelName(String channelName) 
	{
		
		return this.channelDao.findBychannelNameEqualsIgnoreCase(channelName);
		
	}
	

	/*
	 * To find Channel based on id and to use in other methods.
	 */
	private Optional<Channel> findByChannelId(Long channelId) 
	{
		return this.channelDao.findById(channelId);
	}

	
	/*
	 * To create new Channel value.
	 */
	@Override
	public ResponseObj createChannel(@RequestBody Channel channel) 
	{
		channel.setChannelCertified(1);
		channel.setChannelCreatedBy("Pooja");
		channel.setBankId(1L);  // JWT OR SESSION
		channel.setEntityId(1L); // JWT OR SESSION
		Channel chan=this.channelDao.save(channel);
		res.addData(Constant.VALUE_CREATED, chan);
		saveChannelTrail(channel,Constant.VALUE_CREATED,"NEW");
		return res;
	 }
	
	/*
	 * To save values in ChannelTrail table
	 */
	private void saveChannelTrail(Channel channel, String remarks, String action) 
	{
		
			ChannelTrail channnelTrail = (ChannelTrail) ResponseDTO.accepted().convertToEntity(channel, ChannelTrail.class);
			channnelTrail.setChannel(channel);
			channnelTrail.setChannelCreatedBy("Pooja");     /* To do replace maker with JWT */
			channnelTrail.setChannelAction(action);
			channnelTrail.setChannelRemark(remarks);
			channnelTrail.setChannelCertified(1);     /*Pending under Certification */
			this.channelTrailDao.save(channnelTrail); 
			saveCertification(channnelTrail);
	 }
		
	/*
	 * To save values in certification table
	 */
	public void saveCertification(ChannelTrail channelTrail) 
	{
		/*
		 * To inject an instance of Certification
		 */
		 
		Certification cert=new Certification();

		cert.setAction(channelTrail.getChannelAction());
		cert.setTrailId(channelTrail.getChannelTrailId());
		cert.setTableName(MasterType.CHANNEL.toString());
		cert.setCertified(1);
		cert.setMaker("Pooja");           /* To do replace maker with JWT */
		cert.setMakerTime(channelTrail.getChannelCreatedDate());
		this.certificationDao.save(cert);
		
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateChannel(Channel channel) 
	{

		Optional<Channel > channelold= findByChannelId(channel.getChannelId());
		
		System.out.println("channelID is: " + channel.getChannelId());
		if (channelold.isPresent() && channelold.get().getChannelCertified() == 0) {
			Channel channelEx =channelold.get();
			channelEx.setChannelCertified(1);
			channelEx.setChannelModifiedDate(new Date());
			channelEx.setChannelModifiedBy("POOJA");
			this.channelDao.save(channelEx);
			saveChannelTrail(channel, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, channel);
		 } else
			res.setActionError(Constant.ERROR_MSG);
		    return res;

	  }
	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) 
	{

		Optional<Channel> channel= this.channelDao.findById(id);
		if (channel.isPresent() && channel.get().getChannelCertified() == 0) 
		{
			Channel channelEx = channel.get();
			channelEx.setChannelCertified(1);
			this.channelDao.save(channelEx);
			saveChannelTrail(channelEx,Constant.VALUE_DELETED,"DELETE");
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
			
			
			
		}
		else
			res.setActionError(Constant.ERROR_MSG);
		return res;
	    }
}

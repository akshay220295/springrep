package com.isg.gcms.masters.channel.model;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;


/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */

@Data
@Entity
@Table(name = "GCMS_CHANNEL_MST_TRAIL")
public class ChannelTrail {

	
	@Id	 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "CHANNEL_TRAIL_ID")
    private Long channelTrailId; 
	
	@ManyToOne
	@JoinColumn(name = "CHANNEL_ID", referencedColumnName = "CHANNEL_ID")
    private Channel channel;  
	   
     @Column(name = "CHANNEL_NAME")
    private String  channelName; 
    
    
     @Column(name = "CHANNEL_CRT_DT")
     private  Date  channelCreatedDate;
      
     @Column(name = "CHANNEL_CRT_BY")
     private String  channelCreatedBy;  
     
    
     @Column(name = "CHANNEL_MOD_DT")
     private Date  channelModifiedDate;  
     
     @Column(name = "CHANNEL_MOD_BY")
     private String  channelModifiedBy; 
     
     @Column(name ="CHANNEL_CERT")
      private  Integer  channelCertified;
    
     @Column(name="CHANNEL_CERT_MODE") 
     private Integer  channelCertMode;    

      @Column(name="CHANNEL_ACT") 
      private String channelAction;    
     
     @Column(name="CHANNEL_RMRK") 
     private String  channelRemark;


	
	
}

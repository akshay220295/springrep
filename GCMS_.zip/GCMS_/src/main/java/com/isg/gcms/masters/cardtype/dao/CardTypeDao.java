package com.isg.gcms.masters.cardtype.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.cardtype.model.CardType;


@Repository
public interface CardTypeDao extends JpaRepository <CardType, Long>
{
	public List<CardType> findByCardTypeCertified(int id);
	
	public Optional<CardType> findByCardTypeNameEqualsIgnoreCase(String name);
	
	@Query("SELECT M FROM CardType M WHERE M.cardTypeCertified!=2")
	public Page<CardType> findAllByPagination(Pageable pageble);
	
	@Query("SELECT M FROM CardType M where M.cardTypeCertified=0 AND M.cardTypeCertified!=2")
	public Page<CardType> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM CardType M where M.cardTypeCertified=1 AND M.cardTypeCertified!=2")
	public Page<CardType> FindAllInActiveByPagination(Pageable pageable);
}

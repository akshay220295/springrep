package com.isg.gcms.masters.decision.dao;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;



import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.model.DecisionTrail;

@Repository
public interface DecisionTrailDao extends JpaRepository<DecisionTrail, Long> {

	public List<DecisionTrail> findByDecision(Decision decision);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 * 
	 */

}

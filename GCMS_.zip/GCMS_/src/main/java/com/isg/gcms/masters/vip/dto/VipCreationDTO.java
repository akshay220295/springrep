package com.isg.gcms.masters.vip.dto;

import java.util.Date;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class VipCreationDTO {
	
	private String vipName;
	
	@JsonIgnore
	private final Date vipCreatedDate = new Date();

}

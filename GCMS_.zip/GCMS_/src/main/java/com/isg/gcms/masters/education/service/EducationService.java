package com.isg.gcms.masters.education.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.education.model.Education;

@Service
public interface EducationService {
	
	public ResponseObj getAllEducation();
	public ResponseObj getAllEducation(PaginationModel pagination);
	public ResponseObj getStatus(PaginationModel pagination, String status);
	public ResponseObj getById(Long id);
	public ResponseObj update(Education education);
	public ResponseObj deleteEducation(Long id);
	public ResponseObj create(Education education);
	public ResponseObj getByName(String name);
	public Optional<Education> findbyEducationName(String educationName);

}

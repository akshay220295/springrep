package com.isg.gcms.masters.education.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.education.dto.EducationCreationDTO;
import com.isg.gcms.masters.education.dto.EducationUpdateDTO;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.service.EducationService;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_EDUCATION)
public class EducationController 
{
	
	/*
	 * To inject an instance of EducationService
	 */	
	@Autowired
	private EducationService educationService;
	
	/*
	 * Get all Education without pagination.
	 */	 
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj findAllEducation()
	{
		return this.educationService.getAllEducation();
	}
	 
	/*
	 * Get all Education with pagination.
	 */
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI)
	public  ResponseObj findAllEducation(@RequestBody PaginationModel pagination)
	{
		
		return this.educationService.getAllEducation(pagination);
	}
	
	/*
	 * To get Education based on status (active/inactive) .
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.educationService.getStatus(pagination, status) ;
	}
	
	/*
	 * To get Education based on id.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public  ResponseObj findEducationByEduId(@PathVariable("eduId") Long educationId)
	{
		return 	this.educationService.getById(educationId);
	}
	
	/*
	 * To get Education based on name.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public  ResponseObj findEducationByEduName(@PathVariable("eduName") String educationName)
	{
		return 	this.educationService.getByName(educationName);
	}
	
	/*
	 * To create a new Education .
	 */
	@PostMapping
	public ResponseObj createEducation(@RequestDTO(EducationCreationDTO.class) @Validated Education education)
	{
		return this.educationService.create(education);
	}
	
	/*
	 * To update existing Education based on id.
	 */
	@PutMapping
	public ResponseObj updateEducationById(@RequestDTO(EducationUpdateDTO.class) @Validated Education education)
	{
		return this.educationService.update(education);
	}
	
	/*
	 * To soft deleting Education based on id.
	 */
	@DeleteMapping(value =Constant.PATH_DELETE)
	public ResponseObj deleteEducation(@PathVariable("id") Long id) {

		return this.educationService.deleteEducation(id);

	}

}

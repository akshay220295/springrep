package com.isg.gcms.masters.exception.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.exception.model.ExceptionMst;

@Repository
public interface ExceptionDao extends JpaRepository<ExceptionMst, Long> {

	public Optional<ExceptionMst> findByexceptionMstNameEqualsIgnoreCase(String username);
	
	@Query("SELECT M FROM ExceptionMst M WHERE M.exceptionMstCertified!=2")
	public Page<ExceptionMst>  findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM ExceptionMst M WHERE M.exceptionMstCertified=0 AND M.exceptionMstCertified!=2")
	public Page<ExceptionMst> getActiveExcptn(Pageable pageable);
	
	@Query ("SELECT M FROM ExceptionMst M WHERE M.exceptionMstCertified=1 AND M.exceptionMstCertified!=2")
	public Page<ExceptionMst> getInactExcptn(Pageable pageable);

	public List<ExceptionMst> findByexceptionMstCertified(int id);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

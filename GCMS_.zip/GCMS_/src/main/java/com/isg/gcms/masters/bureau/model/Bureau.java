package com.isg.gcms.masters.bureau.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_BUREAU_MST")
public class Bureau 
{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BUREAU_ID")
	private Long bureauId;
	
	@Column(name="BUREAU_MEMBER_ID")
	private String bureauMemberId;
	
	@Column(name="BUREAU_PASS")
    private String bureauPassword;
	
	@Column(name="BUREAU_CATGRY")
    private String bureauCategory;
	
	@Column(name="BUREAU_CRT_DTE")
    private Date bureauCreatedDate;
	
	@Column(name="BUREAU_CRT_BY")
    private String bureauCreatedBy;
	
	@Column(name="BUREAU_MOD_DTE")
    private Date bureauModifiedDate;
	
	@Column(name="BUREAU_MOD_BY")
    private String bureauModifiedBy; 
	
	@Column(name="BUREAU_CERT")
    private Integer bureauCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId; 
	
	@Column(name = "EN_ID")
	private Long entityId;
    
}

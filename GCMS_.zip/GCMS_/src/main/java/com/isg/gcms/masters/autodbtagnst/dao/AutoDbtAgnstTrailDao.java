package com.isg.gcms.masters.autodbtagnst.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainstTrail;




@Repository
public interface AutoDbtAgnstTrailDao extends JpaRepository<AutoDebitAgainstTrail,Long>
{
	public List<AutoDebitAgainstTrail> findByAutodbtAgnst(AutoDebitAgainst autoDebitAgainst);

}

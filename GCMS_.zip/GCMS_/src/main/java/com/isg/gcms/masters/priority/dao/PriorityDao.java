package com.isg.gcms.masters.priority.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.priority.model.Priority;


@Repository
public interface PriorityDao extends JpaRepository<Priority,Long>
{
	public List<Priority> findByPriorityCertified(int id);
	
	public Optional<Priority> findByPriorityNameEqualsIgnoreCase(String name);
	
	@Query("SELECT M FROM Priority M WHERE M.priorityCertified!=2")
	public Page<Priority> findAllByPagination(Pageable pageble);
	
	@Query("SELECT M FROM Priority M where M.priorityCertified=0 AND M.priorityCertified!=2")
	public Page<Priority> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Priority M where M.priorityCertified=1 AND M.priorityCertified!=2")
	public Page<Priority> FindAllInActiveByPagination(Pageable pageable);

}

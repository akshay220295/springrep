package com.isg.gcms.masters.deferral.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.deferral.dao.DeferralDao;
import com.isg.gcms.masters.deferral.dao.DeferralTrailDao;
import com.isg.gcms.masters.deferral.dto.DefrlUpdateDto;
import com.isg.gcms.masters.deferral.model.Deferral;
import com.isg.gcms.masters.deferral.model.DeferralTrail;

@Service
public class DeferralServiceImp implements DeferralService{
	
	/*
	 * To inject an instance of DeferralDao
	 */
	@Autowired
	private DeferralDao deferralDao;
	
	/*
	 * To inject an instance of DeferralTrailDao
	 */
	@Autowired
	private DeferralTrailDao deferralTrailDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
				
	/*
	 * To inject an instance of Certification dao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Override
	public ResponseObj getAllDefrl(PaginationModel pagination) {
		Page<Deferral> deferralPage = this.deferralDao.findAllByPagination(pagination.pageRequest());
		List<Deferral> deferralList = deferralPage.getContent();
		if(!deferralList.isEmpty()) {
			res.addData(Constant.LIST_ALL, deferralList);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		 return res;
	}
	
	/*
	 * To create new Deferral
	 */
	@Override
	public ResponseObj create(@RequestBody Deferral deferral) {
		deferral.setDeferralCertified(1);
		deferral.setBankId(1L);  // JWT OR SESSION
		deferral.setEntityId(1L); // JWT OR SESSION
		Deferral defrl = this.deferralDao.save(deferral);
		res.addData(Constant.VALUE_CREATED,defrl);
		saveDefrltrail(deferral,Constant.VALUE_CREATED,"NEW");
		
		
		return res;
	}

	
	
	/*
	 * To get Deferral based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<Deferral> deferral = findDefrlId(id);
		if(deferral.isPresent() && deferral.get().getDeferralCertified()==0) {
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(deferral.get(), DefrlUpdateDto.class));
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find Deferral based on id and to use in other methods.
	 */
	@Override
	public Optional<Deferral> findDefrlId(Long id) {
		
		return this.deferralDao.findById(id);
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deletebyId(Long id) {
		Optional<Deferral> deferral = findDefrlId(id);
		if(deferral.isPresent() && deferral.get().getDeferralCertified()==0)
		{
			Deferral deferralEx = deferral.get();
			deferralEx.setDeferralCertified(1);
			saveDefrltrail(deferralEx,Constant.VALUE_DELETED,"DELETE");
			this.deferralDao.save(deferralEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
			
			
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get Deferral based on name.
	 */
	@Override
	public ResponseObj findByName(String username) {
		Optional<Deferral> deferral = findDefrlByName(username);
		if(deferral.isPresent() && deferral.get().getDeferralCertified()==0)
		{
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(deferral.get(),DefrlUpdateDto.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find Deferral based on name
	 */
	private Optional<Deferral> findDefrlByName(String username) {
		
		return this.deferralDao.findBydeferralNameEqualsIgnoreCase(username);
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateDefrl(Deferral deferral) {
		Optional<Deferral> deferralOld= findDefrlId(deferral.getDeferralId());
		
		if(deferralOld.isPresent()&&deferralOld.get().getDeferralCertified()==0)
		{
			Deferral deferralExisting = deferralOld.get();
			deferralExisting.setDeferralCertified(1);
			deferralExisting.setDeferralModifiedDate(new Date());
			deferralExisting.setDeferralModifiedBy("Supriya");//JWT token
			this.deferralDao.save(deferralExisting);
			
			saveDefrltrail(deferral, Constant.VALUE_UPDATED,"MODIFY");
			res.addData(Constant.VALUE_UPDATED, deferral);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(String status, PaginationModel pagination) {
		System.out.println(pagination);
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.deferralDao.getActiveDefrl(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.deferralDao.getInactDefrl(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To save values in Deferral Trail table
	 */
	private void saveDefrltrail(Deferral deferral, String remark, String action) {
		DeferralTrail defrlTrail =(DeferralTrail) ResponseDTO.accepted().convertToEntity(deferral, DeferralTrail.class);
		defrlTrail.setDeferral(deferral);
		defrlTrail.setDeferralCreatedBy("Supriya");
		defrlTrail.setDeferralAction(action);
		defrlTrail.setDeferralRemark(remark);
		defrlTrail.setDeferralCertified(1);
		this.deferralTrailDao.save(defrlTrail);
		saveCertification(defrlTrail);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(DeferralTrail defrlTrail) 
	{
			
			/*
			 * To inject an instance of Certification
			 */
			
			Certification cert=new Certification();
			
			cert.setAction(defrlTrail.getDeferralAction());
			cert.setTrailId(defrlTrail.getDeferralTrailId());
			cert.setTableName(MasterType.DEFERRAL.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); /* To do replace maker with JWT */
			cert.setMakerTime(defrlTrail.getDeferralCreatedDate());
			this.certificationDao.save(cert);
			
	}
	 
	/*
	 * To get all Deferral values.
	 */
	@Override
	public ResponseObj getAllDefrl() {
		List<Deferral> deferralList= this.deferralDao.findAll();
		if(!deferralList.isEmpty()) {
			res.addData(Constant.LIST_ALL, deferralList);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		 return res;
	}
		

}
package com.isg.gcms.masters.accounttype.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.accounttype.dto.AccTypCreationDTO;
import com.isg.gcms.masters.accounttype.dto.AccTypUpdateDTO;
import com.isg.gcms.masters.accounttype.model.AccountType;
import com.isg.gcms.masters.accounttype.service.AccountTypeService;


@RestController
@CrossOrigin
@RequestMapping (value = Constant.PATH_ACCOUNT_TYPE)
public class AccountTypeController 
{	
	/*
	 * To inject an instance of AcctypService
	 */
	@Autowired
	private AccountTypeService AcctypService;

	/*
	 * To create a new AccountType .
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(AccTypCreationDTO.class) @Validated AccountType accTyp)
	{
		return this.AcctypService.create(accTyp);
	}
	
	/*
	 *  To Get all AccountType with pagination.
	 */
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		return this.AcctypService.getAllAccType(pagination);
	}
	
	/*
	 * To Get all AccountType without pagination.
	 */
	@GetMapping(value = Constant.PATH_GET_ALL)
	public ResponseObj getAll()
	{
		return this.AcctypService.getAllAccType();
	}
	
	/*
	 * To get AccountType based on id.
	 */
	@GetMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getAccTypeById(@PathVariable("id") Long id)
	
	{
		
		return this.AcctypService.getById(id);
	}

	/*
	 * To get AccountType based on name.
	 */
	@GetMapping(value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.AcctypService.getByName(name);
	}
	
	/*
	 * To soft deleting AccountType based on id.
	 */
	@DeleteMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		System.out.println("delById ++++++++++++++++++++");
		
		return this.AcctypService.deleteById(id);
	}
	
	/*
	 * To update existing AccountType based on id.
	 */
	@PutMapping 
	public ResponseObj update(@RequestDTO(AccTypUpdateDTO.class) @Validated AccountType accTyp)
	{
		
		return this.AcctypService.updateAccType(accTyp);
	}
	
	/*
	 * To get AccountType based on status (active/inactive) .
	 */
	@GetMapping(value = Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.AcctypService.getstatus(status, pagination);
		
	}
}

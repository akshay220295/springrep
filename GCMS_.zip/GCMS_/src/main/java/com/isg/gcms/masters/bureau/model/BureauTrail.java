package com.isg.gcms.masters.bureau.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "GCMS_BUREAU_MST_TRAIL")
public class BureauTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="BUREAU_TRAIL_ID")
	private Long bureauTrailId; 

	@ManyToOne
	@JoinColumn(name = "BUREAU_ID", referencedColumnName = "BUREAU_ID")
	private Bureau bureau;
	
	@Column(name="BUREAU_MEMBER_ID")
	private String bureauMemberId;
	
	@Column(name="BUREAU_PASS")
    private String bureauPassword;
	
	@Column(name="BUREAU_CATGRY")
    private String bureauCategory;
	
	@Column(name="BUREAU_CRT_DTE")
    private Date bureauCreatedDate;
	
	@Column(name="BUREAU_CRT_BY")
    private String bureauCreatedBy;
	
	@Column(name="BUREAU_MOD_DTE")
    private Date bureauModifiedDate;
	
	@Column(name="BUREAU_MOD_BY")
    private String bureauModifiedBy; 
	
	@Column(name="BUREAU_CERT")
    private Integer bureauCertified;
	
	@Column(name="BUREAU_ACTION")
	private String bureauAction;	
	
	@Column(name="BUREAU_RMRK")
	private String bureauRemark;
	
	@Column (name = "BANK_ID")
	private Long bankId; 
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column(name="BUREAU_CERT_MOD")
	private Integer bureauCertMod;
	
}

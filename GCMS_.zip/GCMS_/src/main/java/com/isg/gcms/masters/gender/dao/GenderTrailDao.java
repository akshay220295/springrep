package com.isg.gcms.masters.gender.dao; 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.isg.gcms.masters.gender.model.Gender;
import com.isg.gcms.masters.gender.model.GenderTrail;


 @Repository
 public interface GenderTrailDao extends JpaRepository<GenderTrail,Long> {

 public List<GenderTrail> findByGender(Gender gender);
 
 
 
 /*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */

 
 

   }

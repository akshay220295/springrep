package com.isg.gcms.masters.bank.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;



import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;
import com.isg.gcms.masters.address.model.Address;
import com.isg.gcms.masters.entity.model.EntityBean;

import lombok.Data;


@Data
@DTO
public class BankUpdateDTO {
	
	@Id
    @NotNull
    private Long bankId;
	
	private EntityBean bankEntity;

	private String bankName;

	private String bankDescription;

	private Address bankAddress;
	
	private String bankUrl;

	@JsonIgnore
    private final Date bankModifiedDate = new Date();
}

package com.isg.gcms.masters.deferral.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.deferral.model.Deferral;
import com.isg.gcms.masters.deferral.model.DeferralTrail;

@Repository
public interface DeferralTrailDao extends JpaRepository<DeferralTrail, Long> 

{
	public List<DeferralTrail> findByDeferral(Deferral deferral);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

package com.isg.gcms.masters.salutation.dao;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.model.SalutationTrail;

@Repository
public interface SalutationTrailDao extends JpaRepository<SalutationTrail,Long> 
	{
		
		public List<SalutationTrail> findBySalutation(Salutation salutation);
	
	}

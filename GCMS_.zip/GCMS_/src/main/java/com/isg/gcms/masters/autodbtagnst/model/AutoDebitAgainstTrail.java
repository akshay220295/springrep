package com.isg.gcms.masters.autodbtagnst.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "GCMS_AUTO_DBT_AGNST_MST_TRAIL")
public class AutoDebitAgainstTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="AUTO_DBT_AGNST_TRAIL_ID")
	private Long autodbtAgnstTrailId;   
	
	@ManyToOne
	@JoinColumn(name = "AUTO_DBT_AGNST_ID", referencedColumnName = "AUTO_DBT_AGNST_ID")
	private AutoDebitAgainst autodbtAgnst;
	
	@Column(name="AUTO_DBT_AGNST_NAME")
	private String autodbtAgnstName;
	
	@Column(name="AUTO_DBT_AGNST_CRT_DTE")
	private Date autodbtAgnstCrtDte;
	
	@Column(name="AUTO_DBT_AGNST_CRT_BY")
	private String autodbtAgnstCrtdBy; 
	
	@Column(name="AUTO_DBT_AGNST_MOD_DTE")
	private Date  autodbtAgnstModDte; 
	
	@Column(name="AUTO_DBT_AGNST_MOD_BY")
	private String  autodbtAgnstModBy; 
	
	@Column(name="AUTO_DBT_AGNST_CERT")
	private Integer  autodbtAgnstCertified; 
	
	@Column(name="AUTO_DBT_AGNST_ACTION")
	private String autodbtAgnstAction;	
	
	@Column(name="AUTO_DBT_AGNST_RMRK")
	private String autodbtAgnstRemark;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column(name="AUTO_DBT_AGNST_CERT_MOD")
	private Integer autoDebitAgainstCertMod;
	
}

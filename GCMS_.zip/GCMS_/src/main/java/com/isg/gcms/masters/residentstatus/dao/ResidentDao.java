package com.isg.gcms.masters.residentstatus.dao;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.isg.gcms.masters.residentstatus.model.Resident;


@Repository
public interface ResidentDao  extends JpaRepository<Resident, Long>
{
	
	public Optional<Resident> findByResidentNameEqualsIgnoreCase(String residentName);

	public Optional<Resident> findByresidentName(String residentName);

	@Query("SELECT R FROM Resident R WHERE R.residentCertified!=2")
	public Page<Resident>findAllByPagination(Pageable pageable);

	@Query("SELECT M FROM Resident M where M.residentCertified=0 AND M.residentCertified!=2")
	public Page<Resident> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Salutation M where M.salutationCertified=1 AND M.salutationCertified!=2")
	public Page<Resident> FindAllInActiveByPagination(Pageable pageable);

	public List<Resident> findByResidentCertified(int id);

	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
	
	
 }




package com.isg.gcms.masters.entity.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;


@Data
@DTO
public class EntityUpdateDTO {

	@Id
    @NotNull
    private Long entityId;
	
	private String entityName;

	private String entityDescription;
	
	@JsonIgnore
    private final Date entityModifiedDate = new Date();
	
	
}

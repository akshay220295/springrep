package com.isg.gcms.masters.relation.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.promocode.model.PromoCodeTrail;
import com.isg.gcms.masters.relation.dao.RelationDao;
import com.isg.gcms.masters.relation.dao.RelationTrailDao;
import com.isg.gcms.masters.relation.dto.RltnUpdateDTO;
import com.isg.gcms.masters.relation.model.Relation;
import com.isg.gcms.masters.relation.model.RelationTrail;

@Service
public class RelationServiceImp implements RelationService 
{	
	/* To inject instance of RelationDao class */
	@Autowired
	private RelationDao rltnDao;
	
	/* To inject instance of RelationTrailDao class */
	@Autowired
	private RelationTrailDao rltnTrlDao;
	
	/* To inject instance of ResponseObj */
	@Autowired
	private ResponseObj res; 
	
	
	
	/* To inject instance of certificationDao */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllRltn(PaginationModel pagination) 
	{
		Page<Relation> rltnPage = this.rltnDao.findAllByPagination(pagination.pageRequest());
		List<Relation> rltnPageList = rltnPage.getContent();
		if(!rltnPageList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, rltnPageList );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Relationship based on id and to use in other methods.
	 */
	@Override
	public Optional<Relation> findById(Long id) 
	{

		return this.rltnDao.findById(id);
	}
	
	/*
	 * To get Relationship based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<Relation> rltn = this.findById(id);
		if (rltn.isPresent() && rltn.get().getRelationCertifed() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(rltn.get(), RltnUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Relationship based on name and to use in other methods
	 */
	public Optional<Relation> getByName(String name) {
		return rltnDao.findByrelationNameEqualsIgnoreCase(name);
	}

	/*
	 * To get Relationship based on name.
	 */
	
	@Override
	public ResponseObj findByName(String name) {
		Optional<Relation> rltn = this.getByName(name);
		if (rltn.isPresent() && rltn.get().getRelationCertifed() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(rltn.get(), RltnUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new Relationship value.
	 */
	@Override
	public ResponseObj create(Relation relation) {
		relation.setRelationCertifed(1);
		relation.setRelationCreatedBy("Aditya"); // To Do -- will be replaced by JWT token or any other
															
		Relation rltn = this.rltnDao.save(relation);
		saveRltnTrail(rltn,Constant.VALUE_CREATED, "NEW");
		res.addData(Constant.VALUE_CREATED, rltn);
		return res;
	}

	/*
	 * To Update existing value based on id.
	 */
	@Override
	public ResponseObj updateRltn(Relation relation) {
		Optional<Relation> rltnOld = findById(relation.getRelationId());
		
		if(rltnOld.isPresent() && rltnOld.get().getRelationCertifed() == 0)
		{
			Relation rltnEx = rltnOld.get();
			rltnEx.setRelationCertifed(1);
			rltnEx.setRelationModifiedDate(new Date());
			rltnEx.setRelationModifiedBy("Abhishek");
			this.rltnDao.save(rltnEx);
			saveRltnTrail(relation, Constant.VALUE_UPDATED, "MODIFY" );
			res.addData(Constant.VALUE_UPDATED, relation);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<Relation> rltn = this.findById(id);
		
		if(rltn.isPresent() && rltn.get().getRelationCertifed() == 0)
		{
			Relation rltnEx = rltn.get();
			rltnEx.setRelationCertifed(1);
			saveRltnTrail(rltnEx,Constant.VALUE_DELETED,"DELETED");
			this.rltnDao.save(rltnEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
			}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
	return res;
	}

	/*
	 * To save values in Relationship Trail table
	 */
	public void saveRltnTrail(Relation relation, String remark, String action) {
		RelationTrail rltnTrail = (RelationTrail) ResponseDTO.accepted().convertToEntity(relation,RelationTrail.class);
		rltnTrail.setRelation(relation);
		rltnTrail.setRelationCreatedBy("adi");
		rltnTrail.setRelationAction(action);
		rltnTrail.setRelationCertifed(1);;
		rltnTrail.setRelationRemark(remark);

		this.rltnTrlDao.save(rltnTrail);
		
		saveCertification(rltnTrail);
	}

	/*
	 * To save values in Certification table
	 */
	public void saveCertification(RelationTrail rltnTrail) 
	{
		
		/* To inject an instance of Certification */
	
		 Certification cert=new Certification();
		
			cert.setAction(rltnTrail.getRelationAction());
			cert.setTrailId(rltnTrail.getRelationTrailId());
			cert.setTableName(MasterType.RELATION.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(rltnTrail.getRelationCreatedDate());
			this.certificationDao.save(cert);
			
	}

	/*
	 * To get all Relationship values.
	 */
	@Override
	public ResponseObj getAllRltn() {
		List<Relation> rltnList = this.rltnDao.findAll();
		if(!rltnList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, rltnList );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get values based on status (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.rltnDao.getActiveRltn(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this. rltnDao. getInactRltn(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

}

package com.isg.gcms.masters.address.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.address.dao.AddressDao;
import com.isg.gcms.masters.address.dto.AddressUpdateDTO;
import com.isg.gcms.masters.address.model.Address;



@Service

public class AddressServiceImpl implements AddressService {

	@Autowired
	public AddressDao addressDao;

	@Autowired
	public ResponseObj res;

	@Override
	public ResponseObj getAllAddress(PaginationModel pagination) {

		res.addData("Address List", this.addressDao.findAll(pagination.pageRequest()));

		return res;

	}

	@Override
	public Optional<Address> findAddressById(Long addressId) {

		return this.addressDao.findById(addressId);
	}

	@Override
	public ResponseObj getAddressById(long addressId) {

		Optional<Address> address = findAddressById(addressId);
		if (address.isPresent())
			res.addData("Address by address Id",
					ResponseDTO.accepted().convertTo(address.get(), AddressUpdateDTO.class));
		else
			res.setActionError("Address not found for id: " + addressId);

		return res;
	}



	@Override
	public ResponseObj saveAddress(Address address) {

		address.setAddressCreatedBy("Srushti"); // To do replace maker with JWT
		res.addData("Save Address", this.addressDao.save(address));
		return res;

	}

	@Override
	public ResponseObj deleteAddress(Long id) {

		Optional<Address> address = findAddressById(id);

		if (address.isPresent()) {
			this.addressDao.delete(address.get());
			res.setMsg("Address Deleted", ResponseMsgType.SUCCESS);
		} else
			res.setActionError("Address not found with id " + id);

		return res;
	}

	@Override
	public ResponseObj updateAddress(Address address) {
		
		Optional<Address> addressO = findAddressById(address.getAddressId());
		if (addressO.isPresent()) {
			
			this.addressDao.save(address);
		} else
			res.setActionError("Address not found with Id " + address.getAddressId());

		return res;
	}

}

package com.isg.gcms.masters.bank.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.masters.bank.dto.BankCreationDTO;
import com.isg.gcms.masters.bank.model.Bank;
import com.isg.gcms.masters.bank.service.BankService;
import com.isg.gcms.common.response.ResponseObj;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_BANK)
public class BankController {

	@Autowired
	public BankService bankService;

	@GetMapping
	public ResponseObj getAllBanks(Pageable pageable) {

		return this.bankService.getAllBank(pageable);
	}

	@GetMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getBankById(@PathVariable("id") int bankId) {

		return this.bankService.getBankById(bankId);

	}

	@GetMapping(value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getBankByName(@PathVariable("name") String bankName) 
	{

		return this.bankService.getByName(bankName);

	}

	@GetMapping(value = Constant.PATH_ENTITY + Constant.PATH_VARIABLE_ID)
	public ResponseObj getBankByEntity(@PathVariable("name") Long entityId) {

		return this.bankService.getByEntity(entityId);

	}

	/* To create a new bank . */
	@PostMapping(path = "/create")
	public ResponseObj createBank(@RequestDTO(BankCreationDTO.class) @Validated Bank bank) {
		
		return this.bankService.saveBank(bank);
	}

	/* To update existing bank. */
	// @ApiOperation(httpMethod = "PUT", hidden = true, value = "")
	@PutMapping(path = "/update")
	public ResponseObj updateBank(@RequestBody @Valid Bank bank) {

		return this.bankService.updateBank(bank);
	}

	/* To soft delete a bank based on bank id */
	// @ApiOperation(value = "Description here.", httpMethod = "DELETE", hidden =
	// true)
	@DeleteMapping(path = "/delete/{id}")
	public ResponseObj deleteBank(@PathVariable("id") Long bankId) {

		return this.bankService.deleteBank(bankId);

	}

}

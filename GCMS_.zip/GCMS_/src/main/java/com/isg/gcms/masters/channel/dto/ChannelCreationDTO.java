package com.isg.gcms.masters.channel.dto;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;


@Data
@DTO
public class ChannelCreationDTO
{
	private String channelName;

	@JsonIgnore
    private final Date channelCreatedDate = new Date();
	
}

package com.isg.gcms.masters.exception.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;


import lombok.Data;


/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */
@Entity
@Data
@Table(name = "GCMS_EXCEPTION_MST_TRAIL")
public class ExceptionMstTrail {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	@Column (name = "EXCPTN_TRAIL_ID")
	private Long exceptionMstTrailId;
	
	@ManyToOne
	@JoinColumn(name = "EXCPTN_ID", referencedColumnName = "EXCPTN_ID")
	private ExceptionMst exceptionMst;
	
	@Column(name="EXCPTN_NAME")
	private String exceptionMstName;
	
	@Column(name="EXCPTN_CRT_DTE")
//	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date exceptionMstCreatedDate;
	
	@Column(name="EXCPTN_CRT_BY")
	private String exceptionMstCreatedBy;
	
	@Column(name="EXCPTN_MOD_DTE")
//	@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date exceptionMstModifiedDate;
	
	@Column(name="EXCPTN_MOD_BY")
	private String exceptionMstModifiedBy;
	
	@Column(name="EXCPTN_CERT")
	private Integer exceptionMstCertified;
	
	@Column(name="EXCPTN_ACT")
	private String exceptionMstAction;
	
	@Column(name="EXCPTN_RMRK")
	private String exceptionMstRemark;
	
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column (name = "EXCPTN_CERT_MODE")
	private Integer exceptionMstCertMode;
	
	
	
	
}

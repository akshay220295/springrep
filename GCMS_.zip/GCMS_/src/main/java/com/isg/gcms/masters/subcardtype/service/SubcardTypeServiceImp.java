package com.isg.gcms.masters.subcardtype.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;

import com.isg.gcms.masters.subcardtype.dao.SubcardTypeDao;
import com.isg.gcms.masters.subcardtype.dao.SubcardTypeTrailDao;
import com.isg.gcms.masters.subcardtype.dto.SubcrdTypeUpdateDTO;
import com.isg.gcms.masters.subcardtype.model.SubcardType;
import com.isg.gcms.masters.subcardtype.model.SubcardTypeTrail;

@Service
public class SubcardTypeServiceImp implements SubcardTypeService
{	
	/* To inject an instance of SubcardTypeDao 
	 * 
	*/	
	@Autowired
	private SubcardTypeDao subcrdTypDao;
	
	/*
	 * To inject an instance of SubcardTypeTrailDao
	*/	@Autowired
	private SubcardTypeTrailDao subcrdTypTrlDao;
	
	
					
	/*
	 *  To inject an instance of CertificationDao
	 */	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To inject an instance of responseObj
	 */	@Autowired
	private ResponseObj res;

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllSubcrdTyp(PaginationModel pagination) {
		Page<SubcardType> subCardPage = this.subcrdTypDao.findAllByPagination(pagination.pageRequest());
		List<SubcardType> subCardList = subCardPage.getContent();
		if(!subCardList.isEmpty()) {
			res.addData(Constant.LIST_ALL, subCardList);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all SubcardType values.
	 */
	@Override
	public ResponseObj getAllSubcrdTyp() {
		List<SubcardType> subCardList = this.subcrdTypDao.findAll();
		if(!subCardList.isEmpty()){
			res.addData(Constant.LIST_ALL, subCardList);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find SubcardType based on id and to use in other methods.
	 */
	@Override
	public Optional<SubcardType> findById(Long id) {
		return this.subcrdTypDao.findById(id);  
		
	}

	/*
	 * To get SubcardType based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<SubcardType> subcrdTyp = this.findById(id);
		if(subcrdTyp.isPresent() && subcrdTyp.get().getSubcardTypeCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(subcrdTyp.get(), SubcrdTypeUpdateDTO.class ));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find SubcardType based on name
	 */
	public Optional<SubcardType> getByName(String name) {
		return subcrdTypDao.findBysubcardTypeNameEqualsIgnoreCase(name);
	}

	/*
	 * To get SubcardType based on name.
	 */
	@Override
	public ResponseObj findByName(String name) {
		Optional<SubcardType> subcrdTyp = this.getByName(name);
		if (subcrdTyp.isPresent() && subcrdTyp.get().getSubcardTypeCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(subcrdTyp.get(), SubcrdTypeUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new SubcardType value.
	 */
	@Override
	public ResponseObj create(SubcardType subcrdTyp) {
		subcrdTyp.setSubcardTypeCertified(1);
		subcrdTyp.setSubcardTypeCreatedby("adi");  //JWT orSession
		subcrdTyp.setBankId(1L);  // JWT OR SESSION
		subcrdTyp.setEntityId(1L); // JWT OR SESSION
		SubcardType subcrdTypTrl = this.subcrdTypDao.save(subcrdTyp);
		saveSubcrdTypTrail(subcrdTypTrl,Constant.VALUE_CREATED,"NEW" );
		res.addData(Constant.VALUE_CREATED, subcrdTypTrl);
		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<SubcardType> subcardTyp = this.findById(id);
		if (subcardTyp.isPresent() && subcardTyp.get().getSubcardTypeCertified() == 0) 
		{
			SubcardType subcardTypEx = subcardTyp.get();
			subcardTypEx.setSubcardTypeCertified(1);
			saveSubcrdTypTrail(subcardTypEx,Constant.VALUE_DELETED,"DELETE" );
			this.subcrdTypDao.save(subcardTypEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateSubcrdTyp(SubcardType subcrdTyp) {
		Optional<SubcardType> subcrdTypOld = findById(subcrdTyp.getSubcardTypeId());
		if (subcrdTypOld.isPresent() && subcrdTypOld.get().getSubcardTypeCertified() == 0)
		{
			SubcardType subcrdTypEx = subcrdTypOld.get();
			subcrdTypEx.setSubcardTypeCertified(1);
			subcrdTypEx.setSubcardTypeModifiedDate(new Date());
			subcrdTypEx.setSubcardTypeModifiedBy("Abhishek");
			this.subcrdTypDao.save(subcrdTypEx);
			saveSubcrdTypTrail(subcrdTyp,Constant.VALUE_UPDATED,"MODIFY" );
			res.addData(Constant.VALUE_UPDATED, subcrdTyp );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.subcrdTypDao.getActiveSubcrdTyp(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.subcrdTypDao.getInactSubcrdTyp(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in SubcardType Trail table
	 */
	public void saveSubcrdTypTrail(SubcardType subcrdTyp, String remark, String action) {
		SubcardTypeTrail subcrdTypTrl = (SubcardTypeTrail) ResponseDTO.accepted().convertToEntity(subcrdTyp,
				SubcardTypeTrail.class);
		subcrdTypTrl.setSubcardType(subcrdTyp);
		subcrdTypTrl.setSubcardTypeCreatedby("adi"); //JWT OR Session
		subcrdTypTrl.setSubcardTypeAction(action);
		subcrdTypTrl.setSubcardTypeCertified(1);
		subcrdTypTrl.setSubcardTypeRemark(remark);

		this.subcrdTypTrlDao.save(subcrdTypTrl);
		saveCertification(subcrdTypTrl);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(SubcardTypeTrail subcrdTypeTrl) 
	{
		/* 
		 * To inject an instance of Certification
		*/
	
		Certification cert=new Certification();
		
			cert.setAction(subcrdTypeTrl.getSubcardTypeAction());
			cert.setTrailId(subcrdTypeTrl.getSubcardTypeTrailId());
			cert.setTableName(MasterType.SUBCARDTYPE.toString());
			cert.setCertified(1);
			cert.setMaker("Supriya"); // To do replace maker with JWT
			cert.setMakerTime(subcrdTypeTrl.getSubcardTypeCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.certification.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dto.CertificationDTO;
import com.isg.gcms.common.response.ResponseObj;

@Service
public interface CertificationService
{
	public ResponseObj populateMaster();

	public ResponseObj confirmCertify(List<CertificationDTO> certify, String masterName);
	
	public <K,V> ResponseObj listCertification(String masterName);

}

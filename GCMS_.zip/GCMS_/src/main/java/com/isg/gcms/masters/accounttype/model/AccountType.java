package com.isg.gcms.masters.accounttype.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "GCMS_ACCOUNT_TYPE_MST")
public class AccountType 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "AC_TYP_ID")
	private Long accountTypeId;
	
	@Column (name = "AC_TYP_NAME")
	private String accountTypeName;
	
	@Column (name = "AC_TYP_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date accountTypeCreatedDate;
	
	@Column (name = "AC_TYP_CRT_BY")
	private String accountTypeCreatedBy;
	
	@Column (name = "AC_TYP_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date accountTypeModifiedDate;
	
	@Column (name = "AC_TYP_MOD_BY")
	private String accountTypeModifiedBy;
	
	@Column (name = "AC_TYP_CERT")
	private Integer accountTypeCertified;

}

package com.isg.gcms.masters.decision.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.decision.dto.DecisnCreationDTO;
import com.isg.gcms.masters.decision.dto.DecisnUpdateDTO;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.decision.service.DecisionService;


@RestController
@RequestMapping(value=Constant.PATH_DECISION)
@CrossOrigin("*")
public class DecisionController 
{
	@Autowired
	private DecisionService decisnService;
	
	/*
	 * To create a new Decision .
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(DecisnCreationDTO.class) @Validated Decision decision)
	{
		return this.decisnService.create(decision);
	}
	
	/*
	 * Get all Decision with pagination.
	 */
	@PostMapping(value= Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAll(@RequestBody PaginationModel pagination)
	{
		return this.decisnService.getAllDecision(pagination);
	}
	
	/*
	 * Get all Decision without pagination.
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj getAllDecision()
	{
		return this.decisnService.getAllDecision();
	}
	
	/*
	 * To get Decision based on id.
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getMrtlStsById(@PathVariable("id") Long id)
	
	{
		return this.decisnService.getById(id);
	}
	
	/*
	 * To get Decision based on name.
	 */
	@GetMapping( value =Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("name") String name)
	{
		return this.decisnService.findByName(name);
	}
	
	/*
	 * To soft deleting Decision based on id.
	 */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.decisnService.deleteById(id);
	}
	
	/*
	 * To update existing Decision based on id.
	 */
	@PutMapping 
	public ResponseObj update(@RequestDTO(DecisnUpdateDTO.class) @Validated Decision decision)
	{
		return this.decisnService.updateDecisn(decision);
	}
	
	/*
	 * To get Decisions based on status (active/inactive) .
	 */
	@GetMapping(Constant.PATH_VARIABLE_STATUS)
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		return this.decisnService.getstatus(status, pagination);
		
	}

}

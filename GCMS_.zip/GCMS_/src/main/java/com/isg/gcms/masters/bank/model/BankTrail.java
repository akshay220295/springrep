package com.isg.gcms.masters.bank.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.URL;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;


/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */

@Data
@Entity
@Table(name = "RBAC_BANK_HDR_TRAIL")
public class BankTrail  {
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "BNK_TRAIL_ID", length = 12)
	private long bankTrailId;

	@ManyToOne
	@JoinColumn(name = "BNK_ID", referencedColumnName = "BNK_ID")
	private Bank bank;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 15)
	@Column(name = "BNK_NAME", length = 128)
	private String bankName;

	@Size(min = 2, max = 256)
	@Column(name = "BNK_DESC", length = 256)
	private String bankDescription;

	@URL(protocol = "http")
	@NotBlank(message = "Url is mandatory")
	@Column(name = "BNK_URL", length = 100)
	private String bankUrl;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)
	@Column(name = "BNK_CRTDBY", length = 150)
	private String bankCreatedBy;

	@Pattern(regexp = "^[ A-Za-z]+$")
	@Size(min = 3, max = 12)
	@Column(name = "BNK_MODBY", length = 150)
	private String bankModifiedBy;

	@Column(name = "BNK_CERTIFIED", length = 6)
	private Integer bankCertified;

	@Column(name = "BNK_CERTMODE", length = 1)
	private Integer bankCertifiedMode;

	@Column(name = "BNK_ACTION", length = 10)
	private String bankAction;

	@Column(name = "BNK_REMARK", length = 256)
	private String bankRemark;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name = "BNK_MODDT")
	private Date bankModifiedDate;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING,pattern="dd-MM-yyyy")
	@Column(name = "BNK_CRTDDT", length = 50)
	private Date bankCreatedDate;

}

package com.isg.gcms.masters.vip.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.vip.model.Vip;

@Service
public interface VipService  {

	public ResponseObj getAllVip(PaginationModel pagination);

	public ResponseObj create(Vip vip);

	public ResponseObj getById(Long id);

	public Optional<Vip> findById(Long id);

	public ResponseObj deleteById(Long id);

	public ResponseObj findByName(String name);

	public ResponseObj updateVip(Vip vip);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);
	
	public ResponseObj getAllVip();
}

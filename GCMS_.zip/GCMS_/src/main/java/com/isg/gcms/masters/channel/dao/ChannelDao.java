package com.isg.gcms.masters.channel.dao;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.channel.model.Channel;

@Repository
public interface ChannelDao extends JpaRepository< Channel, Long>

 {
	public Optional<Channel> findBychannelNameEqualsIgnoreCase(String channelName);
	
	public List<Channel> findByChannelCertified(int id);

	@Query("SELECT M FROM Channel M WHERE M.channelCertified!=2")
	public Page<Channel>findAllByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Channel M where M.channelCertified=0 AND M.channelCertified!=2")
	public Page<Channel> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Channel M where M.channelCertified=1 AND M.channelCertified!=2")
	public Page<Channel> FindAllInActiveByPagination(Pageable pageable);

	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
	
	
	
  }


	






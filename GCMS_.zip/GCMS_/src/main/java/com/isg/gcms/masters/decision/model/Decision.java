package com.isg.gcms.masters.decision.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
@Table(name = "GCMS_DECISION_MST")
public class Decision 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "DECISN_ID")
	private Long decisionId;
	
	@Column (name = "DECISN_NAME")
	private String decisionName;
	
	@Column (name = "DECISN_CRT_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date decisionCreatedDate;
	
	@Column (name = "DECISN_CRT_BY")
	private String decisionCreatedBy;
	
	@Column (name = "DECISN_MOD_DTE")
	//@JsonFormat(shape = JsonFormat.Shape.STRING , pattern = "dd-mm-yyyy")
	private Date decisionModifiedDate;
	
	@Column (name = "DECISN_MOD_BY")
	private String decisionModifiedBy;
	
	@Column (name = "DECISN_CERT")
	private Integer decisionCertified;

}

package com.isg.gcms.masters.bank.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import  com.isg.gcms.masters.bank.model.Bank;

@Repository
public interface BankDao extends JpaRepository<Bank, Long>
{

	public Optional<Bank> findByBankNameIgnoreCase(String bankName);

	public List<Bank> findByBankCertified(int id);

	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */

}

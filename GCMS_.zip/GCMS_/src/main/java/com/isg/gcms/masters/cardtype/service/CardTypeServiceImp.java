package com.isg.gcms.masters.cardtype.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.bureau.model.Bureau;
import com.isg.gcms.masters.cardtype.dao.CardTypeDao;
import com.isg.gcms.masters.cardtype.dao.CardTypeTrailDao;
import com.isg.gcms.masters.cardtype.dto.CardTypeUpdateDTO;
import com.isg.gcms.masters.cardtype.model.CardType;
import com.isg.gcms.masters.cardtype.model.CardTypeTrail;


@Service
public class CardTypeServiceImp implements CardTypeService {
	
	/*
	 * To inject an instance of CardTypeDao
	 */
	@Autowired
	CardTypeDao cardTypeDao;
	
	/*
	 * To inject an instance of CardTypeTrailDao
	 */
	@Autowired
	CardTypeTrailDao cardTypeTrailDao;

	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	ResponseObj res;
	
	
	
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	
	/*
	 * To find CardType based on id and to use in other methods.
	 */
	public Optional<CardType> findByCardTypeId(Long id)
	{
		return this.cardTypeDao.findById(id);
	}
	
	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.cardTypeDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.cardTypeDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}
	
	/*
	 * To get all CardType values.
	 */
	@Override
	public ResponseObj getAllCardType() 
	{
		List<CardType> cardType=this.cardTypeDao.findAll();
		if(!cardType.isEmpty())
		{
			res.addData(Constant.LIST_ALL, cardType);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllCardType(PaginationModel pagination) 
	{
		Page<CardType> cardType=this.cardTypeDao.findAll(pagination.pageRequest());
		List<CardType> cardTypeList = cardType.getContent();
		if(!cardType.isEmpty())
		{
			res.addData(Constant.LIST_ALL, cardTypeList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	
	/*
	 * To get CardType based on id.
	 */
	@Override
	public ResponseObj getById(Long id) 
	{
		Optional<CardType> cardType=this.cardTypeDao.findById(id);
		if(cardType.isPresent() && cardType.get().getCardTypeCertified()==0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(cardType.get(), CardTypeUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	
	/*
	 * To get CardType based on name.
	 */
	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<CardType> cardType=this.cardTypeDao.findByCardTypeNameEqualsIgnoreCase(name);
		
		if(cardType.isPresent() && cardType.get().getCardTypeCertified()==0)
		{
			res.addData(Constant.BY_NAME,ResponseDTO.accepted().convertTo(cardType.get(), CardTypeUpdateDTO.class ) );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To find CardType based on name
	 */
	@Override
	public Optional<CardType> findbyCardTypeName(String cardTypeName) 
	{
		return this.cardTypeDao.findByCardTypeNameEqualsIgnoreCase(cardTypeName);
	}
	
	/*
	 * To create new CardType value.
	 */ 
	@Override
	public ResponseObj create(@RequestBody CardType cardType) 
	{
		cardType.setCardTypeCertified(1);
		cardType.setCardTypeCreatedBy("Ajit");
		cardType.setBankId(1L);  // JWT OR SESSION
		cardType.setEntityId(1L); // JWT OR SESSION
		// To Do Set Created By here.
		CardType crdtyp=this.cardTypeDao.save(cardType);
		res.addData(Constant.VALUE_CREATED, crdtyp);
		saveCardTypeTrail(cardType, Constant.VALUE_CREATED, "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(CardType cardType) 
	{
		
		Optional<CardType> crdtyp= findByCardTypeId(cardType.getCardTypeId());
		
		if(crdtyp.isPresent() &&  crdtyp.get().getCardTypeCertified()==0)
		{
			CardType cardTypeExisting = crdtyp.get();
			cardTypeExisting.setCardTypeCertified(1);
			cardTypeExisting.setCardTypeModifiedDate(new Date());
			cardTypeExisting.setCardTypeModifiedBy("Ajit");//JWT
			this.cardTypeDao.save(cardTypeExisting);
			saveCardTypeTrail(cardType, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, cardType);
		}
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
		
	}

	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteCardType(Long id) 
	{
		Optional<CardType> cardType = findByCardTypeId(id);

		if (cardType.isPresent() && cardType.get().getCardTypeCertified()==0) {
			CardType cardTypeExisting = cardType.get();
			cardTypeExisting.setCardTypeCertified(1);
			this.cardTypeDao.save(cardTypeExisting);
			saveCardTypeTrail(cardTypeExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}


	/*
	 * To save values in CardType Trail table
	 */
	public void saveCardTypeTrail(CardType cardType, String remark, String action)
	{
		CardTypeTrail cardTypeTrail=(CardTypeTrail)ResponseDTO.accepted().convertToEntity(cardType, CardTypeTrail.class);
		
		cardTypeTrail.setCardType(cardType);
		cardTypeTrail.setCardTypeCreatedBy("Ajit");
		cardTypeTrail.setCardTypeAction(action);
		cardTypeTrail.setCardTypeRemark(remark);
		cardTypeTrail.setCardTypeCertified(1);
		
		this.cardTypeTrailDao.save(cardTypeTrail);
		saveCertification(cardTypeTrail);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(CardTypeTrail cardTypeTrail) 
	{
			/*
			 * To inject an instance of Certification
			 */
			
			Certification cert =new Certification();
		
			cert.setAction(cardTypeTrail.getCardTypeAction());
			cert.setTrailId(cardTypeTrail.getCardTypeTrailId());
			cert.setTableName(MasterType.CARDTYPE.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); /* To do replace maker with JWT */
			cert.setMakerTime(cardTypeTrail.getCardTypeCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.accounttype.dao;


import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.isg.gcms.masters.accounttype.model.AccountType;


@Repository
public interface AccountTypeDao extends JpaRepository<AccountType, Long>
{
	public Optional<AccountType> findByaccountTypeNameEqualsIgnoreCase(String name);

	@Query ("SELECT M FROM AccountType M WHERE M.accountTypeCertified!=2") 
	public Page<AccountType> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM AccountType M WHERE M.accountTypeCertified=0 AND M.accountTypeCertified=2")
	public Page<AccountType> getActiveAccType(Pageable pageable);
	
	@Query ("SELECT M FROM AccountType M WHERE M.accountTypeCertified=1 AND M.accountTypeCertified=2")
	public Page<AccountType> getInactiveAccType(Pageable pageable);
	
	public List<AccountType> findByaccountTypeCertified(int id);

}

package com.isg.gcms.masters.promocode.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class PromoCodeCreationDTO {
	
	private String prmocdeName;
	
	@JsonIgnore
	private final Date prmocdeCreatedDate = new Date();
	
	
}

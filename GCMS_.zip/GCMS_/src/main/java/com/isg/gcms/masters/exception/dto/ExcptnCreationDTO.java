package com.isg.gcms.masters.exception.dto;

import java.util.Date;

import com.isg.gcms.common.bind.DTO;
import lombok.Data;

@Data
@DTO
public class ExcptnCreationDTO {

		private String exceptionMstName; 
		
		private final Date exceptionMstCreatedDate = new Date();
}

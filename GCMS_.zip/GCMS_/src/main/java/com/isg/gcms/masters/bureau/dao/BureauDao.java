package com.isg.gcms.masters.bureau.dao;



import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.isg.gcms.masters.bureau.model.Bureau;


@Repository
public interface BureauDao extends JpaRepository<Bureau , Long>
{
	public List<Bureau> findByBureauCertified(int id);
	
	@Query("SELECT M FROM Bureau M WHERE M.bureauCertified!=2")
	public Page<Bureau> findAllByPagination(Pageable pageble);
	
	@Query("SELECT M FROM Bureau M where M.bureauCertified=0 AND M.bureauCertified!=2")
	public Page<Bureau> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM Bureau M where M.bureauCertified=1 AND M.bureauCertified!=2")
	public Page<Bureau> FindAllInActiveByPagination(Pageable pageable);
}

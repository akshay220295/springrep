package com.isg.gcms.masters.autodbtagnst.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.autodbtagnst.dto.AutoDebitAgainstCreationDTO;
import com.isg.gcms.masters.autodbtagnst.dto.AutoDebitAgainstUpdateDTO;
import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;
import com.isg.gcms.masters.autodbtagnst.service.AutoDbtAgnstService;

@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_AUTODBTAGNST)
public class AutoDbtAgnstController {
	
	@Autowired
	private AutoDbtAgnstService autoDbtAgnstService;
	
	
	 
	/*
	 * To get AutoDebitAgainsts based on status (active/inactive) .
	 */	  	
	@GetMapping(value= Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.autoDbtAgnstService.getStatus(pagination, status) ;
	}
	
	@GetMapping(value= Constant.PATH_GET_ALL)
	public ResponseObj findAllAutoDebitAgainst()
	{
		return this.autoDbtAgnstService.getAllAutoDebitAgainst();
	}
	
	 
	/*
	 * To Get all AutoDebitAgainst with pagination.
	 */	  	
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI) 
	public  ResponseObj findAllAutoDebitAgainst(@RequestBody PaginationModel pagination)
	{
		return 	this.autoDbtAgnstService.getAllAutoDebitAgainst(pagination);
	}
	
	/*
	 * To get AutoDebitAgainst based on id.
	 */	
	@GetMapping(value= Constant.PATH_VARIABLE_ID)
	public  ResponseObj findAutoDebitAgainstByAutoDebitAgainstId(@PathVariable("autoDebitAgainstId") Long autoDebitAgainstId)
	{
		return 	this.autoDbtAgnstService.getById(autoDebitAgainstId);
	}
	
	/*
	 * To get AutoDebitAgainst based on name.
	 */	  
	@GetMapping(value= Constant.PATH_VARIABLE_NAME)
	public  ResponseObj findAutoDebitAgainstByAutoDebitAgainstName(@PathVariable("autoDebitAgainstName") String autoDebitAgainstName)
	{
		return 	this.autoDbtAgnstService.getByName(autoDebitAgainstName);
	}
	
	/*
	 * To create a new AutoDebitAgainst .
	 */	  
	@PostMapping
	public ResponseObj createAutoDebitAgainst(@RequestDTO(AutoDebitAgainstCreationDTO.class) @Validated AutoDebitAgainst autoDebitAgainst)
	{
		return this.autoDbtAgnstService.create(autoDebitAgainst);
	}
	
	/*
	 * To update existing AutoDebitAgainst based on id.
	 */	  
	@PutMapping
	public ResponseObj updateAutoDebitAgainstById(@RequestDTO(AutoDebitAgainstUpdateDTO.class) @Validated AutoDebitAgainst autoDebitAgainst)
	{
		return this.autoDbtAgnstService.update(autoDebitAgainst);
	}
	
	/*
	 * To soft deleting AutoDebitAgainst based on id.
	 */	  
	@DeleteMapping(value = Constant.PATH_DELETE)
	public ResponseObj deleteAutoDebitAgainst(@PathVariable("id") Long id) {

		return this.autoDbtAgnstService.deleteAutoDebitAgainst(id);

	}
	
	
	

}

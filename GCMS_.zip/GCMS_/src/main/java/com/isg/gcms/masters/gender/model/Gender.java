package com.isg.gcms.masters.gender.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */




@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "GCMS_GENDER_MST")
public class Gender {
			
    @Id	 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GENDER_ID")
	private Long genderID;
    
   @Column(name = "GENDER_NAME")
   private  String  genderName;  
    
   
   @Column(name = "GENDER_CRT_DTE")
	private Date genderCreatedDate;
   
   @Column(name = "GENDER_CRT_BY")
	private String  genderCreatedBy; 
   
   @Column(name = "GENDER_MOD_DTE")
	private Date genderModifiedDate;
  
   @Column(name = "GENDER_MOD_BY")
	private String  genderModifiedBy;  
   
   @Column(name="GENDER_CERT")  
   private Integer genderCertified;


}



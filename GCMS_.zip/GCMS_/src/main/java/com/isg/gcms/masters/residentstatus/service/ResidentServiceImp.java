package com.isg.gcms.masters.residentstatus.service;
import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.relation.model.Relation;
import com.isg.gcms.masters.residentstatus.dao.ResidentDao;
import com.isg.gcms.masters.residentstatus.dao.ResidentTrailDao;
import com.isg.gcms.masters.residentstatus.dto.ResidentUpdateDTO;
import com.isg.gcms.masters.residentstatus.model.Resident;
import com.isg.gcms.masters.residentstatus.model.ResidentTrail;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;



@Service
public class ResidentServiceImp implements ResidentService {

	
	/* To inject an instance of ResidentDao */
	@Autowired
	private ResidentDao residentDao;
	
	
	/* To inject an instance of ResidenttrailDao  */
	@Autowired
	private ResidentTrailDao residentTrailDao;
	
	
	
	
	
	/* To inject an instance of CertificationDao */
	@Autowired
	private CertificationDao certificationDao;
	
	
	/* To inject an instance of ResponseObj */
	@Autowired
	private ResponseObj res;
	
	
	
	/* To get all values of Residential status based on pagination */ 
	@Override
	public ResponseObj getAllResident(PaginationModel pagination) {
		
		Page<Resident> resident=this.residentDao.findAll(pagination.pageRequest());
		List<Resident> residentList = resident.getContent();
		if(!residentList.isEmpty())
		{
			res.addData(Constant.LIST_ALL,residentList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
	
		return res;
	    }
	
	/*
	 * To get all Residential status values.
	 */
	@Override
	public ResponseObj getAll() {
		List<Resident> recidentList = this.residentDao.findAll();
		if(!recidentList.isEmpty())
		{
		res.addData(Constant.LIST_ALL, recidentList );	 
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get values based on status (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.residentDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.residentDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}

	/*
	 * To get Residential status based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {

		Optional<Resident>resident = this.residentDao.findById(id);

		if (resident.isPresent() &&resident.get().getResidentCertified() == 0)
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(resident.get(), ResidentUpdateDTO.class));
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;

	    }

	/*
	 * To get Residential status based on name.
	 */
	@Override
	public ResponseObj getByName(String residentName) {
		
		Optional<Resident> resident = findbyresidentName(residentName);
		if(resident.isPresent() && resident.get().getResidentCertified()==0) {
			res.addData(Constant.BY_NAME,
					ResponseDTO.accepted().convertTo(resident.get(),ResidentUpdateDTO.class));
			
		} else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	    }
			
	
	/*
	 * To get Residential status based on name and to use in other methods.
	 */
	private Optional<Resident> findbyresidentName(String residentName)
	{
		return this.residentDao.findByresidentName(residentName);
	
	}
	
	/*
	 * To get Residential status based on id and to use in other methods.
	 */
	private Optional<Resident> findByResidentId(Long residentId) {
		
		return this.residentDao.findById(residentId);
	}
	
	/*
	 * To create new Residential status based.
	 */
	@Override
	public ResponseObj createResident(@RequestBody Resident resident) {
		resident.setResidentCertified(1);
		resident.setResidentCreatedBy("Pooja");
		resident.setBankId(1L);  // JWT OR SESSION
		resident.setEntityId(1L); // JWT OR SESSION
		Resident resi=	this.residentDao.save(resident);
		res.addData(Constant.VALUE_CREATED,resi);
		saveResidentTrail(resident,Constant.VALUE_CREATED,"NEW");
		return res;

	   }

	/* 
	 * To save values in ResidentTrail table
	 */
	private void saveResidentTrail(Resident resident, String remarks, String action) {
		
			ResidentTrail residentTrail = (ResidentTrail) ResponseDTO.accepted().convertToEntity(resident, ResidentTrail.class);
			residentTrail.setResident(resident);
			residentTrail.setResidentCreatedBy("Pooja");     /* To do replace maker with JWT  */
			residentTrail.setResidentAction(action);
			residentTrail.setResidentRemark(remarks);
			residentTrail.setResidentCertified(1);        /* Pending under Certification */
			this.residentTrailDao.save(residentTrail);
			saveCertification(residentTrail);	
	    }
	
	/* 
	 * To save values in certification table
	 */
	private void saveCertification(ResidentTrail residentTrail)
	  {
		/* To inject an instance of Certification*/
		
	 Certification cert=new Certification();

		cert.setAction(residentTrail.getResidentAction());
		cert.setTrailId(residentTrail.getResidentTrailId());
		cert.setTableName(MasterType.RESIDENT.toString());
		cert.setCertified(1);
		cert.setMaker("Pooja");         /* To do replace maker with JWT  */
		cert.setMakerTime(residentTrail.getResidentCreatedDate());
		this.certificationDao.save(cert);
	     }
		 
	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateResident(Resident resident) {

		Optional<Resident> residentold= findByResidentId(resident.getResidentId());
		
		if (residentold.isPresent() && residentold.get().getResidentCertified() == 0) {
			Resident residentEx =residentold.get();
			residentEx.setResidentCertified(1);
			residentEx.setResidentModifiedDate(new Date());
			this.residentDao.save(residentEx);
			saveResidentTrail(resident, Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, resident);
		  } else
			res.setActionError(Constant.ERROR_MSG);
		    return res;

	       }

	/*
	 * To soft delete based on id.
	 */ 
	@Override
	public ResponseObj deleteById(Long id) 
	{

		Optional<Resident> resident = this.residentDao.findById(id);
		
		if (resident.isPresent() && resident.get().getResidentCertified() == 0) 
			{
				Resident residentEx = resident.get();
				residentEx.setResidentCertified(1);
				this.residentDao.save(residentEx);
				saveResidentTrail(residentEx,Constant.VALUE_DELETED,"DELETE");
				res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
			}
			   
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
			  
		return res;

	} 
	
}
package com.isg.gcms.masters.employee.dto;

import java.util.Date;


import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class EmpUpdateDTO {
	
	@Id
	@NotNull
	private Long employeeId;

	private String employeeCode;
	
	private String employeeSsoId;
	
	private String employeeEcn;
	
	private Long employeeSalutationId;
		
	private String employeeFirstName;
	
	private String employeeMiddleName;
	
	private String employeeLastName;
	
	
	private Long employeeMobileNumber;
	
	private String employeeEmail;
	
	private String employeeDesignationId;
	
	private String employeeDepartmentId; 
	
	@JsonIgnore
	private final Date employeeModifiedDate = new Date();
}

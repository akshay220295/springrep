package com.isg.gcms.masters.education.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_EDUCATION_MST")
public class Education {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="EDUCTN_ID")
	private Long educationId; 
	
	@Column(name="EDUCTN_NAME")
    private String educationName;
	
	@Column(name="EDUCTN_CRT_DTE")
    private Date educationCreatedDate;
	
	@Column(name="EDUCTN_CRT_BY")
    private String educationCreatedBy;
	
	@Column(name="EDUCTN_MOD_DTE")
    private Date educationModifiedDate;
	
	@Column(name="EDUCTN_MOD_BY")
    private String educationModifiedBy;
	
	@Column(name="EDUCTN_CERT")
    private Integer educationCertified;

}

package com.isg.gcms.masters.accounttype.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.accounttype.dao.AccountTypeDao;
import com.isg.gcms.masters.accounttype.dao.AccountTypeTrailDao;
import com.isg.gcms.masters.accounttype.dto.AccTypUpdateDTO;
import com.isg.gcms.masters.accounttype.model.AccountType;
import com.isg.gcms.masters.accounttype.model.AccountTypeTrail;



@Service
public class AccountTypeSserviceImp implements AccountTypeService
{
	/*
	 * To inject an instance of AccountTypeDao
	 */
	@Autowired
	private AccountTypeDao accTypDao;
	
	/*
	 * To inject an instance of AccountTypeTrailDao
	 */
	@Autowired
	private AccountTypeTrailDao accTypeTrlDao;
	
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
		
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllAccType(PaginationModel pagination) {
		Page<AccountType> accPage = this.accTypDao.findAllByPagination(pagination.pageRequest());
		List<AccountType> accList = accPage.getContent();
		if(!accList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, accList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all AccountType values.
	 */
	@Override
	public ResponseObj getAllAccType() {
		List<AccountType> accList = this.accTypDao.findAll();
		if(!accList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, accList );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
	
		return res;
	}
	

	/*
	 * To find AccountType based on id and to use in other methods.
	 */
	@Override
	public Optional<AccountType> findById(Long id) {
		return this.accTypDao.findById(id);
	}
	

	/*
	 * To get AccountType based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<AccountType> acctyp = this.findById(id);
		if(acctyp.isPresent() && acctyp.get().getAccountTypeCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(acctyp.get(), AccTypUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}
	 
	/*
	 * To find AccountType based on name
	 */
	public Optional<AccountType> findByName(String name) {
		return accTypDao.findByaccountTypeNameEqualsIgnoreCase(name);
	}
	 
	/*
	 * To get AccountType based on name.
	 */
	@Override
	public ResponseObj getByName(String name) {
		Optional<AccountType> accTyp = this.findByName(name);
		if (accTyp.isPresent() && accTyp.get().getAccountTypeCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(accTyp.get(), AccTypUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
		
	}

	/*
	 * To create new AccountType value.
	 */
	@Override
	public ResponseObj create(AccountType accType) {
		accType.setAccountTypeCertified(1);
		accType.setAccountTypeCreatedBy("adi");  //JWT orSession
		
		AccountType accounttyp = this.accTypDao.save(accType);
		saveAccTypeTrail(accounttyp,Constant.VALUE_CREATED,"NEW" );
		res.addData(Constant.VALUE_CREATED, accounttyp);
		return res;
	}
	
	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		System.out.println( "in serve +++++++++++++++++++++++++++++++++");
		Optional<AccountType> acctyp = this.findById(id);
		if(acctyp.isPresent() && acctyp.get().getAccountTypeCertified() == 0)
		{
			AccountType accTypEx = acctyp.get();
			accTypEx.setAccountTypeCertified(1);
			saveAccTypeTrail(accTypEx,Constant.VALUE_DELETED,"DELETE" );
			this.accTypDao.save(accTypEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError("ID NOT FOUND");
		}
		return res;
	}
	

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateAccType(AccountType accType) {
		Optional<AccountType> accTypOld = this.findById(accType.getAccountTypeId());
		if(accTypOld.isPresent() && accTypOld.get().getAccountTypeCertified() == 0)
		{
			AccountType accTypEx = accTypOld.get();
			accTypEx.setAccountTypeCertified(1);
			accTypEx.setAccountTypeModifiedBy("adi"); // JWT or Session
			accTypEx.setAccountTypeModifiedDate(new Date());
			this.accTypDao.save(accTypEx);
			saveAccTypeTrail(accType,Constant.VALUE_UPDATED,"MODIFY" );
			res.addData(Constant.VALUE_UPDATED, accType);
		}
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.accTypDao.getActiveAccType(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.accTypDao.getInactiveAccType(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in AccountType Trail table
	 */
	public void saveAccTypeTrail(AccountType accType, String remark, String action) {
		AccountTypeTrail accTypTrail = (AccountTypeTrail) ResponseDTO.accepted().convertToEntity(accType,
				AccountTypeTrail.class);
		accTypTrail.setAccountType(accType);
		accTypTrail.setAccountTypeCreatedBy("adi"); //JWT OR Session
		accTypTrail.setAccountTypeAction(action);
		accTypTrail.setAccountTypeCertified(1);
		accTypTrail.setAccountTypeRemark(remark);

		this.accTypeTrlDao.save(accTypTrail);
		saveCertification(accTypTrail);
	}
	
	/*
	 * To save values in Certification table
	 */	 
	public void saveCertification(AccountTypeTrail accTypTrail) 
	{
		/*
		 * To inject an instance of Certification
		 */
			Certification cert= new Certification();
			
			cert.setAction(accTypTrail.getAccountTypeAction());
			cert.setTrailId(accTypTrail.getAccountTypeTrailId());
			cert.setTableName(MasterType.ACCOUNTTYPE.toString());
			cert.setCertified(1);
			cert.setMaker("aditya"); // To do replace maker with JWT
			cert.setMakerTime(accTypTrail.getAccountTypeCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.gender.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;


/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */



@Data
@Entity
@Table(name = "GCMS_GENDER_MST_TRAIL")
public class GenderTrail {
	
	
	@Id	 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "GENDER_TRAIL_ID")
	private Long genderTrailId;
	
	@ManyToOne
	@JoinColumn(name = "GENDER_ID", referencedColumnName = "GENDER_ID")
	private Gender gender;
    
    @Column(name = "GENDER_NAME")
    private  String  genderName;  
   
    @Column(name = "GENDER_CRT_DTE")
	private Date genderCreatedDate;
	
    @Column(name = "GENDER_CRT_BY")
    private String  genderCreatedBy;
  
    @Column(name = "GENDER_MOD_DTE")
  	private Date  genderModifiedDate;
   
    @Column(name = "GENDER_MOD_BY")
	private String  genderModifiedBy;
   
    @Column(name="GENDER_CERT")  
    private Integer genderCertified;
   
    @Column(name="GENDER_CERT_MODE") 
    private Integer genderCertMode;    

    @Column(name="GENDER_ACT") 
    private String genderAction;    
   
    @Column(name="GENDER_RMRK") 
    private String  genderRemark;    
   
   
  }



package com.isg.gcms.masters.dsa.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_DSA_MST")
public class Dsa 
{

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="DSA_ID")
	private Long dsaId; 
	
	@Column(name="DSA_NAME")
    private String dsaName;
	
	@Column(name="DSA_CATEGORY")
    private String dsaCategory;
	
	@Column(name="DSA_ADD1")
    private String  dsaAdd1; 
	
	@Column(name="DSA_ADD2")
    private String dsaAdd2;
	
	@Column(name="DSA_ADD3")
    private String dsaAdd3;
	
	@Column(name="DSA_CITY")
    private String dsaCity;
	
	@Column(name="DSA_STATE")
    private String  dsaState;
	
	@Column(name="DSA_COUNTRY")
    private String dsaCountry;
	
	@Column(name="DSA_PIN")
    private String dsaPin;
	
	@Column(name="DSA_WEBSITE")
    private String dsaWebsite;
	
	@Column(name="DSA_AUTH_PERSN_NAME")
    private String  dsaAuthPersonName;
	
	@Column(name="DSA_AUTH_PERSN_MOBNO")
    private Long dsaAuthPersonMobNo;
	
	@Column(name="DSA_AUTH_PERSN_EMAIL")
    private String dsaAuthPersonEmail;
	
	@Column(name="DSA_TAX_ID")
    private Long dsaTaxId;
	
	@Column(name="DSA_REGISTRNO")
    private Long dsaRegistrationNo;
	
	@Column(name="DSA_CRT_DTE")
    private Date  dsaCreatedDate;
	
	@Column(name="DSA_CRT_BY")
    private String dsaCreatedBy;
	
	@Column(name="DSA_MOD_DTE")
    private Date dsaModifiedDate;
	
	@Column(name="DSA_MOD_BY")
    private String  dsaModifiedBy;
	
	@Column(name="DSA_CERT")
    private Integer dsaCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
}

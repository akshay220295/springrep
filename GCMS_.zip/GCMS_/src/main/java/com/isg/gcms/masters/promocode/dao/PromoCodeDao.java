package com.isg.gcms.masters.promocode.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.isg.gcms.masters.promocode.model.PromoCode;



public interface PromoCodeDao extends JpaRepository<PromoCode,Long> 

{

	public Optional<PromoCode> findByPrmocdeNameEqualsIgnoreCase(String name);
	
	@Query ("SELECT M FROM PromoCode M WHERE M.prmocdeCertified!=2")
	public Page<PromoCode> findAllByPagination(Pageable pageable);

	@Query ("SELECT M FROM PromoCode M WHERE M.prmocdeCertified=0 AND M.prmocdeCertified!=2")
	public Page<PromoCode> getActivePrmocde(Pageable pageable);
	
	@Query ("SELECT M FROM PromoCode M WHERE M.prmocdeCertified=1 AND M.prmocdeCertified!=2")
	public Page<PromoCode> getInactPrmocde(Pageable pageable);

	public List<PromoCode> findByPrmocdeCertified(int id);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

package com.isg.gcms.masters.relation.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.relation.model.Relation;
import com.isg.gcms.masters.relation.model.RelationTrail;

@Repository
public interface RelationTrailDao extends JpaRepository<RelationTrail, Long>

{

	public List<RelationTrail> findByRelation(Relation relation);
	
}

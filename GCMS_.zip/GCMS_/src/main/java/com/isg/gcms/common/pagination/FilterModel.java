package com.isg.gcms.common.pagination;

public class FilterModel {

	private String prop;
	private String value;

	public FilterModel() {
		super();
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getProp() {
		return prop;
	}

	public void setProp(String prop) {
		this.prop = prop;
	}

	@Override
	public String toString() {
		return "{FilterModel: {prop:" + prop + ", value:" + value + "}}";
	}

}

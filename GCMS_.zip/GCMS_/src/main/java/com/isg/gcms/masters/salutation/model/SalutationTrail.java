package com.isg.gcms.masters.salutation.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Data
@Entity
@Table(name = "GCMS_SALUTATION_MST_TRAIL")
public class SalutationTrail {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="SALTN_TRAIL_ID")
    private Long salutationTrailId;
	
	@ManyToOne
	@JoinColumn(name = "SALTN_ID", referencedColumnName = "SALTN_ID")
	private Salutation salutation;
	
	@Column(name="SALTN_NAME")
    private String salutationName;
	
	@Column(name="SALTN_CRT_DTE")
    private Date salutationCreatedDate;
	
	@Column(name="SALTN_CRT_BY")
    private String salutationCreateddBy;
	
	@Column(name="SALTN_MOD_DTE")
    private Date salutationModifiedDate;
	
	@Column(name="SALTN_MOD_BY")
    private String salutationModifiedBy;
	
	@Column(name="SALTN_CERT")
    private Integer salutationCertified;
	
	@Column(name="SALTN_CERT_MODE")
    private Integer salutationCertifiedMode;
	
	@Column(name="SALTN_ACT")
    private String salutationAction;
	
	@Column(name="SALTN_RMRK")
    private String salutationRemark;  
    

}




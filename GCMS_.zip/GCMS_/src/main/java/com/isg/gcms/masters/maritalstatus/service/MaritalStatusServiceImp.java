package com.isg.gcms.masters.maritalstatus.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.employee.model.EmployeeTrail;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusDao;
import com.isg.gcms.masters.maritalstatus.dao.MaritalStatusTrailDao;
import com.isg.gcms.masters.maritalstatus.dto.MartlStsUpdateDTO;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatusTrail;
import com.isg.gcms.masters.occupation.service.OccupationService;
import com.isg.gcms.masters.promocode.model.PromoCode;

@Service
public class MaritalStatusServiceImp implements MaritalStatusService {
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;

	/*
	 * To inject an instance of MaritalStatusDao
	 */
	@Autowired
	private MaritalStatusDao mrtlStsDao;

	/*
	 * To inject an instance of MaritalStatusTrailDao
	 */
	@Autowired
	private MaritalStatusTrailDao mrtlStsTrlDao;
	
	
		
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;


	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllMartlSts(PaginationModel pagination) {

		Page<MaritalStatus> maritalStatus=this.mrtlStsDao.findAll(pagination.pageRequest());
		List<MaritalStatus> maritalList = maritalStatus.getContent();
		if(!maritalList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, maritalList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find MaritalStatus based on id and to use in other methods.
	 */
	@Override
	public Optional<MaritalStatus> findById(Long id) {
		return this.mrtlStsDao.findById(id);

	}

	/*
	 * To get MaritalStatus based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<MaritalStatus> martlsts = this.findById(id);

		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(martlsts.get(), MartlStsUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find MaritalStatus based on name
	 */
	public Optional<MaritalStatus> getByName(String username) {
		return mrtlStsDao.findByMaritalStatusNameEqualsIgnoreCase(username);
	}

	/*
	 * To get MaritalStatus based on name.
	 */
	@Override
	public ResponseObj findByName(String username) {
		Optional<MaritalStatus> martlsts = this.getByName(username);
		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(martlsts.get(), MartlStsUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new MaritalStatus value.
	 */
	@Override
	public ResponseObj create(@RequestBody MaritalStatus maritalstatus) {
		maritalstatus.setMaritalStatusCertified(1);
		maritalstatus.setMaritalStatusCreatedby("Aditya"); // To Do -- will be replaced by JWT token or any other
															// session objects.
		MaritalStatus martlsts = this.mrtlStsDao.save(maritalstatus);
		saveMartlstsTrail(martlsts,Constant.VALUE_CREATED, "NEW");
		res.addData(Constant.VALUE_CREATED, martlsts);
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateMartlSts(MaritalStatus maritalstatus) {
		Optional<MaritalStatus> martlstsOld = findById(maritalstatus.getMaritalStatusId());
		
		if (martlstsOld.isPresent() && martlstsOld.get().getMaritalStatusCertified() == 0) {
			MaritalStatus MaritalStatusEx = martlstsOld.get();
			MaritalStatusEx.setMaritalStatusCertified(1);
			this.mrtlStsDao.save(MaritalStatusEx);
			saveMartlstsTrail(maritalstatus,Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, maritalstatus);
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<MaritalStatus> martlsts = this.findById(id);
		if (martlsts.isPresent() && martlsts.get().getMaritalStatusCertified() == 0) {
			MaritalStatus martlstsEx = martlsts.get();
			martlstsEx.setMaritalStatusCertified(1);
			saveMartlstsTrail(martlstsEx, Constant.VALUE_DELETED, "DELETED");
			this.mrtlStsDao.save(martlstsEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To save values in MaritalStatus Trail table
	 */
	public void saveMartlstsTrail(MaritalStatus maritalstatus, String remark, String action) {
		MaritalStatusTrail martlstsTrail = (MaritalStatusTrail) ResponseDTO.accepted().convertToEntity(maritalstatus,
				MaritalStatusTrail.class);
		martlstsTrail.setMaritalStatus(maritalstatus);
		martlstsTrail.setMaritalStatusCreatedBy("adi");
		martlstsTrail.setMaritalStatusAction(action);
		martlstsTrail.setMaritalStatusCertified(1);
		martlstsTrail.setMaritalStatusRemark(remark);

		this.mrtlStsTrlDao.save(martlstsTrail);
		
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(MaritalStatusTrail martlstsTrail) 
	{
		
		/*
		 * To inject an instance of Certification
		 */
		
			Certification cert=new Certification();
	 
			cert.setAction(martlstsTrail.getMaritalStatusAction());
			cert.setTrailId(martlstsTrail.getMaritalStatusTrailId());
			cert.setTableName(MasterType.MARITALSTATUS.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			cert.setMakerTime(martlstsTrail.getMaritalStatusCreatedDate());
			this.certificationDao.save(cert);
			
	}
	
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.mrtlStsDao.getActiveMaritalSts(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.mrtlStsDao.getInactMaritalSts(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	@Override
	public ResponseObj getAllMartlSts() {
		List<MaritalStatus> maritalStatus=this.mrtlStsDao.findAll();
		if(!maritalStatus.isEmpty())
		{
			res.addData(Constant.LIST_ALL, maritalStatus);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	
	

}
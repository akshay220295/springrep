package com.isg.gcms.masters.channel.service;

import org.springframework.stereotype.Service;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.channel.model.Channel;


@Service
public interface ChannelService {
	
	public ResponseObj getAllChannel(PaginationModel pagination);
	
	public ResponseObj getAllChannel();
	
	public ResponseObj getStatus(PaginationModel pagination, String status);
	
	public ResponseObj getById(Long id);
	
	public ResponseObj getByName(String channelName);
	
	public ResponseObj createChannel(Channel channel);

	public ResponseObj updateChannel(Channel channel);  
	
	public ResponseObj deleteById(Long id);
	
	


	
	

	

}

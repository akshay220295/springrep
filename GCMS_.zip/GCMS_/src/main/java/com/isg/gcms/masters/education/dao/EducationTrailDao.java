package com.isg.gcms.masters.education.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.model.EducationTrail;

@Repository
public interface EducationTrailDao extends JpaRepository< EducationTrail, Long> 
{

	public List<EducationTrail> findByEducation(Education education);
	
}

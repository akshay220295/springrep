package com.isg.gcms.masters.salutation.controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.salutation.dto.SalutationCreationDTO;
import com.isg.gcms.masters.salutation.dto.SalutationUpdateDTO;
import com.isg.gcms.masters.salutation.model.Salutation;
import com.isg.gcms.masters.salutation.service.SalutationService;
@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_SALUTATION)
public class SalutationController 
{
	
	/*To inject an instance of SalutationService
	*/
	@Autowired
	private SalutationService saltnservice;
	
	
	/*
	 * To get Salutation based on status (active/inactive) .
	 */ 
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.saltnservice.getStatus(pagination, status) ;
	}
	
	/*
	 * Get all Salutation without pagination.
	 */
	@GetMapping(value=Constant.PATH_GET_ALL)
	public ResponseObj findAllSalutation()
	{
		return this.saltnservice.getAllSaltn();
	}
	
	/*
	 * Get all Salutation with pagination.
	 */
	@PostMapping(value = Constant.PATH_GET_ALL_PAGI)
	public  ResponseObj findAllSalutation(@RequestBody PaginationModel pagination)
	{
		System.out.println(pagination);
		return 	this.saltnservice.getAllSaltn(pagination);
	}
	
	/*
	 * To get Salutation based on id.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public  ResponseObj findSalutationBySaltnId(@PathVariable("saltnId") Long saltnId)
	{
		return 	this.saltnservice.getById(saltnId);
	}
	
	/*
	 * To get Salutation based on name.
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public  ResponseObj findSalutationBySaltnName(@PathVariable("saltnName") String saltnName)
	{
		return 	this.saltnservice.getByName(saltnName);
	}
	
	/*
	 * To create a new Salutation .
	 */
	@PostMapping
	public ResponseObj createSalutation(@RequestDTO(SalutationCreationDTO.class) @Validated Salutation salutation)
	{
		return this.saltnservice.create(salutation);
	}
	
	/*
	 * To update existing Salutation based on id.
	 */
	@PutMapping
	public ResponseObj updateSalutationById(@RequestDTO(SalutationUpdateDTO.class) @Validated Salutation salutation)
	{
		return this.saltnservice.update(salutation);
	}
	
	/*
	 * To soft deleting Salutation based on id.
	 */
	@DeleteMapping(value = Constant.PATH_DELETE)
	public ResponseObj deleteSalutation(@PathVariable("id") Long id) {

		return this.saltnservice.deleteSalutation(id);

	}


}

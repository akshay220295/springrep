package com.isg.gcms.masters.channel.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.channel.dto.ChannelCreationDTO;
import com.isg.gcms.masters.channel.dto.ChannelUpdateDTO;
import com.isg.gcms.masters.channel.model.Channel;
import com.isg.gcms.masters.channel.service.ChannelService;

@RestController
@CrossOrigin("*")
@RequestMapping(value =Constant.PATH_CHANNEL)
public class ChannelController {
		
	@Autowired
	private ChannelService channelService;
	
	
	/*
	 * To get all records with pagination
	 */
	@PostMapping(value =Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAllChannel(@RequestBody PaginationModel pagination) {
		return this.channelService.getAllChannel(pagination);

	}
	
	/*
	 * To get all records
	 */
	@GetMapping(value =Constant.PATH_GET_ALL)
	public ResponseObj getAllChnl()
	{

		return this.channelService.getAllChannel();

	}
	
	/*
	 * To get status based on(active/deactive)
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.channelService.getStatus(pagination, status) ;
	}
	
	
	/*
	 * To get records based on id
	 */
	@GetMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getById(@PathVariable("id") Long id) {

		return this.channelService.getById(id);
		
	}

	/*
	 * To get records based on name
	 */
	@GetMapping(value =Constant.PATH_VARIABLE_NAME)
	public ResponseObj getChannelByName(@PathVariable("name") String channelName) {

		return this.channelService.getByName(channelName);

		}
	
	
	/*
	 * To create a new channel .
	 */
	@PostMapping
	public ResponseObj createChannel(@RequestDTO(ChannelCreationDTO.class) @Validated Channel channel) {
		
		return this.channelService.createChannel(channel);

	}
		

	/*
	 * To update existing channel.
	 */
	@PutMapping
	public ResponseObj updateChannel(@RequestDTO(ChannelUpdateDTO.class) @Validated Channel channel) {
		return this. channelService.updateChannel(channel);

	}
		

	/*
	 * To soft delete a channel based on channel id
	 */
	@DeleteMapping(value=Constant.PATH_DELETE)
	public ResponseObj deleteChannel(@PathVariable("id") Long id) {

		return this.channelService.deleteById(id);
	}
	
}

package com.isg.gcms.masters.exception.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;

import com.isg.gcms.masters.exception.dao.ExceptionDao;
import com.isg.gcms.masters.exception.dao.ExceptionTrailDao;
import com.isg.gcms.masters.exception.dto.ExcptnUpdateDTO;
import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.exception.model.ExceptionMstTrail;

@Service
public class ExceptionServiceImp implements ExceptionMstService{
	/*
	 * To inject instance of ExceptionDao class
	 */
	@Autowired
	private ExceptionDao excptnDao;
	
	/*
	 * To inject instance of ExcepTrailDao class
	 */
	@Autowired
	private ExceptionTrailDao excptnTrlDao; 
	
	
				
	/*
	 * To inject instance of certificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To inject instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllExcptn(PaginationModel pagination) {
		Page<ExceptionMst> exceptionPage = this.excptnDao.findAllByPagination(pagination.pageRequest());
		List<ExceptionMst> exceptioList = exceptionPage.getContent();
		if(!exceptioList.isEmpty()) {
			res.addData(Constant.LIST_ALL, exceptioList);
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To find Decision based on id and to use in other methods.
	 */
	@Override
	public Optional<ExceptionMst> findExcpById(Long id) {
		
		return  this.excptnDao.findById(id);
		
		
	}


	/*
	 * To get Decision based on id.
	 */
	public ResponseObj getById(Long id)
	{
		Optional<ExceptionMst> exception = this.findExcpById(id);
		if(exception.isPresent() && exception.get().getExceptionMstCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(exception.get(), ExcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	


	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<ExceptionMst> exception = findExcpById(id);
		if(exception.isPresent() && exception.get().getExceptionMstCertified() == 0)
		{
			ExceptionMst exceptionEx = exception.get();
			exceptionEx.setExceptionMstCertified(1);
			saveExcptnTrail(exceptionEx , Constant.VALUE_DELETED , "DELETE");
			this.excptnDao.save(exceptionEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get Decision based on name.
	 */
	@Override
	public ResponseObj findByName(String username) {
		Optional<ExceptionMst> exception = this.findByExcepName(username);
		if(exception.isPresent() && exception.get().getExceptionMstCertified()==0)
		{
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(exception.get(), ExcptnUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To find Decision based on name
	 */
	private Optional<ExceptionMst> findByExcepName(String username) {
		return this.excptnDao.findByexceptionMstNameEqualsIgnoreCase(username);
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateExcptn(ExceptionMst exception) {
		Optional<ExceptionMst> exceptionOld = findExcpById(exception.getExceptionMstId());
		if(exceptionOld.isPresent() && exceptionOld.get().getExceptionMstCertified()==0)
		{
			
			ExceptionMst excptnExisting = exceptionOld.get();
			excptnExisting.setExceptionMstCertified(1);
			excptnExisting.setExceptionMstModifiedDate(new Date());
			excptnExisting.setExceptionMstModifiedBy("Supriya");//JWT Token
			this.excptnDao.save(excptnExisting);
			
			saveExcptnTrail(exception , Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, exception);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	

	
	/*
	 * To create new Decision value.
	 */
	@Override
	public ResponseObj create(ExceptionMst exception) {
		exception.setExceptionMstCertified(1);
		exception.setBankId(1L);  // JWT OR SESSION
		exception.setEntityId(1L); // JWT OR SESSION
		ExceptionMst excp=this.excptnDao.save(exception);
		res.addData(Constant.VALUE_CREATED, excp );
		saveExcptnTrail(exception , Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.excptnDao.getActiveExcptn(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.excptnDao.getInactExcptn(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in Decision Trail table
	 */
	private void saveExcptnTrail(ExceptionMst exception, String remark, String action) {
		ExceptionMstTrail excptnTrail =  (ExceptionMstTrail) ResponseDTO.accepted().convertToEntity(exception, ExceptionMstTrail.class);
		excptnTrail.setExceptionMst(exception);
		excptnTrail.setExceptionMstCreatedBy("adi");   //JWT
		excptnTrail.setExceptionMstAction(action);  
		excptnTrail.setExceptionMstCertified(1);
		excptnTrail.setExceptionMstRemark(remark);
		
		this.excptnTrlDao.save(excptnTrail);
		saveCertification(excptnTrail);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(ExceptionMstTrail excptnTrail) 
	{
		
		/*
		 * To inject instance of certification
		 */

		Certification cert=new Certification();
		
			cert.setAction(excptnTrail.getExceptionMstAction());
			cert.setTrailId(excptnTrail.getExceptionMstTrailId());
			cert.setTableName(MasterType.EXCEPTION.toString());
			cert.setCertified(1);
			cert.setMaker("Supriya"); // To do replace maker with JWT
			//cert.setMakerTime(autoDebitAgainstTrail.getAutodbtAgnstCrtDte());
			this.certificationDao.save(cert);
			
	}

	/*
	 * To get all Decision values.
	 */
	@Override
	public ResponseObj getAllExcptn() {
		List<ExceptionMst> exceptionList= this.excptnDao.findAll();
		if(!exceptionList.isEmpty()) {
			res.addData(Constant.LIST_ALL, exceptionList);
			
		}
		else {
			res.setActionError(Constant.ERROR_MSG);
		}
		
		
		return res;
	}

	
	
}

package com.isg.gcms.masters.accounttype.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.accounttype.model.AccountType;


public interface AccountTypeService 
{
public ResponseObj getAllAccType(PaginationModel pagination);
	
	public Optional<AccountType> findById(Long id);

	public ResponseObj getById(Long id);

	public ResponseObj getByName(String name);
	
	public ResponseObj create(AccountType accType);

	public ResponseObj deleteById(Long id);

	public ResponseObj updateAccType(AccountType accType);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllAccType();

}

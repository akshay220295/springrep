package com.isg.gcms.masters.employee.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.employee.model.Employee;
import com.isg.gcms.masters.employee.model.EmployeeTrail;

@Repository
public interface EmployeeTrailDao extends JpaRepository<EmployeeTrail,Long>{
	
	public List<EmployeeTrail> findByEmployee(Employee emp);

}

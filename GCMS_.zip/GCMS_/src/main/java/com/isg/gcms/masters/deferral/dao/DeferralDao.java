package com.isg.gcms.masters.deferral.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.deferral.model.Deferral;

@Repository
public interface DeferralDao extends JpaRepository<Deferral, Long> {
	
	public Optional<Deferral> findBydeferralNameEqualsIgnoreCase(String username);
	
	@Query("SELECT M FROM Deferral M WHERE M.deferralCertified != 2 ")
	public Page<Deferral> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Deferral M WHERE M.deferralCertified=0 AND M.deferralCertified!=2")
	public Page<Deferral> getActiveDefrl(Pageable pageable);
	
	@Query ("SELECT M FROM Deferral M WHERE M.deferralCertified=1 AND M.deferralCertified!=2")
	public Page<Deferral> getInactDefrl(Pageable pageable);

	public List<Deferral> findByDeferralCertified(int id);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}
	
	


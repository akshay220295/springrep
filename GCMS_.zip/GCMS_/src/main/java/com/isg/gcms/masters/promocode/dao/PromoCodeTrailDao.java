package com.isg.gcms.masters.promocode.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.isg.gcms.masters.promocode.model.PromoCode;
import com.isg.gcms.masters.promocode.model.PromoCodeTrail;

public interface PromoCodeTrailDao extends JpaRepository<PromoCodeTrail,Long> 
{

	public List<PromoCodeTrail> findByPromoCode(PromoCode promoCode);
	
}

package com.isg.gcms.masters.exception.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;


import com.isg.gcms.masters.exception.model.ExceptionMst;
import com.isg.gcms.masters.exception.model.ExceptionMstTrail;

public interface ExceptionTrailDao extends JpaRepository<ExceptionMstTrail, Long>{

	public List<ExceptionMstTrail> findByExceptionMst(ExceptionMst exceptionMst);
	
	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

package com.isg.gcms.masters.address.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.address.dto.AddressCreationDTO;
import com.isg.gcms.masters.address.dto.AddressUpdateDTO;
import com.isg.gcms.masters.address.model.Address;
import com.isg.gcms.masters.address.service.AddressService;


@CrossOrigin("*")
@RestController
@RequestMapping(value = Constant.PATH_ADDRESS)
public class AddressController {

	final Logger logger = LogManager.getLogger(AddressController.class);

	@Autowired
	public AddressService addressService;

	@Autowired
	public ResponseObj res;

	/* To get list of all the Address . */
	@GetMapping
	public ResponseObj getAllAddress(@RequestBody PaginationModel paginationModel) {

		return this.addressService.getAllAddress(paginationModel);

	}

	/* To get the detail of Address based on address Id. */
	@GetMapping(value = Constant.PATH_VARIABLE_ID)
	public ResponseObj getAddress(@PathVariable("id") Long addressId) {
		return this.addressService.getAddressById(addressId);

	}

	/* To create a new Address */
	@PostMapping
	public ResponseObj createAddress(@RequestDTO(AddressCreationDTO.class) @Validated Address address) {

		return this.addressService.saveAddress(address);
	}

	/* To update existing record of Address */
	@PutMapping
	public ResponseObj updateAddress(@RequestDTO(AddressUpdateDTO.class) @Validated Address address) {
		return this.addressService.updateAddress(address);
	}

	/* To soft delete Role based on Address Id */
	@DeleteMapping(value = Constant.PATH_DELETE + Constant.PATH_VARIABLE_ID)
	public ResponseObj deleteAddress(@PathVariable("id") Long addressId) {

		return this.addressService.deleteAddress(addressId);
	}

}

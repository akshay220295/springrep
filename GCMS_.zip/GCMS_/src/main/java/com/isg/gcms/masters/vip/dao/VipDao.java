package com.isg.gcms.masters.vip.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.vip.model.Vip;
@Repository
public interface VipDao extends JpaRepository<Vip,Long>{
	
	public Optional<Vip> findByVipNameEqualsIgnoreCase(String name);
	
	@Query ("SELECT M FROM Vip M WHERE M.vipCertified!=2")
	public Page<Vip> findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM Vip M WHERE M.vipCertified=0 AND M.vipCertified!=2")
	public Page<Vip> getActiveVip(Pageable pageable);
	
	@Query ("SELECT M FROM Vip M WHERE M.vipCertified=1 AND M.vipCertified!=2")
	public Page<Vip> getInactVip(Pageable pageable);

	public List<Vip> findByVipCertified(int id);

	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

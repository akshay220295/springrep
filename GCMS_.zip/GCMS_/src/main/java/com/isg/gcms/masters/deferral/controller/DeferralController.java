 package com.isg.gcms.masters.deferral.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.deferral.dto.DefrlCreationDto;
import com.isg.gcms.masters.deferral.dto.DefrlUpdateDto;
import com.isg.gcms.masters.deferral.model.Deferral;
import com.isg.gcms.masters.deferral.service.DeferralService;


@RestController
@RequestMapping(value =Constant.PATH_DEFERRAL)
@CrossOrigin("*")
public class DeferralController {
	@Autowired
	private DeferralService deferralService;
	
	/*
	 * Getting deferral data with pagination
	 */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAll(@RequestBody PaginationModel pagination) {
		return this.deferralService.getAllDefrl(pagination);
		
	}
	
	/*
	 * Getting deferral data without pagination
	 */
	@GetMapping(value =Constant.PATH_GET_ALL)
	public ResponseObj getAll() {
		return this.deferralService.getAllDefrl();
		
	}

	/*
	 * Getting deferral value based on Id
	 */
	@GetMapping( value =Constant.PATH_VARIABLE_ID)
	public ResponseObj getValue(@PathVariable("id") Long id)
	
	{
		
		return this.deferralService.getById(id);
	}
	 
	/*
	 * Getting deferral value based on name
	 */
	@GetMapping( value = Constant.PATH_VARIABLE_NAME)
	public ResponseObj getbyName(@PathVariable("username") String username)
	{
		return this.deferralService.findByName(username);
	}
	
	/*
	 * Creating new Deferral
	 */
	@PostMapping
	public ResponseObj create(@RequestDTO(DefrlCreationDto.class) @Validated Deferral deferral)
	{
		
		return this.deferralService.create(deferral) ;
	}

	/*
	 * Soft deleting deferral based on id
	 */
	@DeleteMapping (value = Constant.PATH_DELETE)
	public ResponseObj delById(@PathVariable("id") Long id)
	{
		return this.deferralService.deletebyId(id);
	}

	/*
	 * updating existing deferral
	 */
	@PutMapping 
	public ResponseObj updateDefrl(@RequestDTO(DefrlUpdateDto.class) @Validated Deferral deferral)
	{
		
		return this.deferralService.updateDefrl(deferral);
	}
	
	/*
	 * getting deferral status based on status
	 */
	@GetMapping("/status/{status}")
	public ResponseObj getByStatus(@RequestBody PaginationModel pagination , @PathVariable("status") String status)
	{
		System.out.println(pagination+ "controller @@@@@@@@@@@@");
		return this.deferralService.getStatus(status, pagination);
		
	}
}
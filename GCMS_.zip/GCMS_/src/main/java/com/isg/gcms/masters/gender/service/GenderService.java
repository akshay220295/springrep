package com.isg.gcms.masters.gender.service;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.gender.model.Gender;


    public interface GenderService {
    	
    public 	ResponseObj getAllGender(PaginationModel pagination);
   
    public ResponseObj getAll();	
   
    public ResponseObj getStatus(PaginationModel pagination, String status);

	public ResponseObj getById(Long id);
	
	public ResponseObj getByName(String genderName);
    	
	public ResponseObj  createGender(Gender gender);
	
	public ResponseObj  updateGender(Gender gender);      
	                                                                                                        
	public ResponseObj  deleteById(Long id);

	
	

	
	
	


	                                                                                 
	

}

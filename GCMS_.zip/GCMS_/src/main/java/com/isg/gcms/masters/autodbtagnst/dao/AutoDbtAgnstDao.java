package com.isg.gcms.masters.autodbtagnst.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.autodbtagnst.model.AutoDebitAgainst;


@Repository
public interface AutoDbtAgnstDao  extends JpaRepository<AutoDebitAgainst,Long>
{
	public List<AutoDebitAgainst> findByAutodbtAgnstCertified(int id);
	
	public Optional<AutoDebitAgainst> findByautodbtAgnstNameEqualsIgnoreCase(String name);
	
	@Query("SELECT M FROM AutoDebitAgainst M WHERE M.autodbtAgnstCertified!=2")
	public Page<AutoDebitAgainst> findAllByPagination(Pageable pageble);
	
	@Query("SELECT M FROM AutoDebitAgainst M where M.autodbtAgnstCertified=0 AND M.autodbtAgnstCertified!=2")
	public Page<AutoDebitAgainst> FindAllActiveByPagination(Pageable pageable);
	
	@Query("SELECT M FROM AutoDebitAgainst M where M.autodbtAgnstCertified=1 AND M.autodbtAgnstCertified!=2")
	public Page<AutoDebitAgainst> FindAllInActiveByPagination(Pageable pageable);

}

package com.isg.gcms.masters.employee.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.education.model.Education;
import com.isg.gcms.masters.education.model.EducationTrail;
import com.isg.gcms.masters.employee.dao.EmployeeDao;
import com.isg.gcms.masters.employee.dao.EmployeeTrailDao;
import com.isg.gcms.masters.employee.dto.EmpUpdateDTO;
import com.isg.gcms.masters.employee.model.Employee;
import com.isg.gcms.masters.employee.model.EmployeeTrail;

@Service
public class EmployeeServiceImp implements EmployeeService {
	
	/*
	 * To inject an instance of DecisonDao
	 */
	@Autowired
	private EmployeeDao empDao;
	
	/*
	 * To inject an instance of Decison Trail Dao
	 */
	@Autowired
	private EmployeeTrailDao empTrlDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	private ResponseObj res;
	
	
		
	/*
	 * To inject an instance of Certification
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	/*
	 * To get all Decision values.
	 */
	@Override
	public ResponseObj getAllEmp() 
	{
		List<Employee> employee=this.empDao.findAll();
		if(!employee.isEmpty())
		{
			res.addData(Constant.LIST_ALL, employee);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllEmp(PaginationModel pagination) 
	{
		Page<Employee> employee=this.empDao.findAll(pagination.pageRequest());
		List<Employee> employeeList = employee.getContent();
		if(!employeeList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, employeeList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	 
	/*
	 * To find Decision based on id and to use in other methods.
	 */
	@Override
	public Optional<Employee> findById(Long id) {
		return this.empDao.findById(id);
	}

	/*
	 * To get Decision based on id.
	 */
	@Override
	public ResponseObj getById(Long id) {
		Optional<Employee> emp = this.findById(id);
		if(emp.isPresent() && emp.get().getEmployeeCertified() == 0)
		{
			res.addData(Constant.BY_ID, ResponseDTO.accepted().convertTo(emp.get(), EmpUpdateDTO.class ));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To get Decision based on name.
	 */
	public Optional<Employee> getByName(String fname )
	{
		return this.empDao.findByemployeeFullNameEqualsIgnoreCase(fname);
	}

	/*
	 * To find Decision based on name
	 */
	@Override
	public ResponseObj findByName(String fname) {
		Optional<Employee> emp = this.getByName(fname);
		if (emp.isPresent() && emp.get().getEmployeeCertified() == 0) {
			res.addData(Constant.BY_NAME, ResponseDTO.accepted().convertTo(emp.get(), EmpUpdateDTO.class));
		} else {
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To create new Decision value.
	 */
	@Override
	public ResponseObj create(Employee emp) {
		emp.setEmployeeCertified(1);
		emp.setEmployeeCreatedby("adi");  //JWT orSession
		emp.setBankId(1L);  // JWT OR SESSION
		emp.setEntityId(1L); // JWT OR SESSION
		emp.setEmployeeFullName(emp.getEmployeeFirstName() + " " + emp.getEmployeeMiddleName() + " " + 
		emp.getEmployeeLastName());
		Employee emplye = this.empDao.save(emp);
		saveEmpTrail(emplye,Constant.VALUE_CREATED,"NEW" );
		res.addData(Constant.VALUE_CREATED, emplye);
		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteById(Long id) {
		Optional<Employee> emp = this.findById(id);
		if (emp.isPresent() && emp.get().getEmployeeCertified() == 0) 
		{
			Employee empEx = emp.get();
			empEx.setEmployeeCertified(1);
			saveEmpTrail(empEx,Constant.VALUE_DELETED,"DELETE" );
			this.empDao.save(empEx);
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj updateEmp(Employee emp) {
		Optional<Employee> empold = this.findById(emp.getEmployeeId());
		if (empold.isPresent() && empold.get().getEmployeeCertified() == 0)
		{
			Employee empEx = empold.get();
			empEx.setEmployeeCertified(1);
			this.empDao.save(empEx);
			saveEmpTrail(emp,Constant.VALUE_UPDATED,"MODIFY" );
			res.addData(Constant.VALUE_UPDATED, emp );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getstatus(String status, PaginationModel pagination) {
		if(status.equalsIgnoreCase("active"))
		{
			res.addData(Constant.ALL_ACTIVE, this.empDao.getActiveEmp(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("inactive"))
		{
			res.addData(Constant.ALL_INACTIVE, this.empDao.getInactEmp(pagination.pageRequest()));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}
	
	/*
	 * To save values in Decision Trail table
	 */
	public void saveEmpTrail(Employee emp, String remark, String action) {
		EmployeeTrail empTrl = (EmployeeTrail) ResponseDTO.accepted().convertToEntity(emp,
				EmployeeTrail.class);
		empTrl.setEmployee(emp);
		empTrl.setEmployeeCreatedby("adi"); //JWT OR Session
		empTrl.setEmployeeAction(action);
		empTrl.setEmployeeCertified(1);
		empTrl.setEmployeeRemark(remark);
		this.empTrlDao.save(empTrl);
		saveCertification(empTrl);
	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(EmployeeTrail empTrl) 
	{
		/*
		 * To inject an instance of Certification
		 */
		
		Certification cert=new Certification();
		
			cert.setAction(empTrl.getEmployeeAction());
			cert.setTrailId(empTrl.getEmployeeTrailId());
			cert.setTableName(MasterType.EMPLOYEE.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); // To do replace maker with JWT
			//cert.setMakerTime(empTrl.getEmployeeCreatedDate());
			this.certificationDao.save(cert);
			
	}
	

}
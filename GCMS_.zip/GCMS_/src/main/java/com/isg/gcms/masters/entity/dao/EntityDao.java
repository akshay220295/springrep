package com.isg.gcms.masters.entity.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.entity.model.EntityBean;



@Repository
public interface EntityDao extends JpaRepository<EntityBean, Long>
{
	public Optional<EntityBean> findByEntityNameEqualsIgnoreCase(String entityName);

	public Optional<EntityBean> findByEntityNameIgnoreCase(String entityName);

	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */
}

package com.isg.gcms.masters.autodbtagnst.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "GCMS_AUTO_DBT_AGNST_MST")
public class AutoDebitAgainst 

{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="AUTO_DBT_AGNST_ID")
	private Long autodbtAgnstId;
	
	@Column(name="AUTO_DBT_AGNST_NAME")
	private String autodbtAgnstName; 
	
	@Column(name="AUTO_DBT_AGNST_CRT_DTE")
	private Date autodbtAgnstCrtDte;
	
	@Column(name="AUTO_DBT_AGNST_CRTD_BY")
	private String autodbtAgnstCrtdBy;
	
	
	@Column(name="AUTO_DBT_AGNST_MOD_DTE")
	private Date autodbtAgnstModDte;
	
	@Column(name="AUTO_DBT_AGNST_MOD_BY")
	private String autodbtAgnstModBy; 
	
	@Column(name="AUTO_DBT_AGNST_CERT")
	private Integer autodbtAgnstCertified;
	
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;

}

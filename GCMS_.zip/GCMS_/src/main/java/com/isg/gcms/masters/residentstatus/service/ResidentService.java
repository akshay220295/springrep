package com.isg.gcms.masters.residentstatus.service;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.residentstatus.model.Resident;

public interface ResidentService { 
	
	public ResponseObj getAllResident(PaginationModel pagination);
	
	public ResponseObj getAll();
	
	public ResponseObj getStatus(PaginationModel pagination, String status);
	
	public ResponseObj getById(Long id);
	
	public ResponseObj getByName(String residentName);
	
	public ResponseObj createResident(Resident resident);

	public ResponseObj updateResident(Resident resident);  
	
	public ResponseObj deleteById(Long id);

	



	

	


}

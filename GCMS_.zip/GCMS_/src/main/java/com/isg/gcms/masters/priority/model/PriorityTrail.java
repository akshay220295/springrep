package com.isg.gcms.masters.priority.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name="GCMS_PRIORITY_MST_TRAIL")
public class PriorityTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="PRIOR_TRAIL_ID")
	private Long priorityTrailId;
	
	@ManyToOne
	@JoinColumn(name = "PRIOR_ID", referencedColumnName = "PRIOR_ID")
	private Priority priority;     
	
	@Column(name="PRIOR_NAME")
    private String priorityName;
	
	
	@Column(name="PRIOR_FST_TRK_FLAG")
    private String priorityFstTrkFlag;
	
	
	@Column(name="PRIOR_CRT_DTE")
    private Date priorityCreatedDate;
	
	
	@Column(name="PRIOR_CRT_BY")
    private String  priorityCreatedBy;
	
	
	@Column(name="PRIOR_MOD_DTE")
    private Date  priorityModifiedDate;
	
	
	@Column(name="PRIOR_MOD_BY")
    private String priorityModifiedBy;
	
	
	@Column(name="PRIOR_CERT")
    private Integer priorityCertified;
	
	
	@Column(name="PRIOR_CERT_MODE")
    private Integer priorityCertifiedMode;
	
	
	@Column(name="PRIOR_ACT")
    private String priorityAction;
	
	
	@Column(name="PRIOR_RMRK")
    private String priorityRemark; 
	
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;

}

package com.isg.gcms.common;

public class Constant {

	
	 public static final String BASE = "";
	    public static final String PATH_ENTITY = Constant.BASE + "/entity";
	    public static final String PATH_BANK = Constant.BASE + "/bank";
	    public static final String PATH_ADDRESS = Constant.BASE + "/address";
	    public static final String PATH_BRANCH = Constant.BASE + "/branch";
	    public static final String PATH_DEPARTMENT = Constant.BASE + "/department";
	    public static final String PATH_DESIGNATION = Constant.BASE + "/designation";
	    public static final String PATH_CONFIG = Constant.BASE + "/config";
	    
	    public static final String PATH_SALUTATION = Constant.BASE + "/salutation";
	    public static final String PATH_ACCOUNT_TYPE = Constant.BASE + "/accountType";
	    public static final String PATH_AUTODBTAGNST = Constant.BASE + "/autodebitagainst";
	    public static final String PATH_BUREAU = Constant.BASE + "/bureau";
	    public static final String PATH_CARD_TYPE = Constant.BASE + "/cardType";
	    public static final String PATH_CHANNEL = Constant.BASE + "/channel";
	    public static final String PATH_DECISION = Constant.BASE + "/decision";
	    public static final String PATH_DEFERRAL = Constant.BASE + "/deferral";
	    public static final String PATH_DSA = Constant.BASE + "/dsa";
	    public static final String PATH_EDUCATION = Constant.BASE + "/education";
	    public static final String PATH_EMPLOYEE = Constant.BASE + "/employee";
	    public static final String PATH_EXCEPTION = Constant.BASE + "/exception";
	    public static final String PATH_GENDER = Constant.BASE + "/gender";
	    public static final String PATH_MARITAL_STS = Constant.BASE + "/maritalStatus";
	    public static final String PATH_OCCUPATION = Constant.BASE + "/occupation";
	    public static final String PATH_PRIORITY = Constant.BASE + "/priority";
	    public static final String PATH_PROMOCODE = Constant.BASE + "/promoCode";
	    public static final String PATH_RELATIONSHIP = Constant.BASE + "/relationship";
	    public static final String PATH_RESIDENTIAL_STS = Constant.BASE + "/residentialStatus";
	    public static final String PATH_SUBCARD_TYPE = Constant.BASE + "/subCardType";
	    public static final String PATH_VIP = Constant.BASE + "/vip";
	    
	    public static final String PATH_COLUMN="/column";
	   
	    public static final String PATH_DELETE="/delete/{id}";
	    
	    public static final String PATH_GET_ALL =  "/getAll";
	    
	    public static final String PATH_GET_ALL_PAGI =  "/get";
	    
	    public static final String PATH_VARIABLE_ID =  "/{id}";
	    
	    public static final String PATH_VARIABLE_TABLE =  "/{table}";
	    
	    public static final String PATH_VARIABLE_NAME =  "name/{name}";
	    
	    public static final String PATH_VARIABLE_STATUS =  "/status/{status}";
	    
	/* ------------------------------------------------------------- */
	    
	    public static final String LIST_ALL = Constant.BASE + "LIST ALL";
	    public static final String BY_ID = Constant.BASE + "BY ID";
	    public static final String BY_NAME = Constant.BASE + "BY NAME";
	    public static final String ERROR_MSG = Constant.BASE + "NO DATA FOUND";
	    public static final String VALUE_CREATED = Constant.BASE + "VALUE CREATED";
	    public static final String VALUE_DELETED = Constant.BASE + "VALUE DELETED";
	    public static final String VALUE_UPDATED = Constant.BASE + "VALUE UPDATED";
	    public static final String ALL_ACTIVE = Constant.BASE + "ALL ACTIVE";
	    public static final String ALL_INACTIVE = Constant.BASE + "ALL INACTIVE";
	    
	    
	    
}

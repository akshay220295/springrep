package com.isg.gcms.masters.dsa.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import com.isg.gcms.masters.dsa.model.Dsa;
import com.isg.gcms.masters.dsa.model.DsaTrail;

@Repository
public interface DsaTrailDao extends JpaRepository < DsaTrail, Long >
{

	public List<DsaTrail> findByDsa(Dsa dsa);
	
}

package com.isg.gcms.masters.bank.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.bank.model.Bank;
import com.isg.gcms.masters.bank.model.BankTrail;





@Repository
public interface BankTrailDao extends JpaRepository<BankTrail, Long>
{
	public List<BankTrail> findByBank(Bank bank);

	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the name we provided it.
	 */

}

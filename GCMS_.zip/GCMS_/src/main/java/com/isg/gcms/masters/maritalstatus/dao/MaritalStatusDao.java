package com.isg.gcms.masters.maritalstatus.dao;


import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.employee.model.Employee;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;

@Repository
public interface MaritalStatusDao extends JpaRepository<MaritalStatus, Long>
{
	public Optional<MaritalStatus> findByMaritalStatusNameEqualsIgnoreCase(String username);
	
	public List<MaritalStatus> findBymaritalStatusCertified(int id);
	
	@Query("SELECT M FROM MaritalStatus M WHERE M.maritalStatusCertified!=2")
	public Page<MaritalStatus>  findAllByPagination(Pageable pageable);
	
	@Query ("SELECT M FROM MaritalStatus M WHERE M.maritalStatusCertified=0 AND M.maritalStatusCertified!=2")
	public Page<MaritalStatus> getActiveMaritalSts(Pageable pageable);
	
	@Query ("SELECT M FROM MaritalStatus M WHERE M.maritalStatusCertified=1 AND M.maritalStatusCertified!=2")
	public Page<MaritalStatus> getInactMaritalSts(Pageable pageable);
}

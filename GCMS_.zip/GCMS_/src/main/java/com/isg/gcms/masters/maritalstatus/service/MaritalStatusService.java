package com.isg.gcms.masters.maritalstatus.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.maritalstatus.model.MaritalStatus;

public interface MaritalStatusService {

	public ResponseObj getAllMartlSts(PaginationModel pagination);

	public ResponseObj getById(Long id);

	public Optional<MaritalStatus> findById(Long id);
	
	public ResponseObj findByName(String username);
	
	public ResponseObj create(MaritalStatus maritalstatus);

	public ResponseObj deleteById(Long id);

	public ResponseObj updateMartlSts(MaritalStatus maritalstatus);
	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllMartlSts();

}

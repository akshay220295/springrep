package com.isg.gcms.masters.cardtype.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "GCMS_CARD_TYPE_MST_TRAIL")
public class CardTypeTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CRD_TYP_TRAIL_ID")
	private Long cardTypeTrailId; 
	
	@ManyToOne
	@JoinColumn(name = "CRD_TYP_ID", referencedColumnName = "CRD_TYP_ID")
	private CardType cardType;
	
	@Column(name="CRD_TYP_NAME")
	private String cardTypeName; 
	
	@Column(name="CRD_TYP_CRT_DTE")
	private Date cardTypeCreatedDate;
	
	@Column(name="CRD_TYP_CRT_BY")
	private String cardTypeCreatedBy;
	
	@Column(name="CRD_TYP_MOD_DTE")
	private Date cardTypeModifiedDate;
	
	@Column(name="CRD_TYP_MOD_BY")
	private String cardTypeModifiedBy;
	
	
	@Column(name="CRD_TYP_CERT")
	private Integer cardTypeCertified;
	
	@Column(name="CRD_TYP_ACT")
    private String cardTypeAction;
	
	@Column(name="CRD_TYP_RMRK")
    private String cardTypeRemark;  
	
	
	@Column (name = "BANK_ID")
	private Long bankId; 
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column(name="CRD_TYP_CERT_MOD")
	private Integer cardTypeCertMod;
}

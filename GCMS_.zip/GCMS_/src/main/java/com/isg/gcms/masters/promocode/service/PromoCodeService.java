package com.isg.gcms.masters.promocode.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.promocode.model.PromoCode;


@Service
public interface PromoCodeService {
	
	public ResponseObj getAllPrmocde(PaginationModel pagination);

	public ResponseObj create(PromoCode prmocde);

	public ResponseObj getById(Long id);

	public Optional<PromoCode> findById(Long id);

	public ResponseObj deleteById(Long id);

	public ResponseObj findByName(String name);

	public ResponseObj updatePrmocde(PromoCode prmocde);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);

	public ResponseObj getAllPrmocde();
}

package com.isg.gcms.masters.accounttype.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class AccTypCreationDTO 
{
	private String accountTypeName;
	
	@JsonIgnore
	private final Date accountTypeCreatedDate = new Date();

}

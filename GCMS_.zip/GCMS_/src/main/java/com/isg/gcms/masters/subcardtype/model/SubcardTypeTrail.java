package com.isg.gcms.masters.subcardtype.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;



import lombok.Data;

@Entity
@Data
@Table (name = "GCMS_SUBCARD_TYPE_MST_TRAIL")
public class SubcardTypeTrail 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column (name = "SUBCRD_TYP_TRAIL_ID")
	private Long subcardTypeTrailId;
	
	@ManyToOne
	@JoinColumn (name = "SUBCRD_TYP_ID" , referencedColumnName =  "SUBCRD_TYP_ID" )
	private SubcardType subcardType; 
	
	@Column (name = "SUBCRD_TYP_CODE")
	private String subcardTypeCode; 
	
	@Column (name = "SUBCRD_TYP_NAME")
	private String subcardTypeName; 
	
	@Column (name = "SUBCRD_TYP_CRT_DTE")

	private Date subcardTypeCreatedDate;  
	
	@Column (name = "SUBCRD_TYP_CRT_BY")
	private String subcardTypeCreatedby; 
	
	@Column (name = "SUBCRD_TYP_MOD_DTE")

	private Date subcardTypeModifiedDate; 
	
	@Column (name = "SUBCRD_TYP_MOD_BY")
	private String subcardTypeModifiedBy; 
	
	@Column (name = "SUBCRD_TYP_CERT")
	private Integer subcardTypeCertified;
	
	@Column (name = "BANK_ID")
	private Long bankId;
	
	@Column(name = "EN_ID")
	private Long entityId;
	
	@Column (name = "SUBCRD_TYP_CERT_MODE")
	private Integer subcardTypeCertMode;
	
	@Column (name = "SUBCRD_TYP_ACT")
	private String subcardTypeAction;
	
	@Column (name = "SUBCRD_TYP_RMRK")
	private String subcardTypeRemark;
}

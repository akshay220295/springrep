package com.isg.gcms.masters.vip.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class VipUpdateDTO {
	
	@Id
	@NotNull
	private Long vipId;
	
	private String vipName;
	
	@JsonIgnore
    private final Date vipModifiedDate = new Date();
}

package com.isg.gcms.masters.residentstatus.model;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Data;



/**
 * @Data is a convenient shortcut annotation that bundles the features
 *       of @ToString, @EqualsAndHashCode, @Getter / @Setter
 *       and @RequiredArgsConstructor together.
 */



@Data
@Entity
@Table(name = "GCMS_RESIDENT_MST")
public class Resident {

    @Id	 
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "RESDTSTS_ID")
    private Long residentId; 
    
    @Column(name = "RESDT_NAME")
    private String  residentName; 
        
    @Column(name = "RESDTSTS_CRT_DTE")
    private  Date residentCreatedDate;
        
     @Column(name = "RESDTSTS_CRT_BY")
     private String  residentCreatedBy;
    
     @Column(name = "RESDTSTS_MOD_DTE")
     private Date residentModifiedDate;    
     
     @Column(name = "RESDTSTS_MOD_BY")
     private String  residentModifiedBy; 
     
     @Column(name ="RESDTSTS_CERT")
     private  Integer residentCertified;
     
     @Column (name = "BANK_ID")
 	 private Long bankId;
 	
 	 @Column(name = "EN_ID")
 	 private Long entityId;

}

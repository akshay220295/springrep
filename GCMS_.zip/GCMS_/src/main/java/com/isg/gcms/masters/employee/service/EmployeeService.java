package com.isg.gcms.masters.employee.service;

import java.util.Optional;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseObj;

import com.isg.gcms.masters.employee.model.Employee;

public interface EmployeeService {
	
	public ResponseObj getAllEmp();
	
	public ResponseObj getAllEmp(PaginationModel pagination);
	
	public Optional<Employee> findById(Long id);

	public ResponseObj getById(Long id);
	
	public ResponseObj findByName(String fname);
	
	public ResponseObj create(Employee emp);

	public ResponseObj deleteById(Long id);

	public ResponseObj updateEmp(Employee emp);
	
	public ResponseObj getstatus(String status, PaginationModel pagination);

}

package com.isg.gcms.certification.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.certification.model.Certification;

@Repository
public interface CertificationDao extends JpaRepository<Certification, Long>
{
	public List<Certification> findByCertified(int certified);

	public List<Certification> findBytableNameIgnoreCase(String tableName);

	public Certification findByTrailId(long trailId);

	/*
	 * The Spring Data Repository will auto-generate the implementation based on
	 * the method name we provide it.
	 */
}

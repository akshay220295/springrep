package com.isg.gcms.masters.dsa.service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import com.isg.gcms.certification.dao.CertificationDao;
import com.isg.gcms.certification.model.Certification;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.MasterType;
import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.decision.model.Decision;
import com.isg.gcms.masters.dsa.dao.DsaDao;
import com.isg.gcms.masters.dsa.dao.DsaTrailDao;
import com.isg.gcms.masters.dsa.dto.DsaUpdateDTO;
import com.isg.gcms.masters.dsa.model.Dsa;
import com.isg.gcms.masters.dsa.model.DsaTrail;


@Service
public class DsaServiceImp implements DsaService
{
	
	/*
	 * To inject an instance of DsaDao
	 */
	@Autowired
	DsaDao dsaDao;
	
	/*
	 * To inject an instance of DsaTrailDao
	 */
	@Autowired
	DsaTrailDao dsaTrailDao;
	
	/*
	 * To inject an instance of ResponseObj
	 */
	@Autowired
	ResponseObj res;
	
	
			
	/*
	 * To inject an instance of CertificationDao
	 */
	@Autowired
	private CertificationDao certificationDao;
	
	
	/*
	 * To find Dsa based on id and to use in other methods.
	 */
	public Optional<Dsa> findByDsaId(Long dsaId)
	{
		return this.dsaDao.findById(dsaId);
	}
	
	
	/*
	 * To get all Dsa values.
	 */
	@Override
	public ResponseObj getAllDsa() 
	{
		List<Dsa> dsa=this.dsaDao.findAll();
		if(!dsa.isEmpty())
		{
			res.addData(Constant.LIST_ALL, dsa);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	/*
	 * To get all values with pagination and checking if list is empty or not.
	 */
	@Override
	public ResponseObj getAllDsa(PaginationModel pagination) 
	{
		Page<Dsa> dsa=this.dsaDao.findAll(pagination.pageRequest());
		List<Dsa> dsaList = dsa.getContent();
		if(!dsaList.isEmpty())
		{
			res.addData(Constant.LIST_ALL, dsaList);
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		return res;
	}

	
	/*
	 * To get status based on (active/inactive)
	 */
	@Override
	public ResponseObj getStatus(PaginationModel pagination, String status) 
	{
		if(status.equalsIgnoreCase("ACTIVE"))
		{
			res.addData(Constant.ALL_ACTIVE, this.dsaDao.FindAllActiveByPagination(pagination.pageRequest()));
		}
		else if(status.equalsIgnoreCase("INACTIVE"))
		{
			res.addData(Constant.ALL_INACTIVE, this.dsaDao.FindAllInActiveByPagination(pagination.pageRequest()));
		}
		
		return res;
	}

	/*
	 * To get Dsa based on id.
	 */
	@Override
	public ResponseObj getById(Long id) 
	{
		Optional<Dsa> dsa= this.dsaDao.findById(id);
		if(dsa.isPresent() && dsa.get().getDsaCertified()==0)
		{
			res.addData(Constant.BY_ID,ResponseDTO.accepted().convertTo(dsa.get(), DsaUpdateDTO.class));
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}
	
	/*
	 * To get Dsa based on name.
	 */
	@Override
	public ResponseObj getByName(String name) 
	{
		Optional<Dsa> dsa=this.dsaDao.findByDsaNameEqualsIgnoreCase(name);
		
		if(dsa.isPresent() && dsa.get().getDsaCertified()==0)
		{
			res.addData(Constant.BY_NAME,ResponseDTO.accepted().convertTo(dsa.get(), DsaUpdateDTO.class ) );
		}
		else
		{
			res.setActionError(Constant.ERROR_MSG);
		}
		
		return res;
	}

	/*
	 * To find Dsa based on name
	 */
	@Override
	public Optional<Dsa> findbyDsaName(String saltnName) 
	{
		
		return this.dsaDao.findByDsaNameEqualsIgnoreCase(saltnName);
	}
	
	/*
	 * To create new Dsa value.
	 */
	@Override
	public ResponseObj create(Dsa dsa) 
	{
		dsa.setDsaCertified(1);
		dsa.setDsaCreatedBy("Ajit");
		dsa.setBankId(1L);  // JWT OR SESSION
		dsa.setEntityId(1L); // JWT OR SESSION
		Dsa ds = this.dsaDao.save(dsa);
		res.addData(Constant.VALUE_CREATED, ds);
		saveDsaTrail(dsa, Constant.VALUE_CREATED , "NEW");
		return res;
	}

	/*
	 * To Update existing value based on id
	 */
	@Override
	public ResponseObj update(Dsa dsa) 
	{
		Optional<Dsa> ds= findByDsaId(dsa.getDsaId());
		
		if(ds.isPresent() &&  ds.get().getDsaCertified()==0)
		{
			Dsa dsaExisting = ds.get();
			dsaExisting.setDsaCertified(1);
			dsaExisting.setDsaModifiedDate(new Date());
			dsaExisting.setDsaModifiedBy("Ajit");
			this.dsaDao.save(dsaExisting);
			saveDsaTrail(dsa,Constant.VALUE_UPDATED, "MODIFY");
			res.addData(Constant.VALUE_UPDATED, dsa);
		}
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}

	/*
	 * To soft delete based on id
	 */
	@Override
	public ResponseObj deleteDsa(Long id) 
	{
		Optional<Dsa> dsa = findByDsaId(id);

		if (dsa.isPresent() && dsa.get().getDsaCertified() == 0) {
			Dsa dsaExisting = dsa.get();
			dsaExisting.setDsaCertified(1);
			this.dsaDao.save(dsaExisting);
			saveDsaTrail(dsaExisting, Constant.VALUE_DELETED,"DELETE");
			
			res.setMsg(Constant.VALUE_DELETED, ResponseMsgType.SUCCESS);
		} 
		else
			res.setActionError(Constant.ERROR_MSG);

		return res;
	}
	
	/*
	 * To save values in Dsa Trail table
	 */
	public void saveDsaTrail( Dsa dsa, String remarks, String action) 
	{

		DsaTrail dsaTrail = (DsaTrail) ResponseDTO.accepted().convertToEntity(dsa, DsaTrail.class);
		dsaTrail.setDsa(dsa);
		dsaTrail.setDsaCreatedBy("Ajit");
		dsaTrail.setDsaAction(action);
		dsaTrail.setDsaRemark(remarks);
		dsaTrail.setDsaCertified(1);
		
		this.dsaTrailDao.save(dsaTrail);
		saveCertification(dsaTrail);

	}
	
	/*
	 * To save values in Certification table
	 */
	public void saveCertification(DsaTrail dsaTrail) 
	{
		
			/*
			 * To inject an instance of Certification
			 */
			
			Certification cert= new Certification();
		
			cert.setAction(dsaTrail.getDsaAction());
			cert.setTrailId(dsaTrail.getDsaTrailId());
			cert.setTableName(MasterType.DSA.toString());
			cert.setCertified(1);
			cert.setMaker("Ajit"); /* To do replace maker with JWT */
			cert.setMakerTime(dsaTrail.getDsaCreatedDate());
			this.certificationDao.save(cert);
			
	}

}

package com.isg.gcms.masters.entity.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.isg.gcms.common.bind.ResponseDTO;
import com.isg.gcms.common.response.ResponseMsgType;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.entity.dao.EntityDao;
import com.isg.gcms.masters.entity.dto.EntityCreationDTO;
import com.isg.gcms.masters.entity.dto.EntityUpdateDTO;
import com.isg.gcms.masters.entity.model.EntityBean;



@Service
public class EntityServiceImpl implements EntityService {

	// To inject an instance of EntityDao
	@Autowired
	private EntityDao entityDao;

	@Autowired
	private ResponseObj res;

//	@Value("${not_found}")
//	private String message;

	@Override
	public Optional<EntityBean> findbyEntityName(String entityName) {

		return this.entityDao.findByEntityNameEqualsIgnoreCase(entityName);

	}

	@Override
	public Optional<EntityBean> findByEntityId(Long entityId) {

		return this.entityDao.findById(entityId);

	}

	@Override
	public ResponseObj getEntityByName(String entityName) {

		Optional<EntityBean> entity = findbyEntityName(entityName);
		if (entity.isPresent())
			res.addData("Fetch Entity by Name",
					ResponseDTO.accepted().convertTo(entity.get(), EntityCreationDTO.class));
		else
			res.setActionError("Entity with ID " + entityName + " not found.");

		return res;
	}

	@Override
	public ResponseObj getEntity(long entityId) {

		Optional<EntityBean> entity = findByEntityId(entityId);

		if (entity.isPresent())
			res.addData("Fetch Entity by ID", ResponseDTO.accepted().convertTo(entity.get(), EntityCreationDTO.class));
		else
			res.setActionError("Entity with ID " + entityId + " not found.");

		return res;
	}

	@Override
	public ResponseObj getAllEntities(Pageable xPageable) {

		res.addData("Find all Entity by Paging", this.entityDao.findAll(xPageable));
		return res;
	}

	@Override
	public ResponseObj saveEntity(EntityBean entity) {

		/*
		 * entity.setEntityCreatedBy("Srushti"); // To DO Getting the maker from JWT
		 */ 
		res.addData("Save Entity",
				ResponseDTO.accepted().convertTo(this.entityDao.save(entity), EntityCreationDTO.class));

		return res;
	}

	@Override
	public ResponseObj updateEntity(EntityBean entity) {

		Optional<EntityBean> entityEx = findByEntityId(entity.getEntityId());

		if (entityEx.isPresent()) {
			/*
			 * entity.setEntityModifiedBy("Vishnu"); //// To DO Get the maker from JWT
			 */			entity.setEntityCreatedBy(entityEx.get().getEntityCreatedBy());
			entity.setEntityCreatedDate(entityEx.get().getEntityCreatedDate());
			res.addData("Update Entity",
					ResponseDTO.accepted().convertTo(this.entityDao.save(entity), EntityUpdateDTO.class));
		}

		else {
			res.setActionError("Entity not found for Id: " + entity.getEntityId());
		}

		return res;
	}

	// To Do- whether this api should be included
	@Override
	public ResponseObj deleteEntity(Long entityId) {
		
		res.setMsg("Entity Not to be deleted", ResponseMsgType.WARNING);
		
		return res;

	}
}

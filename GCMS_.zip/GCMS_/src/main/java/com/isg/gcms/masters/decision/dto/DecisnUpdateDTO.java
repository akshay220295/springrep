package com.isg.gcms.masters.decision.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class DecisnUpdateDTO 
{	
	@Id
	@NotNull
	private Long decisionId;
	
	private String decisionName;
	
	@JsonIgnore
	private final Date decisionModifiedDate = new Date();
	

}

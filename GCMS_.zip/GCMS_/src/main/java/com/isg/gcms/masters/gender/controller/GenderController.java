package com.isg.gcms.masters.gender.controller;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.isg.gcms.common.pagination.PaginationModel;
import com.isg.gcms.common.Constant;
import com.isg.gcms.common.bind.RequestDTO;
import com.isg.gcms.common.response.ResponseObj;
import com.isg.gcms.masters.gender.dto.GenderCreationDTO;
import com.isg.gcms.masters.gender.dto.GenderUpdateDTO;
import com.isg.gcms.masters.gender.model.Gender;
import com.isg.gcms.masters.gender.service.GenderService;

@RestController
@CrossOrigin("*")
@RequestMapping(value=Constant.PATH_GENDER)
public class GenderController {

	/*
	 * To inject an instance of GenderService
	 */
	@Autowired
	private GenderService genderService;
	

	/*
	 * To get records with pagination
	 */
	@PostMapping(value=Constant.PATH_GET_ALL_PAGI)
	public ResponseObj getAllGender(@RequestBody PaginationModel pagination) {
		return this.genderService.getAllGender(pagination);

	}
	
	/*
	 * To get all records
	 */
	@GetMapping(value= Constant.PATH_GET_ALL)
	public ResponseObj getAll()
	{

		return this.genderService.getAll();

	}
	
	/*
	 * To get status based on(active/deactive)
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_STATUS)
	public ResponseObj findActive(@RequestBody PaginationModel pagination,@PathVariable("status") String status)
	{
		return this.genderService.getStatus(pagination, status) ;
	}
	
	/*
	 * To get records based on id
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_ID)
	public ResponseObj getById(@PathVariable("id") Long id) {

		return this.genderService.getById(id);
		
	}
	
	/*
	 * To get records based on name
	 */
	@GetMapping(value=Constant.PATH_VARIABLE_NAME)
	public ResponseObj getGenderByName(@PathVariable("name") String genderName) {

		return this.genderService.getByName(genderName);

	}	
	
	
	/*
	 * To create a new gender .
	 */
	@PostMapping
	public ResponseObj createGender(@RequestDTO(GenderCreationDTO.class) @Validated Gender gender) {
		return this.genderService.createGender(gender);

	}

	
	/*
	 * To update existing gender.
	 */
	@PutMapping
	public ResponseObj updateGender(@RequestDTO(GenderUpdateDTO.class) @Validated Gender gender) {
		return this.genderService.updateGender(gender);

	}
	
	/*
	 * To soft delete a gender based on gender id
	 */
	@DeleteMapping(value=Constant.PATH_DELETE)
	public ResponseObj delete(@PathVariable("id") Long id) {

		return this.genderService.deleteById(id);
	}

    }

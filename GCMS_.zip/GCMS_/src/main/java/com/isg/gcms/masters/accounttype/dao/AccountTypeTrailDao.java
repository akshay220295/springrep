package com.isg.gcms.masters.accounttype.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.isg.gcms.masters.accounttype.model.AccountType;
import com.isg.gcms.masters.accounttype.model.AccountTypeTrail;

@Repository
public interface AccountTypeTrailDao extends JpaRepository<AccountTypeTrail,Long> {
	
	public List<AccountTypeTrail> findByAccountType(AccountType accTyp);

}

package com.isg.gcms.masters.accounttype.dto;

import java.util.Date;

import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.isg.gcms.common.bind.DTO;

import lombok.Data;

@Data
@DTO
public class AccTypUpdateDTO 
{	
	@Id
	@NotNull
	private Long accountTypeId;
	
	private String accountTypeName;
	
	@JsonIgnore
	private final Date accountTypeModifiedDate = new Date();

}
